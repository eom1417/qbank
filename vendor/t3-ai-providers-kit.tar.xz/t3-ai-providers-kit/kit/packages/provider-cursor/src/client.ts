import { ProviderDriverKind } from "@t3tools/contracts";
import { defineProviderClient } from "@t3tools/provider-core/client";

import { CursorSettings } from "./settings.ts";

export const cursorClient = defineProviderClient({
  driverKind: ProviderDriverKind.make("cursor"),
  label: "Cursor",
  modelFamilies: ["Grok "],
  acpRegistryAgentIds: ["cursor"],
  settingsSchema: CursorSettings,
  environmentFields: [
    {
      name: "CURSOR_API_KEY",
      label: "Cursor API key",
      description: "Optional. Overrides browser sign-in for this provider.",
      placeholder: "Paste API key",
      sensitive: true,
    },
  ],
  icon: {
    viewBox: "0 0 466.73 532.09",
    fill: { light: "#26251E", dark: "#EDECEC" },
    paths: [
      {
        d: "M457.43,125.94L244.42,2.96c-6.84-3.95-15.28-3.95-22.12,0L9.3,125.94c-5.75,3.32-9.3,9.46-9.3,16.11v247.99c0,6.65,3.55,12.79,9.3,16.11l213.01,122.98c6.84,3.95,15.28,3.95,22.12,0l213.01-122.98c5.75-3.32,9.3-9.46,9.3-16.11v-247.99c0-6.65-3.55-12.79-9.3-16.11h-.01ZM444.05,151.99l-205.63,356.16c-1.39,2.4-5.06,1.42-5.06-1.36v-233.21c0-4.66-2.49-8.97-6.53-11.31L24.87,145.67c-2.4-1.39-1.42-5.06,1.36-5.06h411.26c5.84,0,9.49,6.33,6.57,11.39h-.01Z",
      },
    ],
  },
});
