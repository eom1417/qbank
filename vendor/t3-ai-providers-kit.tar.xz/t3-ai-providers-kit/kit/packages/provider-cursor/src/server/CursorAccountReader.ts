import * as Context from "effect/Context";
import * as Digest from "effect/crypto/Digest";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as HttpClient from "effect/http/HttpClient";
import * as Layer from "effect/Layer";

import type { CursorCredentialSource } from "./accountCache.ts";
import { readCursorAccountUsage, type CursorAccountUsageReadResult } from "./accountUsage.ts";
import * as CursorKeychain from "./CursorKeychain.ts";

export class CursorAccountReader extends Context.Service<
  CursorAccountReader,
  {
    readonly read: (
      credentialSource: CursorCredentialSource,
      sinceMs: number,
      untilMs: number,
    ) => Effect.Effect<CursorAccountUsageReadResult>;
  }
>()("@t3tools/provider-cursor/server/CursorAccountReader") {}

export const layer = Layer.effect(
  CursorAccountReader,
  Effect.gen(function* () {
    const keychain = yield* CursorKeychain.CursorKeychain;
    const context = yield* Effect.context<
      FileSystem.FileSystem | Digest.Digest | HttpClient.HttpClient
    >();
    return CursorAccountReader.of({
      read: Effect.fn("CursorAccountReader.read")(function (credentialSource, sinceMs, untilMs) {
        return readCursorAccountUsage(
          credentialSource,
          sinceMs,
          untilMs,
          keychain.accessToken,
        ).pipe(Effect.provideContext(context));
      }),
    });
  }),
);
