import * as Queue from "effect/Queue";
import * as Stream from "effect/Stream";
import * as Cause from "effect/Cause";
import * as Effect from "effect/Effect";
import * as Sink from "effect/Sink";
import * as Stdio from "effect/Stdio";
import { ChildProcessSpawner } from "effect/process";

import * as AcpError from "../errors.ts";

const encoder = new TextEncoder();

export const makeChildStdio = (handle: ChildProcessSpawner.ChildProcessHandle) =>
  Stdio.make({
    args: Effect.succeed([]),
    stdin: handle.stdout,
    stdout: () =>
      Sink.mapInput(handle.stdin, (chunk: string | Uint8Array) =>
        typeof chunk === "string" ? encoder.encode(chunk) : chunk,
      ),
    stderr: () => Sink.drain,
  });

export const makeInMemoryStdio = Effect.fn("makeInMemoryStdio")(function* () {
  const input = yield* Queue.unbounded<Uint8Array, Cause.Done<void>>();
  const output = yield* Queue.unbounded<string>();
  const decoder = new TextDecoder();

  return {
    stdio: Stdio.make({
      args: Effect.succeed([]),
      stdin: Stream.fromQueue(input),
      stdout: () =>
        Sink.forEach((chunk: string | Uint8Array) =>
          Queue.offer(
            output,
            typeof chunk === "string" ? chunk : decoder.decode(chunk, { stream: true }),
          ),
        ),
      stderr: () => Sink.drain,
    }),
    input,
    output,
  };
});

type ChildProcessTerminationHandle = Pick<
  ChildProcessSpawner.ChildProcessHandle,
  "exitCode" | "pid"
>;

export const makeTerminationError = (
  handle: ChildProcessTerminationHandle,
): Effect.Effect<AcpError.AcpError> =>
  Effect.match(handle.exitCode, {
    onFailure: (cause) => {
      // The Node spawner reports signal exits as a platform error rather than an exit code.
      const signal =
        cause.reason.module === "ChildProcess" &&
        cause.reason.method === "exitCode" &&
        cause.reason.cause instanceof Error
          ? /^Process interrupted due to receipt of signal: '(SIG[A-Z0-9]+)'$/.exec(
              cause.reason.cause.message,
            )?.[1]
          : undefined;
      return signal === undefined
        ? new AcpError.AcpTransportError({
            operation: "read-process-exit-status",
            pid: handle.pid,
            cause,
          })
        : new AcpError.AcpProcessExitedError({ signal, pid: handle.pid, cause });
    },
    onSuccess: (code) => new AcpError.AcpProcessExitedError({ code, pid: handle.pid }),
  });
