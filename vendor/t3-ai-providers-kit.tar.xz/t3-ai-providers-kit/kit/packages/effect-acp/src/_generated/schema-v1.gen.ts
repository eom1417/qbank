import * as Schema from "effect/Schema";

export type SessionId = string;
export const SessionId = Schema.String.annotate({
  description:
    "A unique identifier for a conversation session between a client and agent.\n\nSessions maintain their own context, conversation history, and state,\nallowing multiple independent interactions with the same agent.\n\nSee protocol docs: [Session ID](https://agentclientprotocol.com/protocol/session-setup#session-id)",
  identifier: "SessionId",
});

export type NesSuggestionId = string;
export const NesSuggestionId = Schema.String.annotate({
  description: "Unique identifier for a next edit suggestion.",
  identifier: "NesSuggestionId",
});

export type LogoutCapabilities = { readonly _meta?: { readonly [x: string]: Schema.Json } | null };
export const LogoutCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Logout capabilities supported by the agent.\n\nSupplying `{}` means the agent supports the logout method.",
  identifier: "LogoutCapabilities",
});

export type PromptCapabilities = {
  readonly image?: boolean;
  readonly audio?: boolean;
  readonly embeddedContext?: boolean;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const PromptCapabilities = Schema.Struct({
  image: Schema.optionalKey(
    Schema.Boolean.annotate({
      description: "Agent supports [`ContentBlock::Image`].",
      default: false,
    }),
  ),
  audio: Schema.optionalKey(
    Schema.Boolean.annotate({
      description: "Agent supports [`ContentBlock::Audio`].",
      default: false,
    }),
  ),
  embeddedContext: Schema.optionalKey(
    Schema.Boolean.annotate({
      description:
        "Agent supports embedded context in `session/prompt` requests.\n\nWhen enabled, the Client is allowed to include [`ContentBlock::Resource`]\nin prompt requests for pieces of context that are referenced in the message.",
      default: false,
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Prompt capabilities supported by the agent in `session/prompt` requests.\n\nBaseline agent functionality requires support for [`ContentBlock::Text`]\nand [`ContentBlock::ResourceLink`] in prompt requests.\n\nOther variants must be explicitly opted in to.\nCapabilities for different types of content in prompt requests.\n\nIndicates which content types beyond the baseline (text and resource links)\nthe agent can process.\n\nSee protocol docs: [Prompt Capabilities](https://agentclientprotocol.com/protocol/initialization#prompt-capabilities)",
  identifier: "PromptCapabilities",
});

export type McpCapabilities = {
  readonly http?: boolean;
  readonly sse?: boolean;
  readonly acp?: boolean;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const McpCapabilities = Schema.Struct({
  http: Schema.optionalKey(
    Schema.Boolean.annotate({ description: "Agent supports [`McpServer::Http`].", default: false }),
  ),
  sse: Schema.optionalKey(
    Schema.Boolean.annotate({ description: "Agent supports [`McpServer::Sse`].", default: false }),
  ),
  acp: Schema.optionalKey(
    Schema.Boolean.annotate({
      description:
        "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nAgent supports [`McpServer::Acp`].",
      default: false,
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "MCP capabilities supported by the agent",
  identifier: "McpCapabilities",
});

export type SessionListCapabilities = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SessionListCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Capabilities for the `session/list` method.\n\nSupplying `{}` means the agent supports listing sessions.",
  identifier: "SessionListCapabilities",
});

export type SessionDeleteCapabilities = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SessionDeleteCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Capabilities for the `session/delete` method.\n\nSupplying `{}` means the agent supports deleting sessions from `session/list`.",
  identifier: "SessionDeleteCapabilities",
});

export type SessionAdditionalDirectoriesCapabilities = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SessionAdditionalDirectoriesCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Capabilities for additional session directories support.\n\nSupplying `{}` means the agent supports the `additionalDirectories` field on\nsupported session lifecycle requests. Agents that also support\n`session/list` may return `SessionInfo.additionalDirectories` to report the\ncomplete ordered additional-root list associated with a listed session.",
  identifier: "SessionAdditionalDirectoriesCapabilities",
});

export type SessionForkCapabilities = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SessionForkCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nCapabilities for the `session/fork` method.\n\nSupplying `{}` means the agent supports forking sessions.",
  identifier: "SessionForkCapabilities",
});

export type SessionResumeCapabilities = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SessionResumeCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Capabilities for the `session/resume` method.\n\nSupplying `{}` means the agent supports resuming sessions.",
  identifier: "SessionResumeCapabilities",
});

export type SessionCloseCapabilities = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SessionCloseCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Capabilities for the `session/close` method.\n\nSupplying `{}` means the agent supports closing sessions.",
  identifier: "SessionCloseCapabilities",
});

export type ProvidersCapabilities = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ProvidersCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nProvider configuration capabilities supported by the agent.\n\nSupplying `{}` means the agent supports provider configuration methods.",
  identifier: "ProvidersCapabilities",
});

export type NesDocumentDidOpenCapabilities = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesDocumentDidOpenCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Marker for `document/didOpen` capability support.",
  identifier: "NesDocumentDidOpenCapabilities",
});

export type TextDocumentSyncKind = "full" | "incremental";
export const TextDocumentSyncKind = Schema.Union([
  Schema.Literal("full").annotate({
    description: "Client sends the entire file content on each change.",
  }),
  Schema.Literal("incremental").annotate({ description: "Client sends only the changed ranges." }),
]).annotate({
  description: "How the agent wants document changes delivered.",
  identifier: "TextDocumentSyncKind",
});

export type NesDocumentDidCloseCapabilities = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesDocumentDidCloseCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Marker for `document/didClose` capability support.",
  identifier: "NesDocumentDidCloseCapabilities",
});

export type NesDocumentDidSaveCapabilities = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesDocumentDidSaveCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Marker for `document/didSave` capability support.",
  identifier: "NesDocumentDidSaveCapabilities",
});

export type NesDocumentDidFocusCapabilities = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesDocumentDidFocusCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Marker for `document/didFocus` capability support.",
  identifier: "NesDocumentDidFocusCapabilities",
});

export type NesRecentFilesCapabilities = {
  readonly maxCount?: number | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesRecentFilesCapabilities = Schema.Struct({
  maxCount: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description: "Maximum number of recent files the agent can use.",
        format: "uint32",
      })
        .check(Schema.isInt().annotate({ expected: "an integer" }))
        .check(
          Schema.isGreaterThanOrEqualTo(0).annotate({
            expected: "a value greater than or equal to 0",
          }),
        ),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Capabilities for recent files context.",
  identifier: "NesRecentFilesCapabilities",
});

export type NesRelatedSnippetsCapabilities = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesRelatedSnippetsCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Capabilities for related snippets context.",
  identifier: "NesRelatedSnippetsCapabilities",
});

export type NesEditHistoryCapabilities = {
  readonly maxCount?: number | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesEditHistoryCapabilities = Schema.Struct({
  maxCount: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description: "Maximum number of edit history entries the agent can use.",
        format: "uint32",
      })
        .check(Schema.isInt().annotate({ expected: "an integer" }))
        .check(
          Schema.isGreaterThanOrEqualTo(0).annotate({
            expected: "a value greater than or equal to 0",
          }),
        ),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Capabilities for edit history context.",
  identifier: "NesEditHistoryCapabilities",
});

export type NesUserActionsCapabilities = {
  readonly maxCount?: number | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesUserActionsCapabilities = Schema.Struct({
  maxCount: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description: "Maximum number of user actions the agent can use.",
        format: "uint32",
      })
        .check(Schema.isInt().annotate({ expected: "an integer" }))
        .check(
          Schema.isGreaterThanOrEqualTo(0).annotate({
            expected: "a value greater than or equal to 0",
          }),
        ),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Capabilities for user actions context.",
  identifier: "NesUserActionsCapabilities",
});

export type NesOpenFilesCapabilities = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesOpenFilesCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Capabilities for open files context.",
  identifier: "NesOpenFilesCapabilities",
});

export type NesDiagnosticsCapabilities = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesDiagnosticsCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Capabilities for diagnostics context.",
  identifier: "NesDiagnosticsCapabilities",
});

export type PositionEncodingKind = "utf-16" | "utf-32" | "utf-8";
export const PositionEncodingKind = Schema.Union([
  Schema.Literal("utf-16").annotate({
    description: "Character offsets count UTF-16 code units. This is the default.",
  }),
  Schema.Literal("utf-32").annotate({
    description: "Character offsets count Unicode code points.",
  }),
  Schema.Literal("utf-8").annotate({
    description: "Character offsets count UTF-8 code units (bytes).",
  }),
]).annotate({
  description:
    "The encoding used for character offsets in positions.\n\nFollows the same conventions as LSP 3.17. The default is UTF-16.",
  identifier: "PositionEncodingKind",
});

export type Role = "assistant" | "user";
export const Role = Schema.Union([
  Schema.Literal("assistant").annotate({ description: "The assistant side of a conversation." }),
  Schema.Literal("user").annotate({ description: "The user side of a conversation." }),
]).annotate({
  description: "The sender or recipient of messages and data in a conversation.",
  identifier: "Role",
});

export type TextResourceContents = {
  readonly mimeType?: string | null;
  readonly text: string;
  readonly uri: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const TextResourceContents = Schema.Struct({
  mimeType: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({ description: "MIME type describing the encoded media payload." }),
      Schema.Null,
    ]),
  ),
  text: Schema.String.annotate({ description: "Text payload carried by this content block." }),
  uri: Schema.String.annotate({
    description: "URI associated with this resource or media payload.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "Text-based resource contents.", identifier: "TextResourceContents" });

export type BlobResourceContents = {
  readonly blob: string;
  readonly mimeType?: string | null;
  readonly uri: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const BlobResourceContents = Schema.Struct({
  blob: Schema.String.annotate({
    description: "Base64-encoded bytes for a binary resource payload.",
  }),
  mimeType: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({ description: "MIME type describing the encoded media payload." }),
      Schema.Null,
    ]),
  ),
  uri: Schema.String.annotate({
    description: "URI associated with this resource or media payload.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "Binary resource contents.", identifier: "BlobResourceContents" });

export type MessageId = string;
export const MessageId = Schema.String.annotate({
  description: "Unique identifier for a message within a session.",
  identifier: "MessageId",
});

export type ToolCallId = string;
export const ToolCallId = Schema.String.annotate({
  description: "Unique identifier for a tool call within a session.",
  identifier: "ToolCallId",
});

export type ToolKind =
  | "read"
  | "edit"
  | "delete"
  | "move"
  | "search"
  | "execute"
  | "think"
  | "fetch"
  | "switch_mode"
  | "other";
export const ToolKind = Schema.Union([
  Schema.Literal("read").annotate({ description: "Reading files or data." }),
  Schema.Literal("edit").annotate({ description: "Modifying files or content." }),
  Schema.Literal("delete").annotate({ description: "Removing files or data." }),
  Schema.Literal("move").annotate({ description: "Moving or renaming files." }),
  Schema.Literal("search").annotate({ description: "Searching for information." }),
  Schema.Literal("execute").annotate({ description: "Running commands or code." }),
  Schema.Literal("think").annotate({ description: "Internal reasoning or planning." }),
  Schema.Literal("fetch").annotate({ description: "Retrieving external data." }),
  Schema.Literal("switch_mode").annotate({ description: "Switching the current session mode." }),
  Schema.Literal("other").annotate({ description: "Other tool types (default)." }),
]).annotate({
  description:
    "Categories of tools that can be invoked.\n\nTool kinds help clients choose appropriate icons and optimize how they\ndisplay tool execution progress.\n\nSee protocol docs: [Creating](https://agentclientprotocol.com/protocol/tool-calls#creating)",
  identifier: "ToolKind",
});

export type ToolCallStatus = "pending" | "in_progress" | "completed" | "failed";
export const ToolCallStatus = Schema.Union([
  Schema.Literal("pending").annotate({
    description:
      "The tool call hasn't started running yet because the input is either\nstreaming or we're awaiting approval.",
  }),
  Schema.Literal("in_progress").annotate({ description: "The tool call is currently running." }),
  Schema.Literal("completed").annotate({ description: "The tool call completed successfully." }),
  Schema.Literal("failed").annotate({ description: "The tool call failed with an error." }),
]).annotate({
  description:
    "Execution status of a tool call.\n\nTool calls progress through different statuses during their lifecycle.\n\nSee protocol docs: [Status](https://agentclientprotocol.com/protocol/tool-calls#status)",
  identifier: "ToolCallStatus",
});

export type TerminalId = string;
export const TerminalId = Schema.String.annotate({
  description: "Typed identifier used for terminal values on the wire.",
  identifier: "TerminalId",
});

export type ToolCallLocation = {
  readonly path: string;
  readonly line?: number | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ToolCallLocation = Schema.Struct({
  path: Schema.String.annotate({
    description: "The absolute file path being accessed or modified.",
  }),
  line: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description: "Optional line number within the file.",
        format: "uint32",
      })
        .check(Schema.isInt().annotate({ expected: "an integer" }))
        .check(
          Schema.isGreaterThanOrEqualTo(0).annotate({
            expected: "a value greater than or equal to 0",
          }),
        ),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    'A file location being accessed or modified by a tool.\n\nEnables clients to implement "follow-along" features that track\nwhich files the agent is working with in real-time.\n\nSee protocol docs: [Following the Agent](https://agentclientprotocol.com/protocol/tool-calls#following-the-agent)',
  identifier: "ToolCallLocation",
});

export type PlanEntryPriority = "high" | "medium" | "low";
export const PlanEntryPriority = Schema.Union([
  Schema.Literal("high").annotate({
    description: "High priority task - critical to the overall goal.",
  }),
  Schema.Literal("medium").annotate({
    description: "Medium priority task - important but not critical.",
  }),
  Schema.Literal("low").annotate({
    description: "Low priority task - nice to have but not essential.",
  }),
]).annotate({
  description:
    "Priority levels for plan entries.\n\nUsed to indicate the relative importance or urgency of different\ntasks in the execution plan.\nSee protocol docs: [Plan Entries](https://agentclientprotocol.com/protocol/agent-plan#plan-entries)",
  identifier: "PlanEntryPriority",
});

export type PlanEntryStatus = "pending" | "in_progress" | "completed";
export const PlanEntryStatus = Schema.Union([
  Schema.Literal("pending").annotate({ description: "The task has not started yet." }),
  Schema.Literal("in_progress").annotate({ description: "The task is currently being worked on." }),
  Schema.Literal("completed").annotate({
    description: "The task has been successfully completed.",
  }),
]).annotate({
  description:
    "Status of a plan entry in the execution flow.\n\nTracks the lifecycle of each task from planning through completion.\nSee protocol docs: [Plan Entries](https://agentclientprotocol.com/protocol/agent-plan#plan-entries)",
  identifier: "PlanEntryStatus",
});

export type PlanId = string;
export const PlanId = Schema.String.annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nUnique identifier for a plan within a session.",
  identifier: "PlanId",
});

export type UnstructuredCommandInput = {
  readonly hint: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const UnstructuredCommandInput = Schema.Struct({
  hint: Schema.String.annotate({
    description: "A hint to display when the input hasn't been provided yet",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "All text that was typed after the command name is provided as input.",
  identifier: "UnstructuredCommandInput",
});

export type SessionModeId = string;
export const SessionModeId = Schema.String.annotate({
  description: "Unique identifier for a Session Mode.",
  identifier: "SessionModeId",
});

export type SessionConfigId = string;
export const SessionConfigId = Schema.String.annotate({
  description: "Unique identifier for a session configuration option.",
  identifier: "SessionConfigId",
});

export type SessionConfigOptionCategory =
  | "mode"
  | "model"
  | "model_config"
  | "thought_level"
  | string;
export const SessionConfigOptionCategory = Schema.Union([
  Schema.Literal("mode").annotate({ description: "Session mode selector." }),
  Schema.Literal("model").annotate({ description: "Model selector." }),
  Schema.Literal("model_config").annotate({
    description: "Model-related configuration parameter.",
  }),
  Schema.Literal("thought_level").annotate({ description: "Thought/reasoning level selector." }),
  Schema.String.annotate({ title: "other", description: "Unknown / uncategorized selector." }),
]).annotate({
  description:
    "Semantic category for a session configuration option.\n\nThis is intended to help Clients distinguish broadly common selectors (e.g. model selector vs\nsession mode selector vs thought/reasoning level) for UX purposes (keyboard shortcuts, icons,\nplacement). It MUST NOT be required for correctness. Clients MUST handle missing or unknown\ncategories gracefully.\n\nCategory names beginning with `_` are free for custom use, like other ACP extension methods.\nCategory names that do not begin with `_` are reserved for the ACP spec.",
  identifier: "SessionConfigOptionCategory",
});

export type SessionConfigValueId = string;
export const SessionConfigValueId = Schema.String.annotate({
  description: "Unique identifier for a session configuration option value.",
  identifier: "SessionConfigValueId",
});

export type SessionConfigGroupId = string;
export const SessionConfigGroupId = Schema.String.annotate({
  description: "Unique identifier for a session configuration option value group.",
  identifier: "SessionConfigGroupId",
});

export type Cost = {
  readonly amount: number;
  readonly currency: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const Cost = Schema.Struct({
  amount: Schema.Number.annotate({
    description: "Total cumulative cost for session.",
    format: "double",
  }).check(Schema.isFinite().annotate({ expected: "a finite number" })),
  currency: Schema.String.annotate({ description: 'ISO 4217 currency code (e.g., "USD", "EUR").' }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "Cost information for a session.", identifier: "Cost" });

export type CompactionId = string;
export const CompactionId = Schema.String.annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nUnique identifier for a context compaction within a session.",
  identifier: "CompactionId",
});

export type CompactionStatus = "in_progress" | "completed" | "failed" | "cancelled" | string;
export const CompactionStatus = Schema.Union([
  Schema.Literal("in_progress").annotate({
    description: "Compaction has started and has not finished.",
  }),
  Schema.Literal("completed").annotate({ description: "Compaction finished successfully." }),
  Schema.Literal("failed").annotate({ description: "Compaction finished unsuccessfully." }),
  Schema.Literal("cancelled").annotate({
    description: "Compaction was cancelled before it finished.",
  }),
  Schema.String.annotate({
    title: "other",
    description:
      "Custom or future compaction status.\n\nValues beginning with `_` are reserved for implementation-specific\nextensions. Other unknown values are reserved for future ACP statuses.",
  }),
]).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nLifecycle state of a context compaction.",
  identifier: "CompactionStatus",
});

export type ElicitationId = string;
export const ElicitationId = Schema.String.annotate({
  description: "Unique identifier for an elicitation.",
  identifier: "ElicitationId",
});

export type McpConnectionId = string;
export const McpConnectionId = Schema.String.annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nA unique identifier for an active MCP-over-ACP connection.",
  identifier: "McpConnectionId",
});

export type ExtNotification = Schema.Json;
export const ExtNotification = Schema.Json.annotate({
  expected: "JSON value",
  description:
    "Allows the Agent to send an arbitrary notification that is not part of the ACP spec.\nExtension notifications provide a way to send one-way messages for custom functionality\nwhile maintaining protocol compatibility.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
  identifier: "ExtNotification",
});

export type RequestId = null | number | string;
export const RequestId = Schema.Union([
  Schema.Null.annotate({ title: "Null", description: "The JSON-RPC `null` request id." }),
  Schema.Number.annotate({
    title: "Number",
    description: "A numeric JSON-RPC request id.",
    format: "int64",
  }).check(Schema.isInt().annotate({ expected: "an integer" })),
  Schema.String.annotate({ title: "Str", description: "A string JSON-RPC request id." }),
]).annotate({
  description:
    "JSON RPC Request Id\n\nAn identifier established by the Client that MUST contain a String, Number, or NULL value if included. If it is not included it is assumed to be a notification. The value SHOULD normally not be Null \\[1\\] and Numbers SHOULD NOT contain fractional parts \\[2\\]\n\nThe Server MUST reply with the same value in the Response object if included. This member is used to correlate the context between the two objects.\n\n\\[1\\] The use of Null as a value for the id member in a Request object is discouraged, because this specification uses a value of Null for Responses with an unknown id. Also, because JSON-RPC 1.0 uses an id value of Null for Notifications this could cause confusion in handling.\n\n\\[2\\] Fractional parts may be problematic, since many decimal fractions cannot be represented exactly as binary fractions.",
  identifier: "RequestId",
});

export type PermissionOptionId = string;
export const PermissionOptionId = Schema.String.annotate({
  description: "Unique identifier for a permission option.",
  identifier: "PermissionOptionId",
});

export type PermissionOptionKind = "allow_once" | "allow_always" | "reject_once" | "reject_always";
export const PermissionOptionKind = Schema.Union([
  Schema.Literal("allow_once").annotate({ description: "Allow this operation only this time." }),
  Schema.Literal("allow_always").annotate({
    description: "Allow this operation and remember the choice.",
  }),
  Schema.Literal("reject_once").annotate({ description: "Reject this operation only this time." }),
  Schema.Literal("reject_always").annotate({
    description: "Reject this operation and remember the choice.",
  }),
]).annotate({
  description:
    "The type of permission option being presented to the user.\n\nHelps clients choose appropriate icons and UI treatment.",
  identifier: "PermissionOptionKind",
});

export type EnvVariable = {
  readonly name: string;
  readonly value: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const EnvVariable = Schema.Struct({
  name: Schema.String.annotate({ description: "The name of the environment variable." }),
  value: Schema.String.annotate({ description: "The value to set for the environment variable." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "An environment variable to set when launching an MCP server.",
  identifier: "EnvVariable",
});

export type ElicitationSchemaType = "object";
export const ElicitationSchemaType = Schema.Union([
  Schema.Literal("object").annotate({ description: "Object schema type." }),
]).annotate({
  description: "Type discriminator for elicitation schemas.",
  identifier: "ElicitationSchemaType",
});

export type StringFormat = "email" | "uri" | "date" | "date-time";
export const StringFormat = Schema.Union([
  Schema.Literal("email").annotate({ description: "Email address format." }),
  Schema.Literal("uri").annotate({ description: "URI format." }),
  Schema.Literal("date").annotate({ description: "Date format (YYYY-MM-DD)." }),
  Schema.Literal("date-time").annotate({ description: "Date-time format (ISO 8601)." }),
]).annotate({
  description: "String format types for string properties in elicitation schemas.",
  identifier: "StringFormat",
});

export type EnumOption = {
  readonly const: string;
  readonly title: string;
  readonly description?: string | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const EnumOption = Schema.Struct({
  const: Schema.String.annotate({ description: "The constant value for this option." }),
  title: Schema.String.annotate({ description: "Human-readable title for this option." }),
  description: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "Human-readable description.\n\nOptional. Omitted and `null` are equivalent and mean no description is provided.",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "A titled enum option with a const value, human-readable title, and optional description.",
  identifier: "EnumOption",
});

export type TitledMultiSelectItems = never;
export const TitledMultiSelectItems = Schema.Never.annotate({
  description: "Items definition for titled multi-select enum properties.",
  identifier: "TitledMultiSelectItems",
});

export type McpServerAcpId = string;
export const McpServerAcpId = Schema.String.annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nUnique identifier for an MCP server using the ACP transport.\n\nThe value is opaque and generated by the ACP component providing the MCP server. It is\nused by `mcp/connect` to route connection requests back to the component that declared the\nserver.",
  identifier: "McpServerAcpId",
});

export type ExtRequest = Schema.Json;
export const ExtRequest = Schema.Json.annotate({
  expected: "JSON value",
  description:
    "Allows for sending an arbitrary request that is not part of the ACP spec.\nExtension methods provide a way to add custom functionality while maintaining\nprotocol compatibility.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
  identifier: "ExtRequest",
});

export type ProtocolVersion = number;
export const ProtocolVersion = Schema.Number.annotate({
  description:
    "Protocol version identifier.\n\nThis version is only bumped for breaking changes.\nNon-breaking changes should be introduced via capabilities.",
  format: "uint16",
})
  .check(Schema.isInt().annotate({ expected: "an integer" }))
  .check(
    Schema.isGreaterThanOrEqualTo(0).annotate({ expected: "a value greater than or equal to 0" }),
  )
  .check(
    Schema.isLessThanOrEqualTo(65535).annotate({
      expected: "a value less than or equal to 65535",
      identifier: "ProtocolVersion",
    }),
  );

export type AuthMethodId = string;
export const AuthMethodId = Schema.String.annotate({
  description: "Typed identifier used for auth method values on the wire.",
  identifier: "AuthMethodId",
});

export type Implementation = {
  readonly name: string;
  readonly title?: string | null;
  readonly version: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const Implementation = Schema.Struct({
  name: Schema.String.annotate({
    description:
      "Intended for programmatic or logical use, but can be used as a display\nname fallback if title isn’t present.",
  }),
  title: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "Intended for UI and end-user contexts — optimized to be human-readable\nand easily understood.\n\nIf not provided, the name should be used for display.",
      }),
      Schema.Null,
    ]),
  ),
  version: Schema.String.annotate({
    description:
      'Version of the implementation. Can be displayed to the user or used\nfor debugging or metrics purposes. (e.g. "1.0.0").',
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Metadata about the implementation of the client or agent.\nDescribes the name and version of an ACP implementation, with an optional\ntitle for UI representation.",
  identifier: "Implementation",
});

export type AuthenticateResponse = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const AuthenticateResponse = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Response to the `authenticate` method.",
  identifier: "AuthenticateResponse",
});

export type ProviderId = string;
export const ProviderId = Schema.String.annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nUnique identifier for a configurable LLM provider.",
  identifier: "ProviderId",
});

export type LlmProtocol = "anthropic" | "openai" | "azure" | "vertex" | "bedrock" | string;
export const LlmProtocol = Schema.Union([
  Schema.Literal("anthropic").annotate({ description: "Anthropic API protocol." }),
  Schema.Literal("openai").annotate({ description: "OpenAI API protocol." }),
  Schema.Literal("azure").annotate({ description: "Azure OpenAI API protocol." }),
  Schema.Literal("vertex").annotate({ description: "Google Vertex AI API protocol." }),
  Schema.Literal("bedrock").annotate({ description: "AWS Bedrock API protocol." }),
  Schema.String.annotate({ title: "other", description: "Unknown or custom protocol." }),
]).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nWell-known API protocol identifiers for LLM providers.\n\nAgents and clients MUST handle unknown protocol identifiers gracefully.\n\nProtocol names beginning with `_` are free for custom use, like other ACP extension methods.\nProtocol names that do not begin with `_` are reserved for the ACP spec.",
  identifier: "LlmProtocol",
});

export type SetProviderResponse = { readonly _meta?: { readonly [x: string]: Schema.Json } | null };
export const SetProviderResponse = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nResponse to `providers/set`.",
  identifier: "SetProviderResponse",
});

export type DisableProviderResponse = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const DisableProviderResponse = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nResponse to `providers/disable`.",
  identifier: "DisableProviderResponse",
});

export type LogoutResponse = { readonly _meta?: { readonly [x: string]: Schema.Json } | null };
export const LogoutResponse = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "Response to the `logout` method.", identifier: "LogoutResponse" });

export type DeleteSessionResponse = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const DeleteSessionResponse = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Response from deleting a session.",
  identifier: "DeleteSessionResponse",
});

export type CloseSessionResponse = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const CloseSessionResponse = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Response from closing a session.",
  identifier: "CloseSessionResponse",
});

export type SetSessionModeResponse = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SetSessionModeResponse = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Response to `session/set_mode` method.",
  identifier: "SetSessionModeResponse",
});

export type StopReason = "end_turn" | "max_tokens" | "max_turn_requests" | "refusal" | "cancelled";
export const StopReason = Schema.Union([
  Schema.Literal("end_turn").annotate({ description: "The turn ended successfully." }),
  Schema.Literal("max_tokens").annotate({
    description: "The turn ended because the agent reached the maximum number of tokens.",
  }),
  Schema.Literal("max_turn_requests").annotate({
    description:
      "The turn ended because the agent reached the maximum number of allowed\nagent requests between user turns.",
  }),
  Schema.Literal("refusal").annotate({
    description:
      "The turn ended because the agent refused to continue. The user prompt\nand everything that comes after it won't be included in the next\nprompt, so this should be reflected in the UI.",
  }),
  Schema.Literal("cancelled").annotate({
    description:
      "The turn was cancelled by the client via `session/cancel`.\n\nThis stop reason MUST be returned when the client sends a `session/cancel`\nnotification, even if the cancellation causes exceptions in underlying operations.\nAgents should catch these exceptions and return this semantically meaningful\nresponse to confirm successful cancellation.",
  }),
]).annotate({
  description:
    "Reasons why an agent stops processing a prompt turn.\n\nSee protocol docs: [Stop Reasons](https://agentclientprotocol.com/protocol/prompt-turn#stop-reasons)",
  identifier: "StopReason",
});

export type Usage = {
  readonly totalTokens: number;
  readonly inputTokens: number;
  readonly outputTokens: number;
  readonly thoughtTokens?: number | null;
  readonly cachedReadTokens?: number | null;
  readonly cachedWriteTokens?: number | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const Usage = Schema.Struct({
  totalTokens: Schema.Number.annotate({
    description: "Sum of all token types across session.",
    format: "uint64",
  })
    .check(Schema.isInt().annotate({ expected: "an integer" }))
    .check(
      Schema.isGreaterThanOrEqualTo(0).annotate({ expected: "a value greater than or equal to 0" }),
    ),
  inputTokens: Schema.Number.annotate({
    description: "Total input tokens across all turns.",
    format: "uint64",
  })
    .check(Schema.isInt().annotate({ expected: "an integer" }))
    .check(
      Schema.isGreaterThanOrEqualTo(0).annotate({ expected: "a value greater than or equal to 0" }),
    ),
  outputTokens: Schema.Number.annotate({
    description: "Total output tokens across all turns.",
    format: "uint64",
  })
    .check(Schema.isInt().annotate({ expected: "an integer" }))
    .check(
      Schema.isGreaterThanOrEqualTo(0).annotate({ expected: "a value greater than or equal to 0" }),
    ),
  thoughtTokens: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({ description: "Total thought/reasoning tokens", format: "uint64" })
        .check(Schema.isInt().annotate({ expected: "an integer" }))
        .check(
          Schema.isGreaterThanOrEqualTo(0).annotate({
            expected: "a value greater than or equal to 0",
          }),
        ),
      Schema.Null,
    ]),
  ),
  cachedReadTokens: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({ description: "Total cache read tokens.", format: "uint64" })
        .check(Schema.isInt().annotate({ expected: "an integer" }))
        .check(
          Schema.isGreaterThanOrEqualTo(0).annotate({
            expected: "a value greater than or equal to 0",
          }),
        ),
      Schema.Null,
    ]),
  ),
  cachedWriteTokens: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({ description: "Total cache write tokens.", format: "uint64" })
        .check(Schema.isInt().annotate({ expected: "an integer" }))
        .check(
          Schema.isGreaterThanOrEqualTo(0).annotate({
            expected: "a value greater than or equal to 0",
          }),
        ),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nToken usage information for a prompt turn.",
  identifier: "Usage",
});

export type Position = {
  readonly line: number;
  readonly character: number;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const Position = Schema.Struct({
  line: Schema.Number.annotate({ description: "Zero-based line number.", format: "uint32" })
    .check(Schema.isInt().annotate({ expected: "an integer" }))
    .check(
      Schema.isGreaterThanOrEqualTo(0).annotate({ expected: "a value greater than or equal to 0" }),
    ),
  character: Schema.Number.annotate({
    description: "Zero-based character offset (encoding-dependent).",
    format: "uint32",
  })
    .check(Schema.isInt().annotate({ expected: "an integer" }))
    .check(
      Schema.isGreaterThanOrEqualTo(0).annotate({ expected: "a value greater than or equal to 0" }),
    ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "A zero-based position in a text document.\n\nThe meaning of `character` depends on the negotiated position encoding.",
  identifier: "Position",
});

export type CloseNesResponse = { readonly _meta?: { readonly [x: string]: Schema.Json } | null };
export const CloseNesResponse = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Response from closing an NES session.",
  identifier: "CloseNesResponse",
});

export type ExtResponse = Schema.Json;
export const ExtResponse = Schema.Json.annotate({
  expected: "JSON value",
  description:
    "Allows for sending an arbitrary response to an [`ExtRequest`] that is not part of the ACP spec.\nExtension methods provide a way to add custom functionality while maintaining\nprotocol compatibility.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
  identifier: "ExtResponse",
});

export type MessageMcpResponse = Schema.Json;
export const MessageMcpResponse = Schema.Json.annotate({
  expected: "JSON value",
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nResponse to `mcp/message`.\n\nThis is the inner MCP response result payload. Any JSON value is valid.",
  identifier: "MessageMcpResponse",
});

export type ErrorCode =
  | -32700
  | -32600
  | -32601
  | -32602
  | -32603
  | -32800
  | -32000
  | -32002
  | number;
export const ErrorCode = Schema.Union([
  Schema.Literal(-32700).annotate({
    title: "Parse error",
    description:
      "**Parse error**: Invalid JSON was received by the server.\nAn error occurred on the server while parsing the JSON text.",
    format: "int32",
  }),
  Schema.Literal(-32600).annotate({
    title: "Invalid request",
    description: "**Invalid request**: The JSON sent is not a valid Request object.",
    format: "int32",
  }),
  Schema.Literal(-32601).annotate({
    title: "Method not found",
    description: "**Method not found**: The method does not exist or is not available.",
    format: "int32",
  }),
  Schema.Literal(-32602).annotate({
    title: "Invalid params",
    description: "**Invalid params**: Invalid method parameter(s).",
    format: "int32",
  }),
  Schema.Literal(-32603).annotate({
    title: "Internal error",
    description:
      "**Internal error**: Internal JSON-RPC error.\nReserved for implementation-defined server errors.",
    format: "int32",
  }),
  Schema.Literal(-32800).annotate({
    title: "Request cancelled",
    description:
      "**Request cancelled**: Execution of the method was aborted either due to a cancellation request from the caller or\nbecause of resource constraints or shutdown.",
    format: "int32",
  }),
  Schema.Literal(-32000).annotate({
    title: "Authentication required",
    description:
      "**Authentication required**: Authentication is required before this operation can be performed.",
    format: "int32",
  }),
  Schema.Literal(-32002).annotate({
    title: "Resource not found",
    description: "**Resource not found**: A given resource, such as a file, was not found.",
    format: "int32",
  }),
  Schema.Number.annotate({
    title: "Other",
    description: "Other undefined error code.",
    format: "int32",
  }).check(Schema.isInt().annotate({ expected: "an integer" })),
]).annotate({
  description:
    "Predefined error codes for common JSON-RPC and ACP-specific errors.\n\nThese codes follow the JSON-RPC 2.0 specification for standard errors\nand use the reserved range (-32000 to -32099) for protocol-specific errors.",
  identifier: "ErrorCode",
});

export type FileSystemCapabilities = {
  readonly readTextFile?: boolean;
  readonly writeTextFile?: boolean;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const FileSystemCapabilities = Schema.Struct({
  readTextFile: Schema.optionalKey(
    Schema.Boolean.annotate({
      description: "Whether the Client supports `fs/read_text_file` requests.",
      default: false,
    }),
  ),
  writeTextFile: Schema.optionalKey(
    Schema.Boolean.annotate({
      description: "Whether the Client supports `fs/write_text_file` requests.",
      default: false,
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "File system capabilities that a client may support.\n\nSee protocol docs: [FileSystem](https://agentclientprotocol.com/protocol/initialization#filesystem)",
  identifier: "FileSystemCapabilities",
});

export type CompactionCapabilities = { readonly [x: string]: never };
export const CompactionCapabilities = Schema.Record(Schema.String, Schema.Never).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nClient support for ID-addressed context compaction updates.",
  identifier: "CompactionCapabilities",
});

export type BooleanConfigOptionCapabilities = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const BooleanConfigOptionCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Capabilities for boolean session configuration options.\n\nSupplying `{}` means the client supports boolean session configuration options.",
  identifier: "BooleanConfigOptionCapabilities",
});

export type PlanCapabilities = { readonly _meta?: { readonly [x: string]: Schema.Json } | null };
export const PlanCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nCapabilities for receiving `plan_update` and `plan_removed` session updates.",
  identifier: "PlanCapabilities",
});

export type AuthCapabilities = {
  readonly terminal?: boolean;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const AuthCapabilities = Schema.Struct({
  terminal: Schema.optionalKey(
    Schema.Boolean.annotate({
      description:
        "Whether the client supports `terminal` authentication methods.\n\nThe client should set this to `true` only when it can reproduce the\nconfigured agent invocation in an interactive terminal. When `true`, the\nagent may include `terminal` entries in its authentication methods.",
      default: false,
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Authentication capabilities supported by the client.\n\nAdvertised during initialization to inform the agent which authentication\nmethod types the client can handle. This governs opt-in types that require\nadditional client-side support.",
  identifier: "AuthCapabilities",
});

export type ElicitationFormCapabilities = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ElicitationFormCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Form-based elicitation capabilities.\n\nSupplying `{}` means the client supports form-based elicitation.",
  identifier: "ElicitationFormCapabilities",
});

export type ElicitationUrlCapabilities = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ElicitationUrlCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "URL-based elicitation capabilities.\n\nSupplying `{}` means the client supports URL-based elicitation.",
  identifier: "ElicitationUrlCapabilities",
});

export type NesJumpCapabilities = { readonly _meta?: { readonly [x: string]: Schema.Json } | null };
export const NesJumpCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Marker for jump suggestion support.",
  identifier: "NesJumpCapabilities",
});

export type NesRenameCapabilities = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesRenameCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Marker for rename suggestion support.",
  identifier: "NesRenameCapabilities",
});

export type NesSearchAndReplaceCapabilities = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesSearchAndReplaceCapabilities = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Marker for search and replace suggestion support.",
  identifier: "NesSearchAndReplaceCapabilities",
});

export type NesRejectReason = "rejected" | "ignored" | "replaced" | "cancelled";
export const NesRejectReason = Schema.Union([
  Schema.Literal("rejected").annotate({
    description: "The user explicitly dismissed the suggestion.",
  }),
  Schema.Literal("ignored").annotate({
    description: "The suggestion was shown but the user continued editing without interacting.",
  }),
  Schema.Literal("replaced").annotate({
    description: "The suggestion was superseded by a newer suggestion.",
  }),
  Schema.Literal("cancelled").annotate({
    description: "The request was cancelled before the agent returned a response.",
  }),
]).annotate({
  description: "The reason a suggestion was rejected.",
  identifier: "NesRejectReason",
});

export type ListProvidersRequest = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ListProvidersRequest = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nRequest parameters for `providers/list`.",
  identifier: "ListProvidersRequest",
});

export type LogoutRequest = { readonly _meta?: { readonly [x: string]: Schema.Json } | null };
export const LogoutRequest = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Request parameters for the logout method.\n\nTerminates the current authenticated session.",
  identifier: "LogoutRequest",
});

export type HttpHeader = {
  readonly name: string;
  readonly value: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const HttpHeader = Schema.Struct({
  name: Schema.String.annotate({ description: "The name of the HTTP header." }),
  value: Schema.String.annotate({ description: "The value to set for the HTTP header." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "An HTTP header to set when making requests to the MCP server.",
  identifier: "HttpHeader",
});

export type ListSessionsRequest = {
  readonly cwd?: string | null;
  readonly cursor?: string | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ListSessionsRequest = Schema.Struct({
  cwd: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description: "Filter sessions by working directory. Must be an absolute path.",
      }),
      Schema.Null,
    ]),
  ),
  cursor: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "Opaque cursor token from a previous response's nextCursor field for cursor-based pagination",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Request parameters for listing existing sessions.\n\nOnly available if the Agent supports the `sessionCapabilities.list` capability.",
  identifier: "ListSessionsRequest",
});

export type WorkspaceFolder = {
  readonly uri: string;
  readonly name: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const WorkspaceFolder = Schema.Struct({
  uri: Schema.String.annotate({ description: "The URI of the folder." }),
  name: Schema.String.annotate({ description: "The display name of the folder." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "A workspace folder.", identifier: "WorkspaceFolder" });

export type NesRepository = {
  readonly name: string;
  readonly owner: string;
  readonly remoteUrl: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesRepository = Schema.Struct({
  name: Schema.String.annotate({ description: "The repository name." }),
  owner: Schema.String.annotate({ description: "The repository owner." }),
  remoteUrl: Schema.String.annotate({ description: "The remote URL of the repository." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Repository metadata for an NES session.",
  identifier: "NesRepository",
});

export type NesTriggerKind = "automatic" | "diagnostic" | "manual";
export const NesTriggerKind = Schema.Union([
  Schema.Literal("automatic").annotate({
    description: "Triggered by user typing or cursor movement.",
  }),
  Schema.Literal("diagnostic").annotate({
    description: "Triggered by a diagnostic appearing at or near the cursor.",
  }),
  Schema.Literal("manual").annotate({
    description: "Triggered by an explicit user action (keyboard shortcut).",
  }),
]).annotate({
  description: "What triggered the suggestion request.",
  identifier: "NesTriggerKind",
});

export type NesRecentFile = {
  readonly uri: string;
  readonly languageId: string;
  readonly text: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesRecentFile = Schema.Struct({
  uri: Schema.String.annotate({ description: "The URI of the file." }),
  languageId: Schema.String.annotate({ description: "The language identifier." }),
  text: Schema.String.annotate({ description: "The full text content of the file." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "A recently accessed file.", identifier: "NesRecentFile" });

export type NesExcerpt = {
  readonly startLine: number;
  readonly endLine: number;
  readonly text: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesExcerpt = Schema.Struct({
  startLine: Schema.Number.annotate({
    description: "The start line of the excerpt (zero-based).",
    format: "uint32",
  })
    .check(Schema.isInt().annotate({ expected: "an integer" }))
    .check(
      Schema.isGreaterThanOrEqualTo(0).annotate({ expected: "a value greater than or equal to 0" }),
    ),
  endLine: Schema.Number.annotate({
    description: "The end line of the excerpt (zero-based).",
    format: "uint32",
  })
    .check(Schema.isInt().annotate({ expected: "an integer" }))
    .check(
      Schema.isGreaterThanOrEqualTo(0).annotate({ expected: "a value greater than or equal to 0" }),
    ),
  text: Schema.String.annotate({ description: "The text content of the excerpt." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "A code excerpt from a file.", identifier: "NesExcerpt" });

export type NesEditHistoryEntry = {
  readonly uri: string;
  readonly diff: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesEditHistoryEntry = Schema.Struct({
  uri: Schema.String.annotate({ description: "The URI of the edited file." }),
  diff: Schema.String.annotate({ description: "A diff representing the edit." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "An entry in the edit history.", identifier: "NesEditHistoryEntry" });

export type NesDiagnosticSeverity = "error" | "warning" | "information" | "hint";
export const NesDiagnosticSeverity = Schema.Union([
  Schema.Literal("error").annotate({ description: "An error." }),
  Schema.Literal("warning").annotate({ description: "A warning." }),
  Schema.Literal("information").annotate({ description: "An informational message." }),
  Schema.Literal("hint").annotate({ description: "A hint." }),
]).annotate({ description: "Severity of a diagnostic.", identifier: "NesDiagnosticSeverity" });

export type WriteTextFileResponse = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const WriteTextFileResponse = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Response to `fs/write_text_file`",
  identifier: "WriteTextFileResponse",
});

export type ReadTextFileResponse = {
  readonly content: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ReadTextFileResponse = Schema.Struct({
  content: Schema.String.annotate({ description: "Content payload returned by this response." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Response containing the contents of a text file.",
  identifier: "ReadTextFileResponse",
});

export type TerminalExitStatus = {
  readonly exitCode?: number | null;
  readonly signal?: string | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const TerminalExitStatus = Schema.Struct({
  exitCode: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description: "The process exit code (may be null if terminated by signal).",
        format: "uint32",
      })
        .check(Schema.isInt().annotate({ expected: "an integer" }))
        .check(
          Schema.isGreaterThanOrEqualTo(0).annotate({
            expected: "a value greater than or equal to 0",
          }),
        ),
      Schema.Null,
    ]),
  ),
  signal: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description: "The signal that terminated the process (may be null if exited normally).",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Exit status of a terminal command.",
  identifier: "TerminalExitStatus",
});

export type ReleaseTerminalResponse = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ReleaseTerminalResponse = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Response to terminal/release method",
  identifier: "ReleaseTerminalResponse",
});

export type WaitForTerminalExitResponse = {
  readonly exitCode?: number | null;
  readonly signal?: string | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const WaitForTerminalExitResponse = Schema.Struct({
  exitCode: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description: "The process exit code (may be null if terminated by signal).",
        format: "uint32",
      })
        .check(Schema.isInt().annotate({ expected: "an integer" }))
        .check(
          Schema.isGreaterThanOrEqualTo(0).annotate({
            expected: "a value greater than or equal to 0",
          }),
        ),
      Schema.Null,
    ]),
  ),
  signal: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description: "The signal that terminated the process (may be null if exited normally).",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Response containing the exit status of a terminal command.",
  identifier: "WaitForTerminalExitResponse",
});

export type KillTerminalResponse = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const KillTerminalResponse = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Response to `terminal/kill` method",
  identifier: "KillTerminalResponse",
});

export type ElicitationContentValue = string | number | number | boolean | ReadonlyArray<string>;
export const ElicitationContentValue = Schema.Union([
  Schema.String.annotate({
    title: "String",
    description: "String value accepted in elicitation response content.",
  }),
  Schema.Number.annotate({
    title: "Integer",
    description: "Integer value accepted in elicitation response content.",
    format: "int64",
  }).check(Schema.isInt().annotate({ expected: "an integer" })),
  Schema.Number.annotate({
    title: "Number",
    description: "Number value accepted in elicitation response content.",
    format: "double",
  }).check(Schema.isFinite().annotate({ expected: "a finite number" })),
  Schema.Boolean.annotate({
    title: "Boolean",
    description: "Boolean value accepted in elicitation response content.",
  }),
  Schema.Array(Schema.String).annotate({
    title: "StringArray",
    description: "String array value accepted in elicitation response content.",
  }),
]).annotate({
  description: "Allowed wire representations for [`ElicitationContentValue`].",
  identifier: "ElicitationContentValue",
});

export type DisconnectMcpResponse = {
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const DisconnectMcpResponse = Schema.Struct({
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nResponse to `mcp/disconnect`.",
  identifier: "DisconnectMcpResponse",
});

export type WriteTextFileRequest = {
  readonly sessionId: SessionId;
  readonly path: string;
  readonly content: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const WriteTextFileRequest = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The session ID for this request.",
  }),
  path: Schema.String.annotate({ description: "Absolute path to the file to write." }),
  content: Schema.String.annotate({ description: "The text content to write to the file." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Request to write content to a text file.\n\nOnly available if the client supports the `fs.writeTextFile` capability.",
  identifier: "WriteTextFileRequest",
});

export type ReadTextFileRequest = {
  readonly sessionId: SessionId;
  readonly path: string;
  readonly line?: number | null;
  readonly limit?: number | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ReadTextFileRequest = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The session ID for this request.",
  }),
  path: Schema.String.annotate({ description: "Absolute path to the file to read." }),
  line: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description: "Line number to start reading from (1-based).",
        format: "uint32",
      })
        .check(Schema.isInt().annotate({ expected: "an integer" }))
        .check(
          Schema.isGreaterThanOrEqualTo(0).annotate({
            expected: "a value greater than or equal to 0",
          }),
        ),
      Schema.Null,
    ]),
  ),
  limit: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({ description: "Maximum number of lines to read.", format: "uint32" })
        .check(Schema.isInt().annotate({ expected: "an integer" }))
        .check(
          Schema.isGreaterThanOrEqualTo(0).annotate({
            expected: "a value greater than or equal to 0",
          }),
        ),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Request to read content from a text file.\n\nOnly available if the client supports the `fs.readTextFile` capability.",
  identifier: "ReadTextFileRequest",
});

export type SessionInfo = {
  readonly sessionId: SessionId;
  readonly cwd: string;
  readonly additionalDirectories?: ReadonlyArray<string>;
  readonly title?: string | null;
  readonly updatedAt?: string | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SessionInfo = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "Unique identifier for the session",
  }),
  cwd: Schema.String.annotate({
    description: "The working directory for this session. Must be an absolute path.",
  }),
  additionalDirectories: Schema.optionalKey(
    Schema.Array(Schema.String).annotate({
      description:
        "Additional workspace roots reported for this session. Each path must be absolute.\n\nWhen present, this is the complete ordered additional-root list reported\nby the Agent. Omitted and empty values are equivalent: the response\nreports no additional roots.",
    }),
  ),
  title: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({ description: "Human-readable title for the session" }),
      Schema.Null,
    ]),
  ),
  updatedAt: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({ description: "ISO 8601 timestamp of last activity" }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Information about a session returned by session/list",
  identifier: "SessionInfo",
});

export type StartNesResponse = {
  readonly sessionId: SessionId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const StartNesResponse = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The session ID for the newly started NES session.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "Response to `nes/start`.", identifier: "StartNesResponse" });

export type CancelNotification = {
  readonly sessionId: SessionId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const CancelNotification = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The ID of the session to cancel operations for.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Notification to cancel ongoing operations for a session.\n\nSee protocol docs: [Cancellation](https://agentclientprotocol.com/protocol/prompt-turn#cancellation)",
  identifier: "CancelNotification",
});

export type DidOpenDocumentNotification = {
  readonly sessionId: SessionId;
  readonly uri: string;
  readonly languageId: string;
  readonly version: number;
  readonly text: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const DidOpenDocumentNotification = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The session ID for this notification.",
  }),
  uri: Schema.String.annotate({ description: "The URI of the opened document." }),
  languageId: Schema.String.annotate({
    description: 'The language identifier of the document (e.g., "rust", "python").',
  }),
  version: Schema.Number.annotate({
    description: "The version number of the document.",
    format: "int64",
  }).check(Schema.isInt().annotate({ expected: "an integer" })),
  text: Schema.String.annotate({ description: "The full text content of the document." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Notification sent when a file is opened in the editor.",
  identifier: "DidOpenDocumentNotification",
});

export type DidCloseDocumentNotification = {
  readonly sessionId: SessionId;
  readonly uri: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const DidCloseDocumentNotification = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The session ID for this notification.",
  }),
  uri: Schema.String.annotate({ description: "The URI of the closed document." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Notification sent when a file is closed.",
  identifier: "DidCloseDocumentNotification",
});

export type DidSaveDocumentNotification = {
  readonly sessionId: SessionId;
  readonly uri: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const DidSaveDocumentNotification = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The session ID for this notification.",
  }),
  uri: Schema.String.annotate({ description: "The URI of the saved document." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Notification sent when a file is saved.",
  identifier: "DidSaveDocumentNotification",
});

export type DeleteSessionRequest = {
  readonly sessionId: SessionId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const DeleteSessionRequest = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The ID of the session to delete.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Request parameters for deleting an existing session from `session/list`.\n\nOnly available if the Agent supports the `sessionCapabilities.delete` capability.",
  identifier: "DeleteSessionRequest",
});

export type CloseSessionRequest = {
  readonly sessionId: SessionId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const CloseSessionRequest = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The ID of the session to close.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Request parameters for closing an active session.\n\nIf supported, the agent **must** cancel any ongoing work related to the session\n(treat it as if `session/cancel` was called) and then free up any resources\nassociated with the session.\n\nOnly available if the Agent supports the `sessionCapabilities.close` capability.",
  identifier: "CloseSessionRequest",
});

export type CloseNesRequest = {
  readonly sessionId: SessionId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const CloseNesRequest = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The ID of the NES session to close.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Request to close an NES session.\n\nThe agent **must** cancel any ongoing work related to the NES session\nand then free up any resources associated with the session.",
  identifier: "CloseNesRequest",
});

export type AcceptNesNotification = {
  readonly sessionId: SessionId;
  readonly id: NesSuggestionId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const AcceptNesNotification = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The session ID for this notification.",
  }),
  id: Schema.suspend((): Schema.Codec<NesSuggestionId> => NesSuggestionId).annotate({
    description: "The ID of the accepted suggestion.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Notification sent when a suggestion is accepted.",
  identifier: "AcceptNesNotification",
});

export type AgentAuthCapabilities = {
  readonly logout?: LogoutCapabilities | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const AgentAuthCapabilities = Schema.Struct({
  logout: Schema.optionalKey(
    Schema.Union([LogoutCapabilities, Schema.Null]).annotate({
      description:
        "Whether the agent supports the logout method.\n\nOptional. Omitted or `null` both mean the agent does not advertise support.\nSupplying `{}` means the agent supports the logout method.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Authentication-related capabilities supported by the agent.",
  identifier: "AgentAuthCapabilities",
});

export type SessionCapabilities = {
  readonly list?: SessionListCapabilities | null;
  readonly delete?: SessionDeleteCapabilities | null;
  readonly additionalDirectories?: SessionAdditionalDirectoriesCapabilities | null;
  readonly fork?: SessionForkCapabilities | null;
  readonly resume?: SessionResumeCapabilities | null;
  readonly close?: SessionCloseCapabilities | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SessionCapabilities = Schema.Struct({
  list: Schema.optionalKey(
    Schema.Union([SessionListCapabilities, Schema.Null]).annotate({
      description:
        "Whether the agent supports `session/list`.\n\nOptional. Omitted or `null` both mean the agent does not advertise support.\nSupplying `{}` means the agent supports listing sessions.",
    }),
  ),
  delete: Schema.optionalKey(
    Schema.Union([SessionDeleteCapabilities, Schema.Null]).annotate({
      description:
        "Whether the agent supports `session/delete`.\n\nOptional. Omitted or `null` both mean the agent does not advertise support.\nSupplying `{}` means the agent supports deleting sessions from `session/list`.",
    }),
  ),
  additionalDirectories: Schema.optionalKey(
    Schema.Union([SessionAdditionalDirectoriesCapabilities, Schema.Null]).annotate({
      description:
        "Whether the agent supports `additionalDirectories` on supported session lifecycle requests.\n\nOptional. Omitted or `null` both mean the agent does not advertise support.\nSupplying `{}` means the agent supports `additionalDirectories` on\nsupported session lifecycle requests.\n\nAgents that also support `session/list` may return\n`SessionInfo.additionalDirectories` to report the complete ordered\nadditional-root list associated with a listed session.",
    }),
  ),
  fork: Schema.optionalKey(
    Schema.Union([SessionForkCapabilities, Schema.Null]).annotate({
      description:
        "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nWhether the agent supports `session/fork`.\n\nOptional. Omitted or `null` both mean the agent does not advertise support.\nSupplying `{}` means the agent supports forking sessions.",
    }),
  ),
  resume: Schema.optionalKey(
    Schema.Union([SessionResumeCapabilities, Schema.Null]).annotate({
      description:
        "Whether the agent supports `session/resume`.\n\nOptional. Omitted or `null` both mean the agent does not advertise support.\nSupplying `{}` means the agent supports resuming sessions.",
    }),
  ),
  close: Schema.optionalKey(
    Schema.Union([SessionCloseCapabilities, Schema.Null]).annotate({
      description:
        "Whether the agent supports `session/close`.\n\nOptional. Omitted or `null` both mean the agent does not advertise support.\nSupplying `{}` means the agent supports closing sessions.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Session capabilities supported by the agent.\n\nAs a baseline, all Agents **MUST** support `session/new`, `session/prompt`, `session/cancel`, and `session/update`.\n\nOptionally, they **MAY** support other session methods and notifications by specifying additional capabilities.\n\nNote: `session/load` is still handled by the top-level `load_session` capability. This will be unified in future versions of the protocol.\n\nSee protocol docs: [Session Capabilities](https://agentclientprotocol.com/protocol/initialization#session-capabilities)",
  identifier: "SessionCapabilities",
});

export type NesDocumentDidChangeCapabilities = {
  readonly syncKind: TextDocumentSyncKind;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesDocumentDidChangeCapabilities = Schema.Struct({
  syncKind: Schema.suspend((): Schema.Codec<TextDocumentSyncKind> => TextDocumentSyncKind).annotate(
    { description: 'The sync kind the agent wants: `"full"` or `"incremental"`.' },
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Capabilities for `document/didChange` events.",
  identifier: "NesDocumentDidChangeCapabilities",
});

export type NesContextCapabilities = {
  readonly recentFiles?: NesRecentFilesCapabilities | null;
  readonly relatedSnippets?: NesRelatedSnippetsCapabilities | null;
  readonly editHistory?: NesEditHistoryCapabilities | null;
  readonly userActions?: NesUserActionsCapabilities | null;
  readonly openFiles?: NesOpenFilesCapabilities | null;
  readonly diagnostics?: NesDiagnosticsCapabilities | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesContextCapabilities = Schema.Struct({
  recentFiles: Schema.optionalKey(
    Schema.Union([NesRecentFilesCapabilities, Schema.Null]).annotate({
      description: "Whether the agent wants recent files context.",
    }),
  ),
  relatedSnippets: Schema.optionalKey(
    Schema.Union([NesRelatedSnippetsCapabilities, Schema.Null]).annotate({
      description: "Whether the agent wants related snippets context.",
    }),
  ),
  editHistory: Schema.optionalKey(
    Schema.Union([NesEditHistoryCapabilities, Schema.Null]).annotate({
      description: "Whether the agent wants edit history context.",
    }),
  ),
  userActions: Schema.optionalKey(
    Schema.Union([NesUserActionsCapabilities, Schema.Null]).annotate({
      description: "Whether the agent wants user actions context.",
    }),
  ),
  openFiles: Schema.optionalKey(
    Schema.Union([NesOpenFilesCapabilities, Schema.Null]).annotate({
      description: "Whether the agent wants open files context.",
    }),
  ),
  diagnostics: Schema.optionalKey(
    Schema.Union([NesDiagnosticsCapabilities, Schema.Null]).annotate({
      description: "Whether the agent wants diagnostics context.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Context capabilities the agent wants attached to each suggestion request.",
  identifier: "NesContextCapabilities",
});

export type Annotations = {
  readonly audience?: ReadonlyArray<Role> | null;
  readonly lastModified?: string | null;
  readonly priority?: number | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const Annotations = Schema.Struct({
  audience: Schema.optionalKey(
    Schema.Union([
      Schema.Array(Role).annotate({
        description: "Intended recipients for this content, such as the user or assistant.",
      }),
      Schema.Null,
    ]),
  ),
  lastModified: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description: "Timestamp indicating when the underlying resource was last modified.",
      }),
      Schema.Null,
    ]),
  ),
  priority: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description: "Relative importance of this content when clients choose what to surface.",
        format: "double",
      }).check(Schema.isFinite().annotate({ expected: "a finite number" })),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Optional annotations for the client. The client can use annotations to inform how objects are used or displayed",
  identifier: "Annotations",
});

export type EmbeddedResourceResource = TextResourceContents | BlobResourceContents;
export const EmbeddedResourceResource = Schema.Union([
  Schema.suspend((): Schema.Codec<TextResourceContents> => TextResourceContents).annotate({
    title: "TextResourceContents",
    description: "Text resource contents embedded directly in the message.",
  }),
  Schema.suspend((): Schema.Codec<BlobResourceContents> => BlobResourceContents).annotate({
    title: "BlobResourceContents",
    description: "Binary resource contents embedded directly in the message.",
  }),
]).annotate({
  description: "Resource content that can be embedded in a message.",
  identifier: "EmbeddedResourceResource",
});

export type TerminalOutputRequest = {
  readonly sessionId: SessionId;
  readonly terminalId: TerminalId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const TerminalOutputRequest = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The session ID for this request.",
  }),
  terminalId: Schema.suspend((): Schema.Codec<TerminalId> => TerminalId).annotate({
    description: "The ID of the terminal to get output from.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Request to get the current output and status of a terminal.",
  identifier: "TerminalOutputRequest",
});

export type ReleaseTerminalRequest = {
  readonly sessionId: SessionId;
  readonly terminalId: TerminalId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ReleaseTerminalRequest = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The session ID for this request.",
  }),
  terminalId: Schema.suspend((): Schema.Codec<TerminalId> => TerminalId).annotate({
    description: "The ID of the terminal to release.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Request to release a terminal and free its resources.",
  identifier: "ReleaseTerminalRequest",
});

export type WaitForTerminalExitRequest = {
  readonly sessionId: SessionId;
  readonly terminalId: TerminalId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const WaitForTerminalExitRequest = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The session ID for this request.",
  }),
  terminalId: Schema.suspend((): Schema.Codec<TerminalId> => TerminalId).annotate({
    description: "The ID of the terminal to wait for.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Request to wait for a terminal command to exit.",
  identifier: "WaitForTerminalExitRequest",
});

export type KillTerminalRequest = {
  readonly sessionId: SessionId;
  readonly terminalId: TerminalId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const KillTerminalRequest = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The session ID for this request.",
  }),
  terminalId: Schema.suspend((): Schema.Codec<TerminalId> => TerminalId).annotate({
    description: "The ID of the terminal to kill.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Request to kill a terminal without releasing it.",
  identifier: "KillTerminalRequest",
});

export type CreateTerminalResponse = {
  readonly terminalId: TerminalId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const CreateTerminalResponse = Schema.Struct({
  terminalId: Schema.suspend((): Schema.Codec<TerminalId> => TerminalId).annotate({
    description: "The unique identifier for the created terminal.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Response containing the ID of the created terminal.",
  identifier: "CreateTerminalResponse",
});

export type PlanEntry = {
  readonly content: string;
  readonly priority: PlanEntryPriority;
  readonly status: PlanEntryStatus;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const PlanEntry = Schema.Struct({
  content: Schema.String.annotate({
    description: "Human-readable description of what this task aims to accomplish.",
  }),
  priority: Schema.suspend((): Schema.Codec<PlanEntryPriority> => PlanEntryPriority).annotate({
    description:
      "The relative importance of this task.\nUsed to indicate which tasks are most critical to the overall goal.",
  }),
  status: Schema.suspend((): Schema.Codec<PlanEntryStatus> => PlanEntryStatus).annotate({
    description: "Current execution status of this task.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "A single entry in the execution plan.\n\nRepresents a task or goal that the assistant intends to accomplish\nas part of fulfilling the user's request.\nSee protocol docs: [Plan Entries](https://agentclientprotocol.com/protocol/agent-plan#plan-entries)",
  identifier: "PlanEntry",
});

export type AvailableCommandInput = UnstructuredCommandInput;
export const AvailableCommandInput = Schema.Union([
  Schema.suspend((): Schema.Codec<UnstructuredCommandInput> => UnstructuredCommandInput).annotate({
    title: "unstructured",
    description: "All text that was typed after the command name is provided as input.",
  }),
]).annotate({
  description: "The input specification for a command.",
  identifier: "AvailableCommandInput",
});

export type SessionMode = {
  readonly id: SessionModeId;
  readonly name: string;
  readonly description?: string | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SessionMode = Schema.Struct({
  id: Schema.suspend((): Schema.Codec<SessionModeId> => SessionModeId).annotate({
    description: "Stable identifier used to refer to this protocol object in later messages.",
  }),
  name: Schema.String.annotate({
    description: "Human-readable name shown for this protocol object.",
  }),
  description: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description: "Optional human-readable details shown with this protocol object.",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "A mode the agent can operate in.\n\nSee protocol docs: [Session Modes](https://agentclientprotocol.com/protocol/session-modes)",
  identifier: "SessionMode",
});

export type SetSessionModeRequest = {
  readonly sessionId: SessionId;
  readonly modeId: SessionModeId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SetSessionModeRequest = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The ID of the session to set the mode for.",
  }),
  modeId: Schema.suspend((): Schema.Codec<SessionModeId> => SessionModeId).annotate({
    description: "The ID of the mode to set.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Request parameters for setting a session mode.",
  identifier: "SetSessionModeRequest",
});

export type SessionConfigSelectOption = {
  readonly value: SessionConfigValueId;
  readonly name: string;
  readonly description?: string | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SessionConfigSelectOption = Schema.Struct({
  value: Schema.suspend((): Schema.Codec<SessionConfigValueId> => SessionConfigValueId).annotate({
    description: "Unique identifier for this option value.",
  }),
  name: Schema.String.annotate({ description: "Human-readable label for this option value." }),
  description: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({ description: "Optional description for this option value." }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "A possible value for a session configuration option.",
  identifier: "SessionConfigSelectOption",
});

export type SetSessionConfigOptionRequest =
  | {
      readonly sessionId: SessionId;
      readonly configId: SessionConfigId;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
      readonly value: boolean;
      readonly type: "boolean";
    }
  | {
      readonly sessionId: SessionId;
      readonly configId: SessionConfigId;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
      readonly value: SessionConfigValueId;
    };
export const SetSessionConfigOptionRequest = Schema.Union([
  Schema.Struct({
    sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
      description: "The ID of the session to set the configuration option for.",
    }),
    configId: Schema.suspend((): Schema.Codec<SessionConfigId> => SessionConfigId).annotate({
      description: "The ID of the configuration option to set.",
    }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
    value: Schema.Boolean.annotate({ description: "The boolean value." }),
    type: Schema.Literal("boolean"),
  }).annotate({ description: 'A boolean value (`type: "boolean"`).' }),
  Schema.Struct({
    sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
      description: "The ID of the session to set the configuration option for.",
    }),
    configId: Schema.suspend((): Schema.Codec<SessionConfigId> => SessionConfigId).annotate({
      description: "The ID of the configuration option to set.",
    }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
    value: Schema.suspend((): Schema.Codec<SessionConfigValueId> => SessionConfigValueId).annotate({
      description: "The value ID.",
    }),
  }).annotate({
    title: "value_id",
    description:
      "A [`SessionConfigValueId`] string value.\n\nThis is the default when `type` is absent on the wire. Unknown `type`\nvalues with string payloads also gracefully deserialize into this\nvariant.",
  }),
]).annotate({ identifier: "SetSessionConfigOptionRequest" });

export type CompleteElicitationNotification = {
  readonly elicitationId: ElicitationId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const CompleteElicitationNotification = Schema.Struct({
  elicitationId: Schema.suspend((): Schema.Codec<ElicitationId> => ElicitationId).annotate({
    description: "The ID of the elicitation that completed.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Notification sent by the agent when a URL-based elicitation is complete.",
  identifier: "CompleteElicitationNotification",
});

export type MessageMcpNotification = {
  readonly connectionId: McpConnectionId;
  readonly method: string;
  readonly params?: { readonly [x: string]: Schema.Json } | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const MessageMcpNotification = Schema.Struct({
  connectionId: Schema.suspend((): Schema.Codec<McpConnectionId> => McpConnectionId).annotate({
    description: "The MCP-over-ACP connection this message is sent on.",
  }),
  method: Schema.String.annotate({ description: "The inner MCP method name." }),
  params: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "Optional inner MCP params.\n\nIf omitted or set to `null`, the inner MCP message has no params.",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nNotification parameters for `mcp/message`.\n\nThis is used when the wrapped MCP message is a notification and the outer JSON-RPC\nenvelope has no `id`.",
  identifier: "MessageMcpNotification",
});

export type MessageMcpRequest = {
  readonly connectionId: McpConnectionId;
  readonly method: string;
  readonly params?: { readonly [x: string]: Schema.Json } | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const MessageMcpRequest = Schema.Struct({
  connectionId: Schema.suspend((): Schema.Codec<McpConnectionId> => McpConnectionId).annotate({
    description: "The MCP-over-ACP connection this message is sent on.",
  }),
  method: Schema.String.annotate({ description: "The inner MCP method name." }),
  params: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "Optional inner MCP params.\n\nIf omitted or set to `null`, the inner MCP message has no params.",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nRequest parameters for `mcp/message`.",
  identifier: "MessageMcpRequest",
});

export type DisconnectMcpRequest = {
  readonly connectionId: McpConnectionId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const DisconnectMcpRequest = Schema.Struct({
  connectionId: Schema.suspend((): Schema.Codec<McpConnectionId> => McpConnectionId).annotate({
    description: "The MCP-over-ACP connection to close.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nRequest parameters for `mcp/disconnect`.",
  identifier: "DisconnectMcpRequest",
});

export type ConnectMcpResponse = {
  readonly connectionId: McpConnectionId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ConnectMcpResponse = Schema.Struct({
  connectionId: Schema.suspend((): Schema.Codec<McpConnectionId> => McpConnectionId).annotate({
    description: "The unique identifier for this MCP-over-ACP connection.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nResponse to `mcp/connect`.",
  identifier: "ConnectMcpResponse",
});

export type RequestPermissionOutcome =
  | { readonly outcome: "cancelled" }
  | {
      readonly outcome: "selected";
      readonly optionId: PermissionOptionId;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    };
export const RequestPermissionOutcome = Schema.Union([
  Schema.Struct({ outcome: Schema.Literal("cancelled") }).annotate({
    description:
      "The prompt turn was cancelled before the user responded.\n\nWhen a client sends a `session/cancel` notification to cancel an ongoing\nprompt turn, it MUST respond to all pending `session/request_permission`\nrequests with this `Cancelled` outcome.\n\nSee protocol docs: [Cancellation](https://agentclientprotocol.com/protocol/prompt-turn#cancellation)",
  }),
  Schema.Struct({
    outcome: Schema.Literal("selected"),
    optionId: Schema.suspend((): Schema.Codec<PermissionOptionId> => PermissionOptionId).annotate({
      description: "The ID of the option the user selected.",
    }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "The user selected one of the provided options." }),
]).annotate({
  description: "The outcome of a permission request.",
  identifier: "RequestPermissionOutcome",
});

export type PermissionOption = {
  readonly optionId: PermissionOptionId;
  readonly name: string;
  readonly kind: PermissionOptionKind;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const PermissionOption = Schema.Struct({
  optionId: Schema.suspend((): Schema.Codec<PermissionOptionId> => PermissionOptionId).annotate({
    description: "Unique identifier for this permission option.",
  }),
  name: Schema.String.annotate({ description: "Human-readable label to display to the user." }),
  kind: Schema.suspend((): Schema.Codec<PermissionOptionKind> => PermissionOptionKind).annotate({
    description: "Hint about the nature of this permission option.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "An option presented to the user when requesting permission.",
  identifier: "PermissionOption",
});

export type CreateTerminalRequest = {
  readonly sessionId: SessionId;
  readonly command: string;
  readonly args?: ReadonlyArray<string>;
  readonly env?: ReadonlyArray<EnvVariable>;
  readonly cwd?: string | null;
  readonly outputByteLimit?: number | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const CreateTerminalRequest = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The session ID for this request.",
  }),
  command: Schema.String.annotate({ description: "The command to execute." }),
  args: Schema.optionalKey(
    Schema.Array(Schema.String).annotate({ description: "Array of command arguments." }),
  ),
  env: Schema.optionalKey(
    Schema.Array(EnvVariable).annotate({ description: "Environment variables for the command." }),
  ),
  cwd: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description: "Working directory for the command. Must be an absolute path.",
      }),
      Schema.Null,
    ]),
  ),
  outputByteLimit: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description:
          "Maximum number of output bytes to retain.\n\nWhen the limit is exceeded, the Client truncates from the beginning of the output\nto stay within the limit.\n\nThe Client MUST ensure truncation happens at a character boundary to maintain valid\nstring output, even if this means the retained output is slightly less than the\nspecified limit.",
        format: "uint64",
      })
        .check(Schema.isInt().annotate({ expected: "an integer" }))
        .check(
          Schema.isGreaterThanOrEqualTo(0).annotate({
            expected: "a value greater than or equal to 0",
          }),
        ),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Request to create a new terminal and execute a command.",
  identifier: "CreateTerminalRequest",
});

export type McpServerStdio = {
  readonly name: string;
  readonly command: string;
  readonly args: ReadonlyArray<string>;
  readonly env: ReadonlyArray<EnvVariable>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const McpServerStdio = Schema.Struct({
  name: Schema.String.annotate({ description: "Human-readable name identifying this MCP server." }),
  command: Schema.String.annotate({ description: "Absolute path to the MCP server executable." }),
  args: Schema.Array(Schema.String).annotate({
    description: "Command-line arguments to pass to the MCP server.",
  }),
  env: Schema.Array(EnvVariable).annotate({
    description: "Environment variables to set when launching the MCP server.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Stdio transport configuration for MCP.",
  identifier: "McpServerStdio",
});

export type MultiSelectItems =
  | {
      readonly type: "string";
      readonly enum: ReadonlyArray<string>;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | ({ readonly type: string } & { readonly [x: string]: Schema.Json })
  | TitledMultiSelectItems;
export const MultiSelectItems = Schema.Union([
  Schema.Struct({
    type: Schema.Literal("string"),
    enum: Schema.Array(Schema.String).annotate({ description: "Allowed enum values." }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "String item schema for multi-select enum properties." }),
  Schema.StructWithRest(
    Schema.Struct({
      type: Schema.String.annotate({
        description:
          "Custom or future multi-select item type.\n\nValues beginning with `_` are reserved for implementation-specific\nextensions. Unknown values that do not begin with `_` are reserved for\nfuture ACP variants.",
      }).check(
        Schema.isPattern(new RegExp("^(?!(?:\\x73tring)$)[\\s\\S]*$")).annotate({
          expected: "a string matching the RegExp ^(?!(?:\\x73tring)$)[\\s\\S]*$",
        }),
      ),
    }),
    [Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" }))],
  ).annotate({ title: "other", description: "Custom or future typed multi-select items." }),
  Schema.suspend((): Schema.Codec<TitledMultiSelectItems> => TitledMultiSelectItems).annotate({
    title: "titled",
    description: "Titled multi-select items with human-readable labels.",
  }),
]).annotate({
  description: "Items for a multi-select (array) property schema.",
  identifier: "MultiSelectItems",
});

export type ConnectMcpRequest = {
  readonly serverId: McpServerAcpId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ConnectMcpRequest = Schema.Struct({
  serverId: Schema.suspend((): Schema.Codec<McpServerAcpId> => McpServerAcpId).annotate({
    description:
      "The ACP MCP server ID that was provided by the component declaring the MCP server.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nRequest parameters for `mcp/connect`.",
  identifier: "ConnectMcpRequest",
});

export type AuthMethodAgent = {
  readonly id: AuthMethodId;
  readonly name: string;
  readonly description?: string | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const AuthMethodAgent = Schema.Struct({
  id: Schema.suspend((): Schema.Codec<AuthMethodId> => AuthMethodId).annotate({
    description: "Unique identifier for this authentication method.",
  }),
  name: Schema.String.annotate({
    description: "Human-readable name of the authentication method.",
  }),
  description: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "Optional description providing more details about this authentication method.",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Agent handles authentication itself through `authenticate`.\n\nThis is the default authentication method type.",
  identifier: "AuthMethodAgent",
});

export type AuthenticateRequest = {
  readonly methodId: AuthMethodId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const AuthenticateRequest = Schema.Struct({
  methodId: Schema.suspend((): Schema.Codec<AuthMethodId> => AuthMethodId).annotate({
    description:
      "The ID of the authentication method to use.\nMust be one of the methods advertised in the initialize response.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Request parameters for the authenticate method.\n\nSpecifies which authentication method to use.",
  identifier: "AuthenticateRequest",
});

export type DisableProviderRequest = {
  readonly providerId: ProviderId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const DisableProviderRequest = Schema.Struct({
  providerId: Schema.suspend((): Schema.Codec<ProviderId> => ProviderId).annotate({
    description: "Provider ID to disable.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nRequest parameters for `providers/disable`.",
  identifier: "DisableProviderRequest",
});

export type ProviderCurrentConfig = {
  readonly apiType: LlmProtocol;
  readonly baseUrl: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ProviderCurrentConfig = Schema.Struct({
  apiType: Schema.suspend((): Schema.Codec<LlmProtocol> => LlmProtocol).annotate({
    description: "Protocol currently used by this provider.",
  }),
  baseUrl: Schema.String.annotate({ description: "Base URL currently used by this provider." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nCurrent effective non-secret routing configuration for a provider.",
  identifier: "ProviderCurrentConfig",
});

export type SetProviderRequest = {
  readonly providerId: ProviderId;
  readonly apiType: LlmProtocol;
  readonly baseUrl: string;
  readonly headers?: { readonly [x: string]: string };
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SetProviderRequest = Schema.Struct({
  providerId: Schema.suspend((): Schema.Codec<ProviderId> => ProviderId).annotate({
    description: "Provider ID to configure.",
  }),
  apiType: Schema.suspend((): Schema.Codec<LlmProtocol> => LlmProtocol).annotate({
    description: "Protocol type for this provider.",
  }),
  baseUrl: Schema.String.annotate({
    description: "Base URL for requests sent through this provider.",
  }),
  headers: Schema.optionalKey(
    Schema.Record(Schema.String, Schema.String).annotate({
      description:
        "Full headers map for this provider.\nMay include authorization, routing, or other integration-specific headers.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nRequest parameters for `providers/set`.\n\nReplaces the full configuration for one provider ID.",
  identifier: "SetProviderRequest",
});

export type PromptResponse = {
  readonly stopReason: StopReason;
  readonly usage?: Usage | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const PromptResponse = Schema.Struct({
  stopReason: Schema.suspend((): Schema.Codec<StopReason> => StopReason).annotate({
    description: "Indicates why the agent stopped processing the turn.",
  }),
  usage: Schema.optionalKey(
    Schema.Union([Usage, Schema.Null]).annotate({
      description:
        "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nToken usage for this turn (optional).",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Response from processing a user prompt.\n\nSee protocol docs: [Check for Completion](https://agentclientprotocol.com/protocol/prompt-turn#4-check-for-completion)",
  identifier: "PromptResponse",
});

export type Range = {
  readonly start: Position;
  readonly end: Position;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const Range = Schema.Struct({
  start: Schema.suspend((): Schema.Codec<Position> => Position).annotate({
    description: "The start position (inclusive).",
  }),
  end: Schema.suspend((): Schema.Codec<Position> => Position).annotate({
    description: "The end position (exclusive).",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "A range in a text document, expressed as start and end positions.",
  identifier: "Range",
});

export type NesUserAction = {
  readonly action: string;
  readonly uri: string;
  readonly position: Position;
  readonly timestampMs: number;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesUserAction = Schema.Struct({
  action: Schema.String.annotate({
    description: 'The kind of action (e.g., "insertChar", "cursorMovement").',
  }),
  uri: Schema.String.annotate({ description: "The URI of the file where the action occurred." }),
  position: Schema.suspend((): Schema.Codec<Position> => Position).annotate({
    description: "The position where the action occurred.",
  }),
  timestampMs: Schema.Number.annotate({
    description: "Timestamp in milliseconds since epoch.",
    format: "uint64",
  })
    .check(Schema.isInt().annotate({ expected: "an integer" }))
    .check(
      Schema.isGreaterThanOrEqualTo(0).annotate({ expected: "a value greater than or equal to 0" }),
    ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "A user action (typing, cursor movement, etc.).",
  identifier: "NesUserAction",
});

export type Error = {
  readonly code: ErrorCode;
  readonly message: string;
  readonly data?: Schema.Json;
};
export const Error = Schema.Struct({
  code: Schema.suspend((): Schema.Codec<ErrorCode> => ErrorCode).annotate({
    description:
      "A number indicating the error type that occurred.\nThis must be an integer as defined in the JSON-RPC specification.",
  }),
  message: Schema.String.annotate({
    description:
      "A string providing a short description of the error.\nThe message should be limited to a concise single sentence.",
  }),
  data: Schema.optionalKey(
    Schema.Json.annotate({
      expected: "JSON value",
      description:
        "Optional primitive or structured value that contains additional information about the error.\nThis may include debugging information or context-specific details.",
    }),
  ),
}).annotate({
  description:
    "JSON-RPC error object.\n\nRepresents an error that occurred during method execution, following the\nJSON-RPC 2.0 error object specification with optional additional data.\n\nSee protocol docs: [JSON-RPC Error Object](https://www.jsonrpc.org/specification#error_object)",
  identifier: "Error",
});

export type SessionConfigOptionsCapabilities = {
  readonly boolean?: BooleanConfigOptionCapabilities | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SessionConfigOptionsCapabilities = Schema.Struct({
  boolean: Schema.optionalKey(
    Schema.Union([BooleanConfigOptionCapabilities, Schema.Null]).annotate({
      description:
        'Whether the client supports boolean session configuration options.\n\nOptional. Omitted or `null` both mean the client does not advertise support.\nSupplying `{}` means agents may include `type: "boolean"` entries in\n`configOptions`, and the client may send `session/set_config_option`\nrequests with `type: "boolean"` and a boolean `value`.',
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Session configuration option capabilities supported by the client.",
  identifier: "SessionConfigOptionsCapabilities",
});

export type ElicitationCapabilities = {
  readonly form?: ElicitationFormCapabilities | null;
  readonly url?: ElicitationUrlCapabilities | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ElicitationCapabilities = Schema.Struct({
  form: Schema.optionalKey(
    Schema.Union([ElicitationFormCapabilities, Schema.Null]).annotate({
      description:
        "Whether the client supports form-based elicitation.\n\nOptional. Omitted and `null` are equivalent and mean form support is not advertised.\nSupplying `{}` explicitly advertises form support.",
    }),
  ),
  url: Schema.optionalKey(
    Schema.Union([ElicitationUrlCapabilities, Schema.Null]).annotate({
      description:
        "Whether the client supports URL-based elicitation.\n\nOptional. Omitted or `null` both mean the client does not advertise support.\nSupplying `{}` means the client supports URL-based elicitation.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Elicitation capabilities supported by the client.",
  identifier: "ElicitationCapabilities",
});

export type ClientNesCapabilities = {
  readonly jump?: NesJumpCapabilities | null;
  readonly rename?: NesRenameCapabilities | null;
  readonly searchAndReplace?: NesSearchAndReplaceCapabilities | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ClientNesCapabilities = Schema.Struct({
  jump: Schema.optionalKey(
    Schema.Union([NesJumpCapabilities, Schema.Null]).annotate({
      description: "Whether the client supports the `jump` suggestion kind.",
    }),
  ),
  rename: Schema.optionalKey(
    Schema.Union([NesRenameCapabilities, Schema.Null]).annotate({
      description: "Whether the client supports the `rename` suggestion kind.",
    }),
  ),
  searchAndReplace: Schema.optionalKey(
    Schema.Union([NesSearchAndReplaceCapabilities, Schema.Null]).annotate({
      description: "Whether the client supports the `searchAndReplace` suggestion kind.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "NES capabilities advertised by the client during initialization.",
  identifier: "ClientNesCapabilities",
});

export type RejectNesNotification = {
  readonly sessionId: SessionId;
  readonly id: NesSuggestionId;
  readonly reason?: NesRejectReason | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const RejectNesNotification = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The session ID for this notification.",
  }),
  id: Schema.suspend((): Schema.Codec<NesSuggestionId> => NesSuggestionId).annotate({
    description: "The ID of the rejected suggestion.",
  }),
  reason: Schema.optionalKey(
    Schema.Union([NesRejectReason, Schema.Null]).annotate({
      description: "The reason for rejection.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Notification sent when a suggestion is rejected.",
  identifier: "RejectNesNotification",
});

export type StartNesRequest = {
  readonly workspaceUri?: string | null;
  readonly workspaceFolders?: ReadonlyArray<WorkspaceFolder> | null;
  readonly repository?: NesRepository | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const StartNesRequest = Schema.Struct({
  workspaceUri: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({ description: "The root URI of the workspace." }),
      Schema.Null,
    ]),
  ),
  workspaceFolders: Schema.optionalKey(
    Schema.Union([
      Schema.Array(WorkspaceFolder).annotate({ description: "The workspace folders." }),
      Schema.Null,
    ]),
  ),
  repository: Schema.optionalKey(
    Schema.Union([NesRepository, Schema.Null]).annotate({
      description: "Repository metadata, if the workspace is a git repository.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "Request to start an NES session.", identifier: "StartNesRequest" });

export type NesRelatedSnippet = {
  readonly uri: string;
  readonly excerpts: ReadonlyArray<NesExcerpt>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesRelatedSnippet = Schema.Struct({
  uri: Schema.String.annotate({ description: "The URI of the file containing the snippets." }),
  excerpts: Schema.Array(NesExcerpt).annotate({ description: "The code excerpts." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "A related code snippet from a file.",
  identifier: "NesRelatedSnippet",
});

export type TerminalOutputResponse = {
  readonly output: string;
  readonly truncated: boolean;
  readonly exitStatus?: TerminalExitStatus | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const TerminalOutputResponse = Schema.Struct({
  output: Schema.String.annotate({ description: "The terminal output captured so far." }),
  truncated: Schema.Boolean.annotate({
    description: "Whether the output was truncated due to byte limits.",
  }),
  exitStatus: Schema.optionalKey(
    Schema.Union([TerminalExitStatus, Schema.Null]).annotate({
      description: "Exit status if the command has completed.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Response containing the terminal output and exit status.",
  identifier: "TerminalOutputResponse",
});

export type CreateElicitationResponse =
  | {
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
      readonly action: "accept";
      readonly content?: { readonly [x: string]: ElicitationContentValue } | null;
    }
  | { readonly _meta?: { readonly [x: string]: Schema.Json } | null; readonly action: "decline" }
  | { readonly _meta?: { readonly [x: string]: Schema.Json } | null; readonly action: "cancel" }
  | ({ readonly _meta?: { readonly [x: string]: Schema.Json } | null; readonly action: string } & {
      readonly [x: string]: Schema.Json;
    });
export const CreateElicitationResponse = Schema.Union([
  Schema.Struct({
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
    action: Schema.Literal("accept"),
    content: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, ElicitationContentValue).annotate({
          description:
            "The user-provided content, if any, as an object matching the requested schema.",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "The user accepted the elicitation and provided content." }),
  Schema.Struct({
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
    action: Schema.Literal("decline"),
  }).annotate({ description: "The user declined the elicitation." }),
  Schema.Struct({
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
    action: Schema.Literal("cancel"),
  }).annotate({ description: "The elicitation was cancelled." }),
  Schema.StructWithRest(
    Schema.Struct({
      _meta: Schema.optionalKey(
        Schema.Union([
          Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
            description:
              "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
          }),
          Schema.Null,
        ]),
      ),
      action: Schema.String.annotate({
        description:
          "Custom or future elicitation action.\n\nValues beginning with `_` are reserved for implementation-specific\nextensions. Unknown values that do not begin with `_` are reserved for\nfuture ACP variants.",
      }).check(
        Schema.isPattern(
          new RegExp("^(?!(?:\\x61ccept|\\x64ecline|\\x63ancel)$)[\\s\\S]*$"),
        ).annotate({
          expected:
            "a string matching the RegExp ^(?!(?:\\x61ccept|\\x64ecline|\\x63ancel)$)[\\s\\S]*$",
        }),
      ),
    }),
    [Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" }))],
  ).annotate({
    title: "other",
    description:
      "Custom or future elicitation action.\n\nValues beginning with `_` are reserved for implementation-specific\nextensions. Unknown values that do not begin with `_` are reserved for\nfuture ACP variants.\n\nAgents that do not understand this action should preserve the raw\npayload when storing, replaying, proxying, or forwarding elicitation\nresponses. They MUST NOT treat it as a known elicitation action.",
  }),
]).annotate({ identifier: "CreateElicitationResponse" });

export type ListSessionsResponse = {
  readonly sessions: ReadonlyArray<SessionInfo>;
  readonly nextCursor?: string | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ListSessionsResponse = Schema.Struct({
  sessions: Schema.Array(SessionInfo).annotate({
    description: "Array of session information objects",
  }),
  nextCursor: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "Opaque cursor token. If present, pass this in the next request's cursor parameter\nto fetch the next page. If absent, there are no more results.",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "Response from listing sessions.", identifier: "ListSessionsResponse" });

export type NesDocumentEventCapabilities = {
  readonly didOpen?: NesDocumentDidOpenCapabilities | null;
  readonly didChange?: NesDocumentDidChangeCapabilities | null;
  readonly didClose?: NesDocumentDidCloseCapabilities | null;
  readonly didSave?: NesDocumentDidSaveCapabilities | null;
  readonly didFocus?: NesDocumentDidFocusCapabilities | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesDocumentEventCapabilities = Schema.Struct({
  didOpen: Schema.optionalKey(
    Schema.Union([NesDocumentDidOpenCapabilities, Schema.Null]).annotate({
      description: "Whether the agent wants `document/didOpen` events.",
    }),
  ),
  didChange: Schema.optionalKey(
    Schema.Union([NesDocumentDidChangeCapabilities, Schema.Null]).annotate({
      description: "Whether the agent wants `document/didChange` events, and the sync kind.",
    }),
  ),
  didClose: Schema.optionalKey(
    Schema.Union([NesDocumentDidCloseCapabilities, Schema.Null]).annotate({
      description: "Whether the agent wants `document/didClose` events.",
    }),
  ),
  didSave: Schema.optionalKey(
    Schema.Union([NesDocumentDidSaveCapabilities, Schema.Null]).annotate({
      description: "Whether the agent wants `document/didSave` events.",
    }),
  ),
  didFocus: Schema.optionalKey(
    Schema.Union([NesDocumentDidFocusCapabilities, Schema.Null]).annotate({
      description: "Whether the agent wants `document/didFocus` events.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Document event capabilities the agent wants to receive.",
  identifier: "NesDocumentEventCapabilities",
});

export type ContentBlock =
  | {
      readonly type: "text";
      readonly annotations?: Annotations | null;
      readonly text: string;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly type: "image";
      readonly annotations?: Annotations | null;
      readonly data: string;
      readonly mimeType: string;
      readonly uri?: string | null;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly type: "audio";
      readonly annotations?: Annotations | null;
      readonly data: string;
      readonly mimeType: string;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly type: "resource_link";
      readonly annotations?: Annotations | null;
      readonly description?: string | null;
      readonly mimeType?: string | null;
      readonly name: string;
      readonly size?: number | null;
      readonly title?: string | null;
      readonly uri: string;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly type: "resource";
      readonly annotations?: Annotations | null;
      readonly resource: EmbeddedResourceResource;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    };
export const ContentBlock = Schema.Union([
  Schema.Struct({
    type: Schema.Literal("text"),
    annotations: Schema.optionalKey(
      Schema.Union([Annotations, Schema.Null]).annotate({
        description:
          "Optional annotations that help clients decide how to display or route this content.",
      }),
    ),
    text: Schema.String.annotate({ description: "Text payload carried by this content block." }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "Text provided to or from an LLM." }),
  Schema.Struct({
    type: Schema.Literal("image"),
    annotations: Schema.optionalKey(
      Schema.Union([Annotations, Schema.Null]).annotate({
        description:
          "Optional annotations that help clients decide how to display or route this content.",
      }),
    ),
    data: Schema.String.annotate({ description: "Base64-encoded media payload." }),
    mimeType: Schema.String.annotate({
      description: "MIME type describing the encoded media payload.",
    }),
    uri: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description: "URI associated with this resource or media payload.",
        }),
        Schema.Null,
      ]),
    ),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "An image provided to or from an LLM." }),
  Schema.Struct({
    type: Schema.Literal("audio"),
    annotations: Schema.optionalKey(
      Schema.Union([Annotations, Schema.Null]).annotate({
        description:
          "Optional annotations that help clients decide how to display or route this content.",
      }),
    ),
    data: Schema.String.annotate({ description: "Base64-encoded media payload." }),
    mimeType: Schema.String.annotate({
      description: "MIME type describing the encoded media payload.",
    }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "Audio provided to or from an LLM." }),
  Schema.Struct({
    type: Schema.Literal("resource_link"),
    annotations: Schema.optionalKey(
      Schema.Union([Annotations, Schema.Null]).annotate({
        description:
          "Optional annotations that help clients decide how to display or route this content.",
      }),
    ),
    description: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description: "Optional human-readable details shown with this protocol object.",
        }),
        Schema.Null,
      ]),
    ),
    mimeType: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({ description: "MIME type describing the encoded media payload." }),
        Schema.Null,
      ]),
    ),
    name: Schema.String.annotate({
      description: "Human-readable name shown for this protocol object.",
    }),
    size: Schema.optionalKey(
      Schema.Union([
        Schema.Number.annotate({
          description: "Optional size of the linked resource in bytes, if known.",
          format: "int64",
        }).check(Schema.isInt().annotate({ expected: "an integer" })),
        Schema.Null,
      ]),
    ),
    title: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({ description: "Optional display title for end-user UI." }),
        Schema.Null,
      ]),
    ),
    uri: Schema.String.annotate({
      description: "URI associated with this resource or media payload.",
    }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description:
      "A resource that the server is capable of reading, included in a prompt or tool call result.",
  }),
  Schema.Struct({
    type: Schema.Literal("resource"),
    annotations: Schema.optionalKey(
      Schema.Union([Annotations, Schema.Null]).annotate({
        description:
          "Optional annotations that help clients decide how to display or route this content.",
      }),
    ),
    resource: Schema.suspend(
      (): Schema.Codec<EmbeddedResourceResource> => EmbeddedResourceResource,
    ).annotate({ description: "Embedded resource payload, either text or binary data." }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description: "The contents of a resource, embedded into a prompt or tool call result.",
  }),
]).annotate({
  description:
    "Content blocks represent displayable information in the Agent Client Protocol.\n\nThey provide a structured way to handle various types of user-facing content—whether\nit's text from language models, images for analysis, or embedded resources for context.\n\nContent blocks appear in:\n- User prompts sent via `session/prompt`\n- Language model output streamed through `session/update` notifications\n- Progress updates and results from tool calls\n\nThis structure is compatible with the Model Context Protocol (MCP), enabling\nagents to seamlessly forward content from MCP tool outputs without transformation.\n\nSee protocol docs: [Content](https://agentclientprotocol.com/protocol/content)",
  identifier: "ContentBlock",
});

export type PlanUpdateContent =
  | {
      readonly type: "items";
      readonly planId: PlanId;
      readonly entries: ReadonlyArray<PlanEntry>;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly type: "file";
      readonly planId: PlanId;
      readonly uri: string;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly type: "markdown";
      readonly planId: PlanId;
      readonly content: string;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    };
export const PlanUpdateContent = Schema.Union([
  Schema.Struct({
    type: Schema.Literal("items"),
    planId: Schema.suspend((): Schema.Codec<PlanId> => PlanId).annotate({
      description: "The plan ID to update.",
    }),
    entries: Schema.Array(PlanEntry).annotate({
      description:
        "The list of tasks to be accomplished.\n\nWhen updating an item-based plan, the agent must send a complete list of all entries\nwith their current status. The client replaces that plan with each update.",
    }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description:
      "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nA plan represented as structured entries.",
  }),
  Schema.Struct({
    type: Schema.Literal("file"),
    planId: Schema.suspend((): Schema.Codec<PlanId> => PlanId).annotate({
      description: "The plan ID to update.",
    }),
    uri: Schema.String.annotate({ description: "The URI of the file containing the plan." }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description:
      "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nA plan represented by a file URI.",
  }),
  Schema.Struct({
    type: Schema.Literal("markdown"),
    planId: Schema.suspend((): Schema.Codec<PlanId> => PlanId).annotate({
      description: "The plan ID to update.",
    }),
    content: Schema.String.annotate({ description: "Markdown content for the plan." }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description:
      "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nA plan represented as raw markdown content.",
  }),
]).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nUpdated content for a plan.",
  identifier: "PlanUpdateContent",
});

export type AvailableCommand = {
  readonly name: string;
  readonly description: string;
  readonly input?: AvailableCommandInput | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const AvailableCommand = Schema.Struct({
  name: Schema.String.annotate({
    description: "Command name (e.g., `create_plan`, `research_codebase`).",
  }),
  description: Schema.String.annotate({
    description: "Human-readable description of what the command does.",
  }),
  input: Schema.optionalKey(
    Schema.Union([AvailableCommandInput, Schema.Null]).annotate({
      description: "Input for the command if required",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "Information about a command.", identifier: "AvailableCommand" });

export type SessionModeState = {
  readonly currentModeId: SessionModeId;
  readonly availableModes: ReadonlyArray<SessionMode>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SessionModeState = Schema.Struct({
  currentModeId: Schema.suspend((): Schema.Codec<SessionModeId> => SessionModeId).annotate({
    description: "The current mode the Agent is in.",
  }),
  availableModes: Schema.Array(SessionMode).annotate({
    description: "The set of modes that the Agent can operate in",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "The set of modes and the one currently active.",
  identifier: "SessionModeState",
});

export type SessionConfigSelectGroup = {
  readonly group: SessionConfigGroupId;
  readonly name: string;
  readonly options: ReadonlyArray<SessionConfigSelectOption>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SessionConfigSelectGroup = Schema.Struct({
  group: Schema.suspend((): Schema.Codec<SessionConfigGroupId> => SessionConfigGroupId).annotate({
    description: "Unique identifier for this group.",
  }),
  name: Schema.String.annotate({ description: "Human-readable label for this group." }),
  options: Schema.Array(SessionConfigSelectOption).annotate({
    description: "The set of option values in this group.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "A group of possible values for a session configuration option.",
  identifier: "SessionConfigSelectGroup",
});

export type RequestPermissionResponse = {
  readonly outcome: RequestPermissionOutcome;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const RequestPermissionResponse = Schema.Struct({
  outcome: Schema.suspend(
    (): Schema.Codec<RequestPermissionOutcome> => RequestPermissionOutcome,
  ).annotate({ description: "The user's decision on the permission request." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Response to a permission request.",
  identifier: "RequestPermissionResponse",
});

export type McpServer =
  | {
      readonly type: "http";
      readonly name: string;
      readonly url: string;
      readonly headers: ReadonlyArray<HttpHeader>;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly type: "sse";
      readonly name: string;
      readonly url: string;
      readonly headers: ReadonlyArray<HttpHeader>;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly type: "acp";
      readonly name: string;
      readonly serverId: McpServerAcpId;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | McpServerStdio;
export const McpServer = Schema.Union([
  Schema.Struct({
    type: Schema.Literal("http"),
    name: Schema.String.annotate({
      description: "Human-readable name identifying this MCP server.",
    }),
    url: Schema.String.annotate({ description: "URL to the MCP server." }),
    headers: Schema.Array(HttpHeader).annotate({
      description: "HTTP headers to set when making requests to the MCP server.",
    }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "HTTP transport configuration for MCP." }),
  Schema.Struct({
    type: Schema.Literal("sse"),
    name: Schema.String.annotate({
      description: "Human-readable name identifying this MCP server.",
    }),
    url: Schema.String.annotate({ description: "URL to the MCP server." }),
    headers: Schema.Array(HttpHeader).annotate({
      description: "HTTP headers to set when making requests to the MCP server.",
    }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "SSE transport configuration for MCP." }),
  Schema.Struct({
    type: Schema.Literal("acp"),
    name: Schema.String.annotate({
      description: "Human-readable name identifying this MCP server.",
    }),
    serverId: Schema.suspend((): Schema.Codec<McpServerAcpId> => McpServerAcpId).annotate({
      description:
        "Unique identifier for this MCP server, generated by the component providing it.\n\nProviders MUST NOT reuse an ID for multiple ACP-transport MCP servers that are visible\non the same ACP connection.",
    }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description:
      "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nACP transport configuration for MCP.\n\nThe MCP server is provided by an ACP component and communicates over the ACP channel\nusing `mcp/connect`, `mcp/message`, and `mcp/disconnect`.",
  }),
  Schema.suspend((): Schema.Codec<McpServerStdio> => McpServerStdio).annotate({
    title: "stdio",
    description: "Stdio transport configuration\n\nAll Agents MUST support this transport.",
  }),
]).annotate({
  description:
    "Configuration for connecting to an MCP (Model Context Protocol) server.\n\nMCP servers provide tools and context that the agent can use when\nprocessing prompts.\n\nSee protocol docs: [MCP Servers](https://agentclientprotocol.com/protocol/session-setup#mcp-servers)",
  identifier: "McpServer",
});

export type ElicitationPropertySchema =
  | {
      readonly type: "string";
      readonly title?: string | null;
      readonly description?: string | null;
      readonly minLength?: number | null;
      readonly maxLength?: number | null;
      readonly pattern?: string | null;
      readonly format?: StringFormat | null;
      readonly default?: string | null;
      readonly enum?: ReadonlyArray<string> | null;
      readonly oneOf?: ReadonlyArray<EnumOption> | null;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly type: "number";
      readonly title?: string | null;
      readonly description?: string | null;
      readonly minimum?: number | null;
      readonly maximum?: number | null;
      readonly default?: number | null;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly type: "integer";
      readonly title?: string | null;
      readonly description?: string | null;
      readonly minimum?: number | null;
      readonly maximum?: number | null;
      readonly default?: number | null;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly type: "boolean";
      readonly title?: string | null;
      readonly description?: string | null;
      readonly default?: boolean | null;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly type: "array";
      readonly title?: string | null;
      readonly description?: string | null;
      readonly minItems?: number | null;
      readonly maxItems?: number | null;
      readonly items: MultiSelectItems;
      readonly default?: ReadonlyArray<string> | null;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | ({ readonly type: string } & { readonly [x: string]: Schema.Json });
export const ElicitationPropertySchema = Schema.Union([
  Schema.Struct({
    type: Schema.Literal("string"),
    title: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description:
            "Optional title for the property.\n\nOptional. Omitted and `null` are equivalent and mean no title is provided.",
        }),
        Schema.Null,
      ]),
    ),
    description: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description:
            "Human-readable description.\n\nOptional. Omitted and `null` are equivalent and mean no description is provided.",
        }),
        Schema.Null,
      ]),
    ),
    minLength: Schema.optionalKey(
      Schema.Union([
        Schema.Number.annotate({
          description:
            "Minimum string length.\n\nOptional. Omitted and `null` are equivalent and mean there is no minimum length constraint.",
          format: "uint32",
        })
          .check(Schema.isInt().annotate({ expected: "an integer" }))
          .check(
            Schema.isGreaterThanOrEqualTo(0).annotate({
              expected: "a value greater than or equal to 0",
            }),
          ),
        Schema.Null,
      ]),
    ),
    maxLength: Schema.optionalKey(
      Schema.Union([
        Schema.Number.annotate({
          description:
            "Maximum string length.\n\nOptional. Omitted and `null` are equivalent and mean there is no maximum length constraint.",
          format: "uint32",
        })
          .check(Schema.isInt().annotate({ expected: "an integer" }))
          .check(
            Schema.isGreaterThanOrEqualTo(0).annotate({
              expected: "a value greater than or equal to 0",
            }),
          ),
        Schema.Null,
      ]),
    ),
    pattern: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description:
            "Pattern the string must match.\n\nOptional. Omitted and `null` are equivalent and mean there is no pattern constraint.",
        }),
        Schema.Null,
      ]),
    ),
    format: Schema.optionalKey(
      Schema.Union([StringFormat, Schema.Null]).annotate({
        description:
          "String format.\n\nOptional. Omitted and `null` are equivalent and mean there is no format constraint.",
      }),
    ),
    default: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description:
            "Default value.\n\nOptional. Omitted and `null` are equivalent and mean no default value is provided.",
        }),
        Schema.Null,
      ]),
    ),
    enum: Schema.optionalKey(
      Schema.Union([
        Schema.Array(Schema.String).annotate({
          description:
            "Enum values for untitled single-select enums.\nOptional. Omitted and `null` are equivalent and mean no untitled single-select choices are\ndeclared by `enum`.",
        }),
        Schema.Null,
      ]),
    ),
    oneOf: Schema.optionalKey(
      Schema.Union([
        Schema.Array(EnumOption).annotate({
          description:
            "Titled enum options for titled single-select enums.\nOptional. Omitted and `null` are equivalent and mean no titled single-select choices are\ndeclared by `oneOf`.",
        }),
        Schema.Null,
      ]),
    ),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description:
      'Schema for string properties in an elicitation form.\n\nWhen `enum` or `oneOf` is set, this represents a single-select enum\nwith `"type": "string"`.',
  }),
  Schema.Struct({
    type: Schema.Literal("number"),
    title: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description:
            "Optional title for the property.\n\nOptional. Omitted and `null` are equivalent and mean no title is provided.",
        }),
        Schema.Null,
      ]),
    ),
    description: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description:
            "Human-readable description.\n\nOptional. Omitted and `null` are equivalent and mean no description is provided.",
        }),
        Schema.Null,
      ]),
    ),
    minimum: Schema.optionalKey(
      Schema.Union([
        Schema.Number.annotate({
          description:
            "Minimum value (inclusive).\n\nOptional. Omitted and `null` are equivalent and mean there is no inclusive lower bound.",
          format: "double",
        }).check(Schema.isFinite().annotate({ expected: "a finite number" })),
        Schema.Null,
      ]),
    ),
    maximum: Schema.optionalKey(
      Schema.Union([
        Schema.Number.annotate({
          description:
            "Maximum value (inclusive).\n\nOptional. Omitted and `null` are equivalent and mean there is no inclusive upper bound.",
          format: "double",
        }).check(Schema.isFinite().annotate({ expected: "a finite number" })),
        Schema.Null,
      ]),
    ),
    default: Schema.optionalKey(
      Schema.Union([
        Schema.Number.annotate({
          description:
            "Default value.\n\nOptional. Omitted and `null` are equivalent and mean no default value is provided.",
          format: "double",
        }).check(Schema.isFinite().annotate({ expected: "a finite number" })),
        Schema.Null,
      ]),
    ),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description: "Schema for number (floating-point) properties in an elicitation form.",
  }),
  Schema.Struct({
    type: Schema.Literal("integer"),
    title: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description:
            "Optional title for the property.\n\nOptional. Omitted and `null` are equivalent and mean no title is provided.",
        }),
        Schema.Null,
      ]),
    ),
    description: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description:
            "Human-readable description.\n\nOptional. Omitted and `null` are equivalent and mean no description is provided.",
        }),
        Schema.Null,
      ]),
    ),
    minimum: Schema.optionalKey(
      Schema.Union([
        Schema.Number.annotate({
          description:
            "Minimum value (inclusive).\n\nOptional. Omitted and `null` are equivalent and mean there is no inclusive lower bound.",
          format: "int64",
        }).check(Schema.isInt().annotate({ expected: "an integer" })),
        Schema.Null,
      ]),
    ),
    maximum: Schema.optionalKey(
      Schema.Union([
        Schema.Number.annotate({
          description:
            "Maximum value (inclusive).\n\nOptional. Omitted and `null` are equivalent and mean there is no inclusive upper bound.",
          format: "int64",
        }).check(Schema.isInt().annotate({ expected: "an integer" })),
        Schema.Null,
      ]),
    ),
    default: Schema.optionalKey(
      Schema.Union([
        Schema.Number.annotate({
          description:
            "Default value.\n\nOptional. Omitted and `null` are equivalent and mean no default value is provided.",
          format: "int64",
        }).check(Schema.isInt().annotate({ expected: "an integer" })),
        Schema.Null,
      ]),
    ),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "Schema for integer properties in an elicitation form." }),
  Schema.Struct({
    type: Schema.Literal("boolean"),
    title: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description:
            "Optional title for the property.\n\nOptional. Omitted and `null` are equivalent and mean no title is provided.",
        }),
        Schema.Null,
      ]),
    ),
    description: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description:
            "Human-readable description.\n\nOptional. Omitted and `null` are equivalent and mean no description is provided.",
        }),
        Schema.Null,
      ]),
    ),
    default: Schema.optionalKey(
      Schema.Union([
        Schema.Boolean.annotate({
          description:
            "Default value.\n\nOptional. Omitted and `null` are equivalent and mean no default value is provided.",
        }),
        Schema.Null,
      ]),
    ),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "Schema for boolean properties in an elicitation form." }),
  Schema.Struct({
    type: Schema.Literal("array"),
    title: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description:
            "Optional title for the property.\n\nOptional. Omitted and `null` are equivalent and mean no title is provided.",
        }),
        Schema.Null,
      ]),
    ),
    description: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description:
            "Human-readable description.\n\nOptional. Omitted and `null` are equivalent and mean no description is provided.",
        }),
        Schema.Null,
      ]),
    ),
    minItems: Schema.optionalKey(
      Schema.Union([
        Schema.Number.annotate({
          description:
            "Minimum number of items to select.\n\nOptional. Omitted and `null` are equivalent and mean there is no minimum selection count.",
          format: "uint64",
        })
          .check(Schema.isInt().annotate({ expected: "an integer" }))
          .check(
            Schema.isGreaterThanOrEqualTo(0).annotate({
              expected: "a value greater than or equal to 0",
            }),
          ),
        Schema.Null,
      ]),
    ),
    maxItems: Schema.optionalKey(
      Schema.Union([
        Schema.Number.annotate({
          description:
            "Maximum number of items to select.\n\nOptional. Omitted and `null` are equivalent and mean there is no maximum selection count.",
          format: "uint64",
        })
          .check(Schema.isInt().annotate({ expected: "an integer" }))
          .check(
            Schema.isGreaterThanOrEqualTo(0).annotate({
              expected: "a value greater than or equal to 0",
            }),
          ),
        Schema.Null,
      ]),
    ),
    items: Schema.suspend((): Schema.Codec<MultiSelectItems> => MultiSelectItems).annotate({
      description: "The items definition describing allowed values.",
    }),
    default: Schema.optionalKey(
      Schema.Union([
        Schema.Array(Schema.String).annotate({
          description:
            "Default selected values.\n\nOptional. Omitted and `null` are equivalent and mean no default selections are provided.",
        }),
        Schema.Null,
      ]),
    ),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description: "Schema for multi-select (array) properties in an elicitation form.",
  }),
  Schema.StructWithRest(
    Schema.Struct({
      type: Schema.String.annotate({
        description:
          "Custom or future elicitation property schema type.\n\nValues beginning with `_` are reserved for implementation-specific\nextensions. Unknown values that do not begin with `_` are reserved for\nfuture ACP variants.",
      }).check(
        Schema.isPattern(
          new RegExp("^(?!(?:\\x73tring|\\x6eumber|\\x69nteger|\\x62oolean|\\x61rray)$)[\\s\\S]*$"),
        ).annotate({
          expected:
            "a string matching the RegExp ^(?!(?:\\x73tring|\\x6eumber|\\x69nteger|\\x62oolean|\\x61rray)$)[\\s\\S]*$",
        }),
      ),
    }),
    [Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" }))],
  ).annotate({
    title: "other",
    description:
      "Custom or future elicitation property schema.\n\nValues beginning with `_` are reserved for implementation-specific\nextensions. Unknown values that do not begin with `_` are reserved for\nfuture ACP variants.\n\nClients that do not understand this property schema type should preserve\nthe raw schema when storing, replaying, proxying, or forwarding\nelicitation requests. They MUST NOT render it as a known input control.",
  }),
]).annotate({
  description:
    'Property schema for elicitation form fields.\n\nEach variant corresponds to a JSON Schema `"type"` value.\nSingle-select enums use the `String` variant with `enum` or `oneOf` set.\nMulti-select enums use the `Array` variant.',
  identifier: "ElicitationPropertySchema",
});

export type AuthMethod =
  | {
      readonly type: "terminal";
      readonly id: AuthMethodId;
      readonly name: string;
      readonly description?: string | null;
      readonly args?: ReadonlyArray<string>;
      readonly env?: { readonly [x: string]: string };
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | AuthMethodAgent;
export const AuthMethod = Schema.Union([
  Schema.Struct({
    type: Schema.Literal("terminal"),
    id: Schema.suspend((): Schema.Codec<AuthMethodId> => AuthMethodId).annotate({
      description: "Unique identifier for this authentication method.",
    }),
    name: Schema.String.annotate({
      description: "Human-readable name of the authentication method.",
    }),
    description: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description:
            "Optional description providing more details about this authentication method.",
        }),
        Schema.Null,
      ]),
    ),
    args: Schema.optionalKey(
      Schema.Array(Schema.String).annotate({
        description:
          "Additional arguments to append to the configured agent invocation for terminal auth.",
      }),
    ),
    env: Schema.optionalKey(
      Schema.Record(Schema.String, Schema.String).annotate({
        description:
          "Additional environment variables to set on the configured agent invocation for terminal auth.\nThese values override same-named variables in the base launch configuration.",
      }),
    ),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description:
      "Terminal-based authentication method.\n\nThe client runs the configured agent program as a separate interactive\nprocess for the user to authenticate via a TUI. Agents MUST advertise this\nmethod only when the client enabled its terminal authentication capability.\nA zero exit status signals success; any other termination signals failure.\nThe client MUST NOT pass this method to `authenticate`.",
  }),
  Schema.suspend((): Schema.Codec<AuthMethodAgent> => AuthMethodAgent).annotate({
    title: "agent",
    description:
      "Agent handles authentication itself through `authenticate`.\n\nThis is the default when no `type` is specified.",
  }),
]).annotate({
  description:
    "Describes an available authentication method.\n\nThe `type` field acts as the discriminator in the serialized JSON form.\nWhen no `type` is present, the method is treated as `agent`.",
  identifier: "AuthMethod",
});

export type ProviderInfo = {
  readonly providerId: ProviderId;
  readonly supported: ReadonlyArray<LlmProtocol>;
  readonly required: boolean;
  readonly current?: ProviderCurrentConfig | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ProviderInfo = Schema.Struct({
  providerId: Schema.suspend((): Schema.Codec<ProviderId> => ProviderId).annotate({
    description: 'Provider identifier, for example "main" or "openai".',
  }),
  supported: Schema.Array(LlmProtocol).annotate({
    description: "Supported protocol types for this provider.",
  }),
  required: Schema.Boolean.annotate({
    description:
      "Whether this provider is mandatory and cannot be disabled via `providers/disable`.\nIf true, clients must not call `providers/disable` for this provider ID.",
  }),
  current: Schema.optionalKey(
    Schema.Union([ProviderCurrentConfig, Schema.Null]).annotate({
      description:
        "Current effective non-secret routing config.\nNull or omitted means provider is disabled.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nInformation about a configurable LLM provider.",
  identifier: "ProviderInfo",
});

export type NesTextEdit = {
  readonly range: Range;
  readonly newText: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesTextEdit = Schema.Struct({
  range: Schema.suspend((): Schema.Codec<Range> => Range).annotate({
    description: "The range to replace.",
  }),
  newText: Schema.String.annotate({ description: "The replacement text." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "A text edit within a suggestion.", identifier: "NesTextEdit" });

export type TextDocumentContentChangeEvent = {
  readonly range?: Range | null;
  readonly text: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const TextDocumentContentChangeEvent = Schema.Struct({
  range: Schema.optionalKey(
    Schema.Union([Range, Schema.Null]).annotate({
      description:
        "The range of the document that changed. If `None`, the entire content is replaced.",
    }),
  ),
  text: Schema.String.annotate({
    description: "The new text for the range, or the full document content if `range` is `None`.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "A content change event for a document.\n\nWhen `range` is `None`, `text` is the full content of the document.\nWhen `range` is `Some`, `text` replaces the given range.",
  identifier: "TextDocumentContentChangeEvent",
});

export type DidFocusDocumentNotification = {
  readonly sessionId: SessionId;
  readonly uri: string;
  readonly version: number;
  readonly position: Position;
  readonly visibleRange: Range;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const DidFocusDocumentNotification = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The session ID for this notification.",
  }),
  uri: Schema.String.annotate({ description: "The URI of the focused document." }),
  version: Schema.Number.annotate({
    description: "The version number of the document.",
    format: "int64",
  }).check(Schema.isInt().annotate({ expected: "an integer" })),
  position: Schema.suspend((): Schema.Codec<Position> => Position).annotate({
    description: "The current cursor position.",
  }),
  visibleRange: Schema.suspend((): Schema.Codec<Range> => Range).annotate({
    description: "The portion of the file currently visible in the editor viewport.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Notification sent when a file becomes the active editor tab.",
  identifier: "DidFocusDocumentNotification",
});

export type NesOpenFile = {
  readonly uri: string;
  readonly languageId: string;
  readonly visibleRange?: Range | null;
  readonly lastFocusedMs?: number | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesOpenFile = Schema.Struct({
  uri: Schema.String.annotate({ description: "The URI of the file." }),
  languageId: Schema.String.annotate({ description: "The language identifier." }),
  visibleRange: Schema.optionalKey(
    Schema.Union([Range, Schema.Null]).annotate({
      description: "The visible range in the editor, if any.",
    }),
  ),
  lastFocusedMs: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description: "Timestamp in milliseconds since epoch of when the file was last focused.",
        format: "uint64",
      })
        .check(Schema.isInt().annotate({ expected: "an integer" }))
        .check(
          Schema.isGreaterThanOrEqualTo(0).annotate({
            expected: "a value greater than or equal to 0",
          }),
        ),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "An open file in the editor.", identifier: "NesOpenFile" });

export type NesDiagnostic = {
  readonly uri: string;
  readonly range: Range;
  readonly severity: NesDiagnosticSeverity;
  readonly message: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesDiagnostic = Schema.Struct({
  uri: Schema.String.annotate({ description: "The URI of the file containing the diagnostic." }),
  range: Schema.suspend((): Schema.Codec<Range> => Range).annotate({
    description: "The range of the diagnostic.",
  }),
  severity: Schema.suspend(
    (): Schema.Codec<NesDiagnosticSeverity> => NesDiagnosticSeverity,
  ).annotate({ description: "The severity of the diagnostic." }),
  message: Schema.String.annotate({ description: "The diagnostic message." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "A diagnostic (error, warning, etc.).", identifier: "NesDiagnostic" });

export type ClientSessionCapabilities = {
  readonly compaction?: CompactionCapabilities | null;
  readonly configOptions?: SessionConfigOptionsCapabilities | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ClientSessionCapabilities = Schema.Struct({
  compaction: Schema.optionalKey(
    Schema.Union([CompactionCapabilities, Schema.Null]).annotate({
      description:
        "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nSupport for ID-addressed context compaction updates. Omitted or `null`\nmeans unsupported; `{}` advertises the complete compaction contract.",
    }),
  ),
  configOptions: Schema.optionalKey(
    Schema.Union([SessionConfigOptionsCapabilities, Schema.Null]).annotate({
      description:
        "Config option capabilities supported by the client.\n\nOmitted or `null` both mean the client does not advertise support for any\nconfig option extensions.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Session-related capabilities supported by the client.",
  identifier: "ClientSessionCapabilities",
});

export type NesEventCapabilities = {
  readonly document?: NesDocumentEventCapabilities | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesEventCapabilities = Schema.Struct({
  document: Schema.optionalKey(
    Schema.Union([NesDocumentEventCapabilities, Schema.Null]).annotate({
      description: "Document event capabilities.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Event capabilities the agent can consume.",
  identifier: "NesEventCapabilities",
});

export type ToolCallContent =
  | {
      readonly type: "content";
      readonly content: ContentBlock;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly type: "diff";
      readonly path: string;
      readonly oldText?: string | null;
      readonly newText: string;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly type: "terminal";
      readonly terminalId: TerminalId;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    };
export const ToolCallContent = Schema.Union([
  Schema.Struct({
    type: Schema.Literal("content"),
    content: Schema.suspend((): Schema.Codec<ContentBlock> => ContentBlock).annotate({
      description: "The actual content block.",
    }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "Standard content block (text, images, resources)." }),
  Schema.Struct({
    type: Schema.Literal("diff"),
    path: Schema.String.annotate({ description: "The absolute file path being modified." }),
    oldText: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({ description: "The original content (None for new files)." }),
        Schema.Null,
      ]),
    ),
    newText: Schema.String.annotate({ description: "The new content after modification." }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description:
      "A diff representing file modifications.\n\nShows changes to files in a format suitable for display in the client UI.\n\nSee protocol docs: [Content](https://agentclientprotocol.com/protocol/tool-calls#content)",
  }),
  Schema.Struct({
    type: Schema.Literal("terminal"),
    terminalId: Schema.suspend((): Schema.Codec<TerminalId> => TerminalId).annotate({
      description: "Identifier of the terminal instance to embed in the content stream.",
    }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description:
      "Embed a terminal created with `terminal/create` by its id.\n\nThe terminal must be added before calling `terminal/release`.\n\nSee protocol docs: [Terminal](https://agentclientprotocol.com/protocol/terminals)",
  }),
]).annotate({
  description:
    "Content produced by a tool call.\n\nTool calls can produce different types of content including\nstandard content blocks (text, images) or file diffs.\n\nSee protocol docs: [Content](https://agentclientprotocol.com/protocol/tool-calls#content)",
  identifier: "ToolCallContent",
});

export type PromptRequest = {
  readonly sessionId: SessionId;
  readonly prompt: ReadonlyArray<ContentBlock>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const PromptRequest = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The ID of the session to send this user message to",
  }),
  prompt: Schema.Array(ContentBlock).annotate({
    description:
      "The blocks of content that compose the user's message.\n\nAs a baseline, the Agent MUST support [`ContentBlock::Text`] and [`ContentBlock::ResourceLink`],\nwhile other variants are optionally enabled via [`PromptCapabilities`].\n\nThe Client MUST adapt its interface according to [`PromptCapabilities`].\n\nThe client MAY include referenced pieces of context as either\n[`ContentBlock::Resource`] or [`ContentBlock::ResourceLink`].\n\nWhen available, [`ContentBlock::Resource`] is preferred\nas it avoids extra round-trips and allows the message to include\npieces of context from sources the agent may not have access to.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Request parameters for sending a user prompt to the agent.\n\nContains the user's message and any additional context.\n\nSee protocol docs: [User Message](https://agentclientprotocol.com/protocol/prompt-turn#1-user-message)",
  identifier: "PromptRequest",
});

export type SessionConfigSelectOptions =
  | ReadonlyArray<SessionConfigSelectOption>
  | ReadonlyArray<SessionConfigSelectGroup>;
export const SessionConfigSelectOptions = Schema.Union([
  Schema.Array(SessionConfigSelectOption).annotate({
    title: "Ungrouped",
    description: "A flat list of options with no grouping.",
  }),
  Schema.Array(SessionConfigSelectGroup).annotate({
    title: "Grouped",
    description: "A list of options grouped under headers.",
  }),
]).annotate({
  description: "Possible values for a session configuration option.",
  identifier: "SessionConfigSelectOptions",
});

export type NewSessionRequest = {
  readonly cwd: string;
  readonly additionalDirectories?: ReadonlyArray<string>;
  readonly mcpServers: ReadonlyArray<McpServer>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NewSessionRequest = Schema.Struct({
  cwd: Schema.String.annotate({
    description: "The working directory for this session. Must be an absolute path.",
  }),
  additionalDirectories: Schema.optionalKey(
    Schema.Array(Schema.String).annotate({
      description:
        "Additional workspace roots for this session. Each path must be absolute.\n\nThese expand the session's filesystem scope without changing `cwd`, which\nremains the base for relative paths. When omitted or empty, no\nadditional roots are activated for the new session.",
    }),
  ),
  mcpServers: Schema.Array(McpServer).annotate({
    description: "List of MCP (Model Context Protocol) servers the agent should connect to.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Request parameters for creating a new session.\n\nSee protocol docs: [Creating a Session](https://agentclientprotocol.com/protocol/session-setup#creating-a-session)",
  identifier: "NewSessionRequest",
});

export type LoadSessionRequest = {
  readonly mcpServers: ReadonlyArray<McpServer>;
  readonly cwd: string;
  readonly additionalDirectories?: ReadonlyArray<string>;
  readonly sessionId: SessionId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const LoadSessionRequest = Schema.Struct({
  mcpServers: Schema.Array(McpServer).annotate({
    description: "List of MCP servers to connect to for this session.",
  }),
  cwd: Schema.String.annotate({
    description: "The working directory for this session. Must be an absolute path.",
  }),
  additionalDirectories: Schema.optionalKey(
    Schema.Array(Schema.String).annotate({
      description:
        "Additional workspace roots to activate for this session. Each path must be absolute.\n\nWhen omitted or empty, no additional roots are activated. When non-empty,\nthis is the complete resulting additional-root list for the loaded\nsession. It may differ from any previously used or reported list as long as\nthe request `cwd` matches the session's `cwd`.",
    }),
  ),
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The ID of the session to load.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Request parameters for loading an existing session.\n\nOnly available if the Agent supports the `loadSession` capability.\n\nSee protocol docs: [Loading Sessions](https://agentclientprotocol.com/protocol/session-setup#loading-sessions)",
  identifier: "LoadSessionRequest",
});

export type ForkSessionRequest = {
  readonly sessionId: SessionId;
  readonly cwd: string;
  readonly additionalDirectories?: ReadonlyArray<string>;
  readonly mcpServers?: ReadonlyArray<McpServer>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ForkSessionRequest = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The ID of the session to fork.",
  }),
  cwd: Schema.String.annotate({
    description: "The working directory for this session. Must be an absolute path.",
  }),
  additionalDirectories: Schema.optionalKey(
    Schema.Array(Schema.String).annotate({
      description:
        "Additional workspace roots to activate for this session. Each path must be absolute.\n\nWhen omitted or empty, no additional roots are activated. When non-empty,\nthis is the complete resulting additional-root list for the forked\nsession.",
    }),
  ),
  mcpServers: Schema.optionalKey(
    Schema.Array(McpServer).annotate({
      description: "List of MCP servers to connect to for this session.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nRequest parameters for forking an existing session.\n\nCreates a new session based on the context of an existing one, allowing\noperations like generating summaries without affecting the original session's history.\n\nOnly available if the Agent supports the `session.fork` capability.",
  identifier: "ForkSessionRequest",
});

export type ResumeSessionRequest = {
  readonly sessionId: SessionId;
  readonly cwd: string;
  readonly additionalDirectories?: ReadonlyArray<string>;
  readonly mcpServers?: ReadonlyArray<McpServer>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ResumeSessionRequest = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The ID of the session to resume.",
  }),
  cwd: Schema.String.annotate({
    description: "The working directory for this session. Must be an absolute path.",
  }),
  additionalDirectories: Schema.optionalKey(
    Schema.Array(Schema.String).annotate({
      description:
        "Additional workspace roots to activate for this session. Each path must be absolute.\n\nWhen omitted or empty, no additional roots are activated. When non-empty,\nthis is the complete resulting additional-root list for the resumed\nsession. It may differ from any previously used or reported list as long as\nthe request `cwd` matches the session's `cwd`.",
    }),
  ),
  mcpServers: Schema.optionalKey(
    Schema.Array(McpServer).annotate({
      description: "List of MCP servers to connect to for this session.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Request parameters for resuming an existing session.\n\nResumes an existing session without returning previous messages (unlike `session/load`).\nThis is useful for agents that can resume sessions but don't implement full session loading.\n\nOnly available if the Agent supports the `sessionCapabilities.resume` capability.",
  identifier: "ResumeSessionRequest",
});

export type ElicitationSchema = {
  readonly type?: ElicitationSchemaType;
  readonly title?: string | null;
  readonly properties?: { readonly [x: string]: ElicitationPropertySchema };
  readonly required?: ReadonlyArray<string> | null;
  readonly description?: string | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ElicitationSchema = Schema.Struct({
  type: Schema.optionalKey(
    Schema.suspend((): Schema.Codec<ElicitationSchemaType> => ElicitationSchemaType).annotate({
      description: 'Type discriminator. Always `"object"`.',
      default: "object",
    }),
  ),
  title: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "Optional title for the schema.\n\nOptional. Omitted and `null` are equivalent and mean no title is provided.",
      }),
      Schema.Null,
    ]),
  ),
  properties: Schema.optionalKey(
    Schema.Record(Schema.String, ElicitationPropertySchema).annotate({
      description: "Property definitions (must be primitive types).",
      default: {},
    }),
  ),
  required: Schema.optionalKey(
    Schema.Union([
      Schema.Array(Schema.String).annotate({
        description:
          "List of required property names.\n\nOptional. Omitted and `null` are equivalent and mean no property names are required.",
      }),
      Schema.Null,
    ]),
  ),
  description: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "Optional description of what this schema represents.\n\nOptional. Omitted and `null` are equivalent and mean no schema description is provided.",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Type-safe elicitation schema for requesting structured user input.\n\nThis represents a JSON Schema object with primitive-typed properties,\nas required by the elicitation specification.",
  identifier: "ElicitationSchema",
});

export type ListProvidersResponse = {
  readonly providers: ReadonlyArray<ProviderInfo>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ListProvidersResponse = Schema.Struct({
  providers: Schema.Array(ProviderInfo).annotate({
    description: "Configurable providers with current routing info suitable for UI display.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nResponse to `providers/list`.",
  identifier: "ListProvidersResponse",
});

export type NesSuggestion =
  | {
      readonly kind: "edit";
      readonly id: NesSuggestionId;
      readonly uri: string;
      readonly edits: ReadonlyArray<NesTextEdit>;
      readonly cursorPosition?: Position | null;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly kind: "jump";
      readonly id: NesSuggestionId;
      readonly uri: string;
      readonly position: Position;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly kind: "rename";
      readonly id: NesSuggestionId;
      readonly uri: string;
      readonly position: Position;
      readonly newName: string;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly kind: "searchAndReplace";
      readonly id: NesSuggestionId;
      readonly uri: string;
      readonly search: string;
      readonly replace: string;
      readonly isRegex?: boolean | null;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    };
export const NesSuggestion = Schema.Union([
  Schema.Struct({
    kind: Schema.Literal("edit"),
    id: Schema.suspend((): Schema.Codec<NesSuggestionId> => NesSuggestionId).annotate({
      description: "Unique identifier for accept/reject tracking.",
    }),
    uri: Schema.String.annotate({ description: "The URI of the file to edit." }),
    edits: Schema.Array(NesTextEdit).annotate({ description: "The text edits to apply." }),
    cursorPosition: Schema.optionalKey(
      Schema.Union([Position, Schema.Null]).annotate({
        description: "Optional suggested cursor position after applying edits.",
      }),
    ),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "A text edit suggestion." }),
  Schema.Struct({
    kind: Schema.Literal("jump"),
    id: Schema.suspend((): Schema.Codec<NesSuggestionId> => NesSuggestionId).annotate({
      description: "Unique identifier for accept/reject tracking.",
    }),
    uri: Schema.String.annotate({ description: "The file to navigate to." }),
    position: Schema.suspend((): Schema.Codec<Position> => Position).annotate({
      description: "The target position within the file.",
    }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "A jump-to-location suggestion." }),
  Schema.Struct({
    kind: Schema.Literal("rename"),
    id: Schema.suspend((): Schema.Codec<NesSuggestionId> => NesSuggestionId).annotate({
      description: "Unique identifier for accept/reject tracking.",
    }),
    uri: Schema.String.annotate({ description: "The file URI containing the symbol." }),
    position: Schema.suspend((): Schema.Codec<Position> => Position).annotate({
      description: "The position of the symbol to rename.",
    }),
    newName: Schema.String.annotate({ description: "The new name for the symbol." }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "A rename symbol suggestion." }),
  Schema.Struct({
    kind: Schema.Literal("searchAndReplace"),
    id: Schema.suspend((): Schema.Codec<NesSuggestionId> => NesSuggestionId).annotate({
      description: "Unique identifier for accept/reject tracking.",
    }),
    uri: Schema.String.annotate({ description: "The file URI to search within." }),
    search: Schema.String.annotate({ description: "The text or pattern to find." }),
    replace: Schema.String.annotate({ description: "The replacement text." }),
    isRegex: Schema.optionalKey(
      Schema.Union([
        Schema.Boolean.annotate({
          description: "Whether `search` is a regular expression. Defaults to `false`.",
        }),
        Schema.Null,
      ]),
    ),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "A search-and-replace suggestion." }),
]).annotate({ description: "A suggestion returned by the agent.", identifier: "NesSuggestion" });

export type DidChangeDocumentNotification = {
  readonly sessionId: SessionId;
  readonly uri: string;
  readonly version: number;
  readonly contentChanges: ReadonlyArray<TextDocumentContentChangeEvent>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const DidChangeDocumentNotification = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The session ID for this notification.",
  }),
  uri: Schema.String.annotate({ description: "The URI of the changed document." }),
  version: Schema.Number.annotate({
    description: "The new version number of the document.",
    format: "int64",
  }).check(Schema.isInt().annotate({ expected: "an integer" })),
  contentChanges: Schema.Array(TextDocumentContentChangeEvent).annotate({
    description: "The content changes.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Notification sent when a file is edited.",
  identifier: "DidChangeDocumentNotification",
});

export type NesSuggestContext = {
  readonly recentFiles?: ReadonlyArray<NesRecentFile> | null;
  readonly relatedSnippets?: ReadonlyArray<NesRelatedSnippet> | null;
  readonly editHistory?: ReadonlyArray<NesEditHistoryEntry> | null;
  readonly userActions?: ReadonlyArray<NesUserAction> | null;
  readonly openFiles?: ReadonlyArray<NesOpenFile> | null;
  readonly diagnostics?: ReadonlyArray<NesDiagnostic> | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesSuggestContext = Schema.Struct({
  recentFiles: Schema.optionalKey(
    Schema.Union([
      Schema.Array(NesRecentFile).annotate({ description: "Recently accessed files." }),
      Schema.Null,
    ]),
  ),
  relatedSnippets: Schema.optionalKey(
    Schema.Union([
      Schema.Array(NesRelatedSnippet).annotate({ description: "Related code snippets." }),
      Schema.Null,
    ]),
  ),
  editHistory: Schema.optionalKey(
    Schema.Union([
      Schema.Array(NesEditHistoryEntry).annotate({ description: "Recent edit history." }),
      Schema.Null,
    ]),
  ),
  userActions: Schema.optionalKey(
    Schema.Union([
      Schema.Array(NesUserAction).annotate({
        description: "Recent user actions (typing, navigation, etc.).",
      }),
      Schema.Null,
    ]),
  ),
  openFiles: Schema.optionalKey(
    Schema.Union([
      Schema.Array(NesOpenFile).annotate({ description: "Currently open files in the editor." }),
      Schema.Null,
    ]),
  ),
  diagnostics: Schema.optionalKey(
    Schema.Union([
      Schema.Array(NesDiagnostic).annotate({
        description: "Current diagnostics (errors, warnings).",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Context attached to a suggestion request.",
  identifier: "NesSuggestContext",
});

export type ClientCapabilities = {
  readonly fs?: FileSystemCapabilities;
  readonly terminal?: boolean;
  readonly session?: ClientSessionCapabilities | null;
  readonly plan?: PlanCapabilities | null;
  readonly auth?: AuthCapabilities;
  readonly elicitation?: ElicitationCapabilities | null;
  readonly nes?: ClientNesCapabilities | null;
  readonly positionEncodings?: ReadonlyArray<PositionEncodingKind>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ClientCapabilities = Schema.Struct({
  fs: Schema.optionalKey(
    Schema.suspend((): Schema.Codec<FileSystemCapabilities> => FileSystemCapabilities).annotate({
      description:
        "File system capabilities supported by the client.\nDetermines which file operations the agent can request.",
      default: { readTextFile: false, writeTextFile: false },
    }),
  ),
  terminal: Schema.optionalKey(
    Schema.Boolean.annotate({
      description: "Whether the Client support all `terminal/*` methods.",
      default: false,
    }),
  ),
  session: Schema.optionalKey(
    Schema.Union([ClientSessionCapabilities, Schema.Null]).annotate({
      description:
        "Session-related capabilities supported by the client.\n\nOptional. Omitted or `null` both mean the client does not advertise any\nsession-related extensions.",
    }),
  ),
  plan: Schema.optionalKey(
    Schema.Union([PlanCapabilities, Schema.Null]).annotate({
      description:
        "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nWhether the client supports `plan_update` and `plan_removed` session updates.\n\nOptional. Omitted or `null` both mean the client does not advertise support.\nSupplying `{}` means the client can receive both update types.",
    }),
  ),
  auth: Schema.optionalKey(
    Schema.suspend((): Schema.Codec<AuthCapabilities> => AuthCapabilities).annotate({
      description:
        "Authentication capabilities supported by the client.\nDetermines which authentication method types the agent may include\nin its `InitializeResponse`.",
      default: { terminal: false },
    }),
  ),
  elicitation: Schema.optionalKey(
    Schema.Union([ElicitationCapabilities, Schema.Null]).annotate({
      description:
        "Elicitation capabilities supported by the client.\nDetermines which elicitation modes the agent may use.\n\nOptional. Omitted or `null` both mean the client does not advertise\nelicitation support.",
    }),
  ),
  nes: Schema.optionalKey(
    Schema.Union([ClientNesCapabilities, Schema.Null]).annotate({
      description:
        "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nNES (Next Edit Suggestions) capabilities supported by the client.\n\nOptional. Omitted or `null` both mean the client does not advertise any\nNES suggestion-kind extensions.",
    }),
  ),
  positionEncodings: Schema.optionalKey(
    Schema.Array(PositionEncodingKind).annotate({
      description:
        "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nThe position encodings supported by the client, in order of preference.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Capabilities supported by the client.\n\nAdvertised during initialization to inform the agent about\navailable features and methods.\n\nSee protocol docs: [Client Capabilities](https://agentclientprotocol.com/protocol/initialization#client-capabilities)",
  identifier: "ClientCapabilities",
});

export type NesCapabilities = {
  readonly events?: NesEventCapabilities | null;
  readonly context?: NesContextCapabilities | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesCapabilities = Schema.Struct({
  events: Schema.optionalKey(
    Schema.Union([NesEventCapabilities, Schema.Null]).annotate({
      description: "Events the agent wants to receive.",
    }),
  ),
  context: Schema.optionalKey(
    Schema.Union([NesContextCapabilities, Schema.Null]).annotate({
      description: "Context the agent wants attached to each suggestion request.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "NES capabilities advertised by the agent during initialization.",
  identifier: "NesCapabilities",
});

export type ToolCallUpdate = {
  readonly toolCallId: ToolCallId;
  readonly kind?: ToolKind | null;
  readonly status?: ToolCallStatus | null;
  readonly title?: string | null;
  readonly name?: string | null;
  readonly content?: ReadonlyArray<ToolCallContent> | null;
  readonly locations?: ReadonlyArray<ToolCallLocation> | null;
  readonly rawInput?: Schema.Json;
  readonly rawOutput?: Schema.Json;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ToolCallUpdate = Schema.Struct({
  toolCallId: Schema.suspend((): Schema.Codec<ToolCallId> => ToolCallId).annotate({
    description: "The ID of the tool call being updated.",
  }),
  kind: Schema.optionalKey(
    Schema.Union([ToolKind, Schema.Null]).annotate({ description: "Update the tool kind." }),
  ),
  status: Schema.optionalKey(
    Schema.Union([ToolCallStatus, Schema.Null]).annotate({
      description: "Update the execution status.",
    }),
  ),
  title: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({ description: "Update the human-readable title." }),
      Schema.Null,
    ]),
  ),
  name: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nUpdate the programmatic name of the tool being invoked.\n\nThis field is optional. Omitting it or sending `null` both mean that\nthe existing name is left unchanged.",
      }),
      Schema.Null,
    ]),
  ),
  content: Schema.optionalKey(
    Schema.Union([
      Schema.Array(ToolCallContent).annotate({ description: "Replace the content collection." }),
      Schema.Null,
    ]),
  ),
  locations: Schema.optionalKey(
    Schema.Union([
      Schema.Array(ToolCallLocation).annotate({ description: "Replace the locations collection." }),
      Schema.Null,
    ]),
  ),
  rawInput: Schema.optionalKey(
    Schema.Json.annotate({ expected: "JSON value", description: "Update the raw input." }),
  ),
  rawOutput: Schema.optionalKey(
    Schema.Json.annotate({ expected: "JSON value", description: "Update the raw output." }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "An update to an existing tool call.\n\nUsed to report progress and results as tools execute. All fields except\nthe tool call ID are optional - only changed fields need to be included.\n\nSee protocol docs: [Updating](https://agentclientprotocol.com/protocol/tool-calls#updating)",
  identifier: "ToolCallUpdate",
});

export type SessionConfigOption =
  | {
      readonly id: SessionConfigId;
      readonly name: string;
      readonly description?: string | null;
      readonly category?: SessionConfigOptionCategory | null;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
      readonly type: "select";
      readonly currentValue: SessionConfigValueId;
      readonly options: SessionConfigSelectOptions;
    }
  | {
      readonly id: SessionConfigId;
      readonly name: string;
      readonly description?: string | null;
      readonly category?: SessionConfigOptionCategory | null;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
      readonly type: "boolean";
      readonly currentValue: boolean;
    };
export const SessionConfigOption = Schema.Union([
  Schema.Struct({
    id: Schema.suspend((): Schema.Codec<SessionConfigId> => SessionConfigId).annotate({
      description: "Unique identifier for the configuration option.",
    }),
    name: Schema.String.annotate({ description: "Human-readable label for the option." }),
    description: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description: "Optional description for the Client to display to the user.",
        }),
        Schema.Null,
      ]),
    ),
    category: Schema.optionalKey(
      Schema.Union([SessionConfigOptionCategory, Schema.Null]).annotate({
        description: "Optional semantic category for this option (UX only).",
      }),
    ),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
    type: Schema.Literal("select"),
    currentValue: Schema.suspend(
      (): Schema.Codec<SessionConfigValueId> => SessionConfigValueId,
    ).annotate({ description: "The currently selected value." }),
    options: Schema.suspend(
      (): Schema.Codec<SessionConfigSelectOptions> => SessionConfigSelectOptions,
    ).annotate({ description: "The set of selectable options." }),
  }).annotate({
    description: "A single-value selector (dropdown) session configuration option payload.",
  }),
  Schema.Struct({
    id: Schema.suspend((): Schema.Codec<SessionConfigId> => SessionConfigId).annotate({
      description: "Unique identifier for the configuration option.",
    }),
    name: Schema.String.annotate({ description: "Human-readable label for the option." }),
    description: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description: "Optional description for the Client to display to the user.",
        }),
        Schema.Null,
      ]),
    ),
    category: Schema.optionalKey(
      Schema.Union([SessionConfigOptionCategory, Schema.Null]).annotate({
        description: "Optional semantic category for this option (UX only).",
      }),
    ),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
    type: Schema.Literal("boolean"),
    currentValue: Schema.Boolean.annotate({
      description: "The current value of the boolean option.",
    }),
  }).annotate({ description: "A boolean on/off toggle session configuration option payload." }),
]).annotate({ identifier: "SessionConfigOption" });

export type CreateElicitationRequest =
  | {
      readonly message: string;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
      readonly mode: "form";
      readonly requestedSchema: ElicitationSchema;
      readonly sessionId: SessionId;
      readonly toolCallId?: ToolCallId | null;
    }
  | {
      readonly message: string;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
      readonly mode: "form";
      readonly requestedSchema: ElicitationSchema;
      readonly requestId: RequestId;
    }
  | {
      readonly message: string;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
      readonly mode: "url";
      readonly elicitationId: ElicitationId;
      readonly url: string;
      readonly sessionId: SessionId;
      readonly toolCallId?: ToolCallId | null;
    }
  | {
      readonly message: string;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
      readonly mode: "url";
      readonly elicitationId: ElicitationId;
      readonly url: string;
      readonly requestId: RequestId;
    }
  | ({
      readonly message: string;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
      readonly mode: string;
      readonly sessionId: SessionId;
      readonly toolCallId?: ToolCallId | null;
    } & { readonly [x: string]: Schema.Json })
  | ({
      readonly message: string;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
      readonly mode: string;
      readonly requestId: RequestId;
    } & { readonly [x: string]: Schema.Json });
export const CreateElicitationRequest = Schema.Union([
  Schema.Union([
    Schema.Struct({
      message: Schema.String.annotate({
        description: "A human-readable message describing what input is needed.",
      }),
      _meta: Schema.optionalKey(
        Schema.Union([
          Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
            description:
              "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
          }),
          Schema.Null,
        ]),
      ),
      mode: Schema.Literal("form"),
      requestedSchema: Schema.suspend(
        (): Schema.Codec<ElicitationSchema> => ElicitationSchema,
      ).annotate({
        description: "A JSON Schema describing the form fields to present to the user.",
      }),
      sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
        description: "The session this elicitation is tied to.",
      }),
      toolCallId: Schema.optionalKey(
        Schema.Union([ToolCallId, Schema.Null]).annotate({
          description:
            "Optional tool call within the session.\n\nOptional. Omitted and `null` are equivalent and mean the elicitation is scoped to the\nsession without a specific tool call.",
        }),
      ),
    }).annotate({
      description:
        "Session-scoped elicitation, optionally tied to a specific tool call.\n\nWhen `tool_call_id` is set, the elicitation is tied to a specific tool call.\nThis is useful when an agent receives an elicitation from an MCP server\nduring a tool call and needs to redirect it to the user.",
    }),
    Schema.Struct({
      message: Schema.String.annotate({
        description: "A human-readable message describing what input is needed.",
      }),
      _meta: Schema.optionalKey(
        Schema.Union([
          Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
            description:
              "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
          }),
          Schema.Null,
        ]),
      ),
      mode: Schema.Literal("form"),
      requestedSchema: Schema.suspend(
        (): Schema.Codec<ElicitationSchema> => ElicitationSchema,
      ).annotate({
        description: "A JSON Schema describing the form fields to present to the user.",
      }),
      requestId: Schema.suspend((): Schema.Codec<RequestId> => RequestId).annotate({
        description: "The request this elicitation is tied to.",
      }),
    }).annotate({
      description:
        "Request-scoped elicitation, tied to a specific JSON-RPC request outside of a session\n(e.g., during auth/configuration phases before any session is started).",
    }),
  ]),
  Schema.Union([
    Schema.Struct({
      message: Schema.String.annotate({
        description: "A human-readable message describing what input is needed.",
      }),
      _meta: Schema.optionalKey(
        Schema.Union([
          Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
            description:
              "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
          }),
          Schema.Null,
        ]),
      ),
      mode: Schema.Literal("url"),
      elicitationId: Schema.suspend((): Schema.Codec<ElicitationId> => ElicitationId).annotate({
        description: "The unique identifier for this elicitation.",
      }),
      url: Schema.String.annotate({ description: "The URL to direct the user to.", format: "uri" }),
      sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
        description: "The session this elicitation is tied to.",
      }),
      toolCallId: Schema.optionalKey(
        Schema.Union([ToolCallId, Schema.Null]).annotate({
          description:
            "Optional tool call within the session.\n\nOptional. Omitted and `null` are equivalent and mean the elicitation is scoped to the\nsession without a specific tool call.",
        }),
      ),
    }).annotate({
      description:
        "Session-scoped elicitation, optionally tied to a specific tool call.\n\nWhen `tool_call_id` is set, the elicitation is tied to a specific tool call.\nThis is useful when an agent receives an elicitation from an MCP server\nduring a tool call and needs to redirect it to the user.",
    }),
    Schema.Struct({
      message: Schema.String.annotate({
        description: "A human-readable message describing what input is needed.",
      }),
      _meta: Schema.optionalKey(
        Schema.Union([
          Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
            description:
              "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
          }),
          Schema.Null,
        ]),
      ),
      mode: Schema.Literal("url"),
      elicitationId: Schema.suspend((): Schema.Codec<ElicitationId> => ElicitationId).annotate({
        description: "The unique identifier for this elicitation.",
      }),
      url: Schema.String.annotate({ description: "The URL to direct the user to.", format: "uri" }),
      requestId: Schema.suspend((): Schema.Codec<RequestId> => RequestId).annotate({
        description: "The request this elicitation is tied to.",
      }),
    }).annotate({
      description:
        "Request-scoped elicitation, tied to a specific JSON-RPC request outside of a session\n(e.g., during auth/configuration phases before any session is started).",
    }),
  ]),
  Schema.Union([
    Schema.StructWithRest(
      Schema.Struct({
        message: Schema.String.annotate({
          description: "A human-readable message describing what input is needed.",
        }),
        _meta: Schema.optionalKey(
          Schema.Union([
            Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate(
              {
                description:
                  "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
              },
            ),
            Schema.Null,
          ]),
        ),
        mode: Schema.String.annotate({
          description:
            "Custom or future elicitation mode.\n\nValues beginning with `_` are reserved for implementation-specific\nextensions. Unknown values that do not begin with `_` are reserved for\nfuture ACP variants.",
        }).check(
          Schema.isPattern(new RegExp("^(?!(?:\\x66orm|\\x75rl)$)[\\s\\S]*$")).annotate({
            expected: "a string matching the RegExp ^(?!(?:\\x66orm|\\x75rl)$)[\\s\\S]*$",
          }),
        ),
        sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
          description: "The session this elicitation is tied to.",
        }),
        toolCallId: Schema.optionalKey(
          Schema.Union([ToolCallId, Schema.Null]).annotate({
            description:
              "Optional tool call within the session.\n\nOptional. Omitted and `null` are equivalent and mean the elicitation is scoped to the\nsession without a specific tool call.",
          }),
        ),
      }),
      [Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" }))],
    ).annotate({
      title: "other",
      description:
        "Session-scoped elicitation, optionally tied to a specific tool call.\n\nWhen `tool_call_id` is set, the elicitation is tied to a specific tool call.\nThis is useful when an agent receives an elicitation from an MCP server\nduring a tool call and needs to redirect it to the user.",
    }),
    Schema.StructWithRest(
      Schema.Struct({
        message: Schema.String.annotate({
          description: "A human-readable message describing what input is needed.",
        }),
        _meta: Schema.optionalKey(
          Schema.Union([
            Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate(
              {
                description:
                  "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
              },
            ),
            Schema.Null,
          ]),
        ),
        mode: Schema.String.annotate({
          description:
            "Custom or future elicitation mode.\n\nValues beginning with `_` are reserved for implementation-specific\nextensions. Unknown values that do not begin with `_` are reserved for\nfuture ACP variants.",
        }).check(
          Schema.isPattern(new RegExp("^(?!(?:\\x66orm|\\x75rl)$)[\\s\\S]*$")).annotate({
            expected: "a string matching the RegExp ^(?!(?:\\x66orm|\\x75rl)$)[\\s\\S]*$",
          }),
        ),
        requestId: Schema.suspend((): Schema.Codec<RequestId> => RequestId).annotate({
          description: "The request this elicitation is tied to.",
        }),
      }),
      [Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" }))],
    ).annotate({
      title: "other",
      description:
        "Request-scoped elicitation, tied to a specific JSON-RPC request outside of a session\n(e.g., during auth/configuration phases before any session is started).",
    }),
  ]),
]).annotate({ identifier: "CreateElicitationRequest" });

export type SuggestNesResponse = {
  readonly suggestions: ReadonlyArray<NesSuggestion>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SuggestNesResponse = Schema.Struct({
  suggestions: Schema.Array(NesSuggestion).annotate({ description: "The list of suggestions." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "Response to `nes/suggest`.", identifier: "SuggestNesResponse" });

export type SuggestNesRequest = {
  readonly sessionId: SessionId;
  readonly uri: string;
  readonly version: number;
  readonly position: Position;
  readonly selection?: Range | null;
  readonly triggerKind: NesTriggerKind;
  readonly context?: NesSuggestContext | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SuggestNesRequest = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The session ID for this request.",
  }),
  uri: Schema.String.annotate({ description: "The URI of the document to suggest for." }),
  version: Schema.Number.annotate({
    description: "The version number of the document.",
    format: "int64",
  }).check(Schema.isInt().annotate({ expected: "an integer" })),
  position: Schema.suspend((): Schema.Codec<Position> => Position).annotate({
    description: "The current cursor position.",
  }),
  selection: Schema.optionalKey(
    Schema.Union([Range, Schema.Null]).annotate({
      description: "The current text selection range, if any.",
    }),
  ),
  triggerKind: Schema.suspend((): Schema.Codec<NesTriggerKind> => NesTriggerKind).annotate({
    description: "What triggered this suggestion request.",
  }),
  context: Schema.optionalKey(
    Schema.Union([NesSuggestContext, Schema.Null]).annotate({
      description: "Context for the suggestion, included based on agent capabilities.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "Request for a code suggestion.", identifier: "SuggestNesRequest" });

export type InitializeRequest = {
  readonly protocolVersion: ProtocolVersion;
  readonly clientCapabilities?: ClientCapabilities;
  readonly clientInfo?: Implementation | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const InitializeRequest = Schema.Struct({
  protocolVersion: Schema.suspend((): Schema.Codec<ProtocolVersion> => ProtocolVersion).annotate({
    description: "The latest protocol version supported by the client.",
  }),
  clientCapabilities: Schema.optionalKey(
    Schema.suspend((): Schema.Codec<ClientCapabilities> => ClientCapabilities).annotate({
      description: "Capabilities supported by the client.",
      default: {
        fs: { readTextFile: false, writeTextFile: false },
        terminal: false,
        auth: { terminal: false },
      },
    }),
  ),
  clientInfo: Schema.optionalKey(
    Schema.Union([Implementation, Schema.Null]).annotate({
      description:
        "Information about the Client name and version sent to the Agent.\n\nNote: in future versions of the protocol, this will be required.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Request parameters for the initialize method.\n\nSent by the client to establish connection and negotiate capabilities.\n\nSee protocol docs: [Initialization](https://agentclientprotocol.com/protocol/initialization)",
  identifier: "InitializeRequest",
});

export type AgentCapabilities = {
  readonly loadSession?: boolean;
  readonly promptCapabilities?: PromptCapabilities;
  readonly mcpCapabilities?: McpCapabilities;
  readonly sessionCapabilities?: SessionCapabilities;
  readonly auth?: AgentAuthCapabilities;
  readonly providers?: ProvidersCapabilities | null;
  readonly nes?: NesCapabilities | null;
  readonly positionEncoding?: PositionEncodingKind | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const AgentCapabilities = Schema.Struct({
  loadSession: Schema.optionalKey(
    Schema.Boolean.annotate({
      description: "Whether the agent supports `session/load`.",
      default: false,
    }),
  ),
  promptCapabilities: Schema.optionalKey(
    Schema.suspend((): Schema.Codec<PromptCapabilities> => PromptCapabilities).annotate({
      description: "Prompt capabilities supported by the agent.",
      default: { image: false, audio: false, embeddedContext: false },
    }),
  ),
  mcpCapabilities: Schema.optionalKey(
    Schema.suspend((): Schema.Codec<McpCapabilities> => McpCapabilities).annotate({
      description: "MCP capabilities supported by the agent.",
      default: { http: false, sse: false, acp: false },
    }),
  ),
  sessionCapabilities: Schema.optionalKey(
    Schema.suspend((): Schema.Codec<SessionCapabilities> => SessionCapabilities).annotate({
      description: "Session lifecycle and prompt capabilities advertised by the agent.",
      default: {},
    }),
  ),
  auth: Schema.optionalKey(
    Schema.suspend((): Schema.Codec<AgentAuthCapabilities> => AgentAuthCapabilities).annotate({
      description: "Authentication-related capabilities supported by the agent.",
      default: {},
    }),
  ),
  providers: Schema.optionalKey(
    Schema.Union([ProvidersCapabilities, Schema.Null]).annotate({
      description:
        "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nProvider configuration capabilities supported by the agent.\n\nOptional. Omitted or `null` both mean the agent does not advertise support.\nSupplying `{}` means the agent supports provider configuration methods.",
    }),
  ),
  nes: Schema.optionalKey(
    Schema.Union([NesCapabilities, Schema.Null]).annotate({
      description:
        "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nNES (Next Edit Suggestions) capabilities supported by the agent.\n\nOptional. Omitted or `null` both mean the agent does not advertise support\nfor NES methods.",
    }),
  ),
  positionEncoding: Schema.optionalKey(
    Schema.Union([PositionEncodingKind, Schema.Null]).annotate({
      description:
        "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nThe position encoding selected by the agent from the client's supported encodings.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Capabilities supported by the agent.\n\nAdvertised during initialization to inform the client about\navailable features and content types.\n\nSee protocol docs: [Agent Capabilities](https://agentclientprotocol.com/protocol/initialization#agent-capabilities)",
  identifier: "AgentCapabilities",
});

export type RequestPermissionRequest = {
  readonly sessionId: SessionId;
  readonly toolCall: ToolCallUpdate;
  readonly options: ReadonlyArray<PermissionOption>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const RequestPermissionRequest = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The session ID for this request.",
  }),
  toolCall: Schema.suspend((): Schema.Codec<ToolCallUpdate> => ToolCallUpdate).annotate({
    description: "Details about the tool call requiring permission.",
  }),
  options: Schema.Array(PermissionOption).annotate({
    description: "Available permission options for the user to choose from.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Request for user permission to execute a tool call.\n\nSent when the agent needs authorization before performing a sensitive operation.\n\nSee protocol docs: [Requesting Permission](https://agentclientprotocol.com/protocol/tool-calls#requesting-permission)",
  identifier: "RequestPermissionRequest",
});

export type SessionUpdate =
  | {
      readonly sessionUpdate: "user_message_chunk";
      readonly content: ContentBlock;
      readonly messageId?: MessageId | null;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly sessionUpdate: "agent_message_chunk";
      readonly content: ContentBlock;
      readonly messageId?: MessageId | null;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly sessionUpdate: "agent_thought_chunk";
      readonly content: ContentBlock;
      readonly messageId?: MessageId | null;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly sessionUpdate: "tool_call";
      readonly toolCallId: ToolCallId;
      readonly title: string;
      readonly name?: string | null;
      readonly kind?: ToolKind;
      readonly status?: ToolCallStatus;
      readonly content?: ReadonlyArray<ToolCallContent>;
      readonly locations?: ReadonlyArray<ToolCallLocation>;
      readonly rawInput?: Schema.Json;
      readonly rawOutput?: Schema.Json;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly sessionUpdate: "tool_call_update";
      readonly toolCallId: ToolCallId;
      readonly kind?: ToolKind | null;
      readonly status?: ToolCallStatus | null;
      readonly title?: string | null;
      readonly name?: string | null;
      readonly content?: ReadonlyArray<ToolCallContent> | null;
      readonly locations?: ReadonlyArray<ToolCallLocation> | null;
      readonly rawInput?: Schema.Json;
      readonly rawOutput?: Schema.Json;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly sessionUpdate: "plan";
      readonly entries: ReadonlyArray<PlanEntry>;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly sessionUpdate: "plan_update";
      readonly plan: PlanUpdateContent;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly sessionUpdate: "plan_removed";
      readonly planId: PlanId;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly sessionUpdate: "available_commands_update";
      readonly availableCommands: ReadonlyArray<AvailableCommand>;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly sessionUpdate: "current_mode_update";
      readonly currentModeId: SessionModeId;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly sessionUpdate: "config_option_update";
      readonly configOptions: ReadonlyArray<SessionConfigOption>;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly sessionUpdate: "session_info_update";
      readonly title?: string | null;
      readonly updatedAt?: string | null;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly sessionUpdate: "usage_update";
      readonly used: number;
      readonly size: number;
      readonly cost?: Cost | null;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly sessionUpdate: "compaction_update";
      readonly compactionId: CompactionId;
      readonly status: CompactionStatus;
      readonly summary?: ReadonlyArray<ContentBlock> | null;
      readonly error?: string | null;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    }
  | {
      readonly sessionUpdate: "compaction_summary_chunk";
      readonly compactionId: CompactionId;
      readonly content: ContentBlock;
      readonly _meta?: { readonly [x: string]: Schema.Json } | null;
    };
export const SessionUpdate = Schema.Union([
  Schema.Struct({
    sessionUpdate: Schema.Literal("user_message_chunk"),
    content: Schema.suspend((): Schema.Codec<ContentBlock> => ContentBlock).annotate({
      description: "A single item of content",
    }),
    messageId: Schema.optionalKey(
      Schema.Union([MessageId, Schema.Null]).annotate({
        description:
          "A unique identifier for the message this chunk belongs to.\n\nAll chunks belonging to the same message share the same `messageId`.\nA change in `messageId` indicates a new message has started.",
      }),
    ),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "A streamed item of content" }),
  Schema.Struct({
    sessionUpdate: Schema.Literal("agent_message_chunk"),
    content: Schema.suspend((): Schema.Codec<ContentBlock> => ContentBlock).annotate({
      description: "A single item of content",
    }),
    messageId: Schema.optionalKey(
      Schema.Union([MessageId, Schema.Null]).annotate({
        description:
          "A unique identifier for the message this chunk belongs to.\n\nAll chunks belonging to the same message share the same `messageId`.\nA change in `messageId` indicates a new message has started.",
      }),
    ),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "A streamed item of content" }),
  Schema.Struct({
    sessionUpdate: Schema.Literal("agent_thought_chunk"),
    content: Schema.suspend((): Schema.Codec<ContentBlock> => ContentBlock).annotate({
      description: "A single item of content",
    }),
    messageId: Schema.optionalKey(
      Schema.Union([MessageId, Schema.Null]).annotate({
        description:
          "A unique identifier for the message this chunk belongs to.\n\nAll chunks belonging to the same message share the same `messageId`.\nA change in `messageId` indicates a new message has started.",
      }),
    ),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "A streamed item of content" }),
  Schema.Struct({
    sessionUpdate: Schema.Literal("tool_call"),
    toolCallId: Schema.suspend((): Schema.Codec<ToolCallId> => ToolCallId).annotate({
      description: "Unique identifier for this tool call within the session.",
    }),
    title: Schema.String.annotate({
      description: "Human-readable title describing what the tool is doing.",
    }),
    name: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description:
            "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nProgrammatic name of the tool being invoked.\n\nThis field is optional. Omitting it or sending `null` both mean that no\ntool name is available.",
        }),
        Schema.Null,
      ]),
    ),
    kind: Schema.optionalKey(
      Schema.suspend((): Schema.Codec<ToolKind> => ToolKind).annotate({
        description:
          "The category of tool being invoked.\nHelps clients choose appropriate icons and UI treatment.",
      }),
    ),
    status: Schema.optionalKey(
      Schema.suspend((): Schema.Codec<ToolCallStatus> => ToolCallStatus).annotate({
        description: "Current execution status of the tool call.",
      }),
    ),
    content: Schema.optionalKey(
      Schema.Array(ToolCallContent).annotate({ description: "Content produced by the tool call." }),
    ),
    locations: Schema.optionalKey(
      Schema.Array(ToolCallLocation).annotate({
        description:
          'File locations affected by this tool call.\nEnables "follow-along" features in clients.',
      }),
    ),
    rawInput: Schema.optionalKey(
      Schema.Json.annotate({
        expected: "JSON value",
        description: "Raw input parameters sent to the tool.",
      }),
    ),
    rawOutput: Schema.optionalKey(
      Schema.Json.annotate({
        expected: "JSON value",
        description: "Raw output returned by the tool.",
      }),
    ),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description:
      "Represents a tool call that the language model has requested.\n\nTool calls are actions that the agent executes on behalf of the language model,\nsuch as reading files, executing code, or fetching data from external sources.\n\nSee protocol docs: [Tool Calls](https://agentclientprotocol.com/protocol/tool-calls)",
  }),
  Schema.Struct({
    sessionUpdate: Schema.Literal("tool_call_update"),
    toolCallId: Schema.suspend((): Schema.Codec<ToolCallId> => ToolCallId).annotate({
      description: "The ID of the tool call being updated.",
    }),
    kind: Schema.optionalKey(
      Schema.Union([ToolKind, Schema.Null]).annotate({ description: "Update the tool kind." }),
    ),
    status: Schema.optionalKey(
      Schema.Union([ToolCallStatus, Schema.Null]).annotate({
        description: "Update the execution status.",
      }),
    ),
    title: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({ description: "Update the human-readable title." }),
        Schema.Null,
      ]),
    ),
    name: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description:
            "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nUpdate the programmatic name of the tool being invoked.\n\nThis field is optional. Omitting it or sending `null` both mean that\nthe existing name is left unchanged.",
        }),
        Schema.Null,
      ]),
    ),
    content: Schema.optionalKey(
      Schema.Union([
        Schema.Array(ToolCallContent).annotate({ description: "Replace the content collection." }),
        Schema.Null,
      ]),
    ),
    locations: Schema.optionalKey(
      Schema.Union([
        Schema.Array(ToolCallLocation).annotate({
          description: "Replace the locations collection.",
        }),
        Schema.Null,
      ]),
    ),
    rawInput: Schema.optionalKey(
      Schema.Json.annotate({ expected: "JSON value", description: "Update the raw input." }),
    ),
    rawOutput: Schema.optionalKey(
      Schema.Json.annotate({ expected: "JSON value", description: "Update the raw output." }),
    ),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description:
      "An update to an existing tool call.\n\nUsed to report progress and results as tools execute. All fields except\nthe tool call ID are optional - only changed fields need to be included.\n\nSee protocol docs: [Updating](https://agentclientprotocol.com/protocol/tool-calls#updating)",
  }),
  Schema.Struct({
    sessionUpdate: Schema.Literal("plan"),
    entries: Schema.Array(PlanEntry).annotate({
      description:
        "The list of tasks to be accomplished.\n\nWhen updating a plan, the agent must send a complete list of all entries\nwith their current status. The client replaces the entire plan with each update.",
    }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description:
      "An execution plan for accomplishing complex tasks.\n\nPlans consist of multiple entries representing individual tasks or goals.\nAgents report plans to clients to provide visibility into their execution strategy.\nPlans can evolve during execution as the agent discovers new requirements or completes tasks.\n\nSee protocol docs: [Agent Plan](https://agentclientprotocol.com/protocol/agent-plan)",
  }),
  Schema.Struct({
    sessionUpdate: Schema.Literal("plan_update"),
    plan: Schema.suspend((): Schema.Codec<PlanUpdateContent> => PlanUpdateContent).annotate({
      description: "The updated plan content.",
    }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description:
      "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nA content update for a plan identified by ID.",
  }),
  Schema.Struct({
    sessionUpdate: Schema.Literal("plan_removed"),
    planId: Schema.suspend((): Schema.Codec<PlanId> => PlanId).annotate({
      description: "The plan ID to remove.",
    }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description:
      "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nRemoval notice for a plan identified by ID.",
  }),
  Schema.Struct({
    sessionUpdate: Schema.Literal("available_commands_update"),
    availableCommands: Schema.Array(AvailableCommand).annotate({
      description: "Commands the agent can execute",
    }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "Available commands are ready or have changed" }),
  Schema.Struct({
    sessionUpdate: Schema.Literal("current_mode_update"),
    currentModeId: Schema.suspend((): Schema.Codec<SessionModeId> => SessionModeId).annotate({
      description: "The ID of the current mode",
    }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description:
      "The current mode of the session has changed\n\nSee protocol docs: [Session Modes](https://agentclientprotocol.com/protocol/session-modes)",
  }),
  Schema.Struct({
    sessionUpdate: Schema.Literal("config_option_update"),
    configOptions: Schema.Array(SessionConfigOption).annotate({
      description: "The full set of configuration options and their current values.",
    }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "Session configuration options have been updated." }),
  Schema.Struct({
    sessionUpdate: Schema.Literal("session_info_update"),
    title: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description: "Human-readable title for the session. Set to null to clear.",
        }),
        Schema.Null,
      ]),
    ),
    updatedAt: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description: "ISO 8601 timestamp of last activity. Set to null to clear.",
        }),
        Schema.Null,
      ]),
    ),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description:
      "Update to session metadata. All fields are optional to support partial updates.\n\nAgents send this notification to update session information like title or custom metadata.\nThis allows clients to display dynamic session names and track session state changes.",
  }),
  Schema.Struct({
    sessionUpdate: Schema.Literal("usage_update"),
    used: Schema.Number.annotate({ description: "Tokens currently in context.", format: "uint64" })
      .check(Schema.isInt().annotate({ expected: "an integer" }))
      .check(
        Schema.isGreaterThanOrEqualTo(0).annotate({
          expected: "a value greater than or equal to 0",
        }),
      ),
    size: Schema.Number.annotate({
      description: "Total context window size in tokens.",
      format: "uint64",
    })
      .check(Schema.isInt().annotate({ expected: "an integer" }))
      .check(
        Schema.isGreaterThanOrEqualTo(0).annotate({
          expected: "a value greater than or equal to 0",
        }),
      ),
    cost: Schema.optionalKey(
      Schema.Union([Cost, Schema.Null]).annotate({
        description: "Cumulative session cost (optional).",
      }),
    ),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description:
            "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({ description: "Context window and cost update for a session." }),
  Schema.Struct({
    sessionUpdate: Schema.Literal("compaction_update"),
    compactionId: Schema.suspend((): Schema.Codec<CompactionId> => CompactionId).annotate({
      description: "The Agent-owned ID of this compaction, unique within the session.",
    }),
    status: Schema.suspend((): Schema.Codec<CompactionStatus> => CompactionStatus).annotate({
      description: "Current lifecycle status.",
    }),
    summary: Schema.optionalKey(
      Schema.Union([
        Schema.Array(ContentBlock).annotate({
          description: "Complete replacement user-displayable summary retained by the compaction.",
        }),
        Schema.Null,
      ]),
    ),
    error: Schema.optionalKey(
      Schema.Union([
        Schema.String.annotate({
          description: "Human-readable description of why the compaction failed.",
        }),
        Schema.Null,
      ]),
    ),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description: "Extensible metadata patch for this compaction.",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description:
      "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nA context compaction upsert. The first update fixes the compaction's\ntimeline position. Later updates with the same ID patch that entity in place.\nAgents MUST only send this update when the Client advertised\n[`ClientSessionCapabilities::compaction`].\n\n`summary`, `error`, and `_meta` have patch semantics: omission leaves the\nstored value unchanged, `null` clears it, and a concrete value replaces it.\n`summary: []` also clears the retained summary. A non-empty summary is only\nvalid with `completed`; `error` is only valid with `failed`.",
  }),
  Schema.Struct({
    sessionUpdate: Schema.Literal("compaction_summary_chunk"),
    compactionId: Schema.suspend((): Schema.Codec<CompactionId> => CompactionId).annotate({
      description: "ID of the compaction whose summary receives this content.",
    }),
    content: Schema.suspend((): Schema.Codec<ContentBlock> => ContentBlock).annotate({
      description: "One content block to append.",
    }),
    _meta: Schema.optionalKey(
      Schema.Union([
        Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
          description: "Metadata scoped to this chunk. Omission and `null` both mean absent.",
        }),
        Schema.Null,
      ]),
    ),
  }).annotate({
    description:
      "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nA content block appended to the retained summary of an in-progress\ncompaction. Agents send chunks only after an `in_progress` update and before\nthe terminal update for the same ID. Agents MUST only send this update when\nthe Client advertised [`ClientSessionCapabilities::compaction`].",
  }),
]).annotate({
  description:
    "Different types of updates that can be sent during session processing.\n\nThese updates provide real-time feedback about the agent's progress.\n\nSee protocol docs: [Agent Reports Output](https://agentclientprotocol.com/protocol/prompt-turn#3-agent-reports-output)",
  identifier: "SessionUpdate",
});

export type NewSessionResponse = {
  readonly sessionId: SessionId;
  readonly modes?: SessionModeState | null;
  readonly configOptions?: ReadonlyArray<SessionConfigOption> | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NewSessionResponse = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description:
      "Unique identifier for the created session.\n\nUsed in all subsequent requests for this conversation.",
  }),
  modes: Schema.optionalKey(
    Schema.Union([SessionModeState, Schema.Null]).annotate({
      description:
        "Initial mode state if supported by the Agent\n\nSee protocol docs: [Session Modes](https://agentclientprotocol.com/protocol/session-modes)",
    }),
  ),
  configOptions: Schema.optionalKey(
    Schema.Union([
      Schema.Array(SessionConfigOption).annotate({
        description: "Initial session configuration options if supported by the Agent.",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Response from creating a new session.\n\nSee protocol docs: [Creating a Session](https://agentclientprotocol.com/protocol/session-setup#creating-a-session)",
  identifier: "NewSessionResponse",
});

export type LoadSessionResponse = {
  readonly modes?: SessionModeState | null;
  readonly configOptions?: ReadonlyArray<SessionConfigOption> | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const LoadSessionResponse = Schema.Struct({
  modes: Schema.optionalKey(
    Schema.Union([SessionModeState, Schema.Null]).annotate({
      description:
        "Initial mode state if supported by the Agent\n\nSee protocol docs: [Session Modes](https://agentclientprotocol.com/protocol/session-modes)",
    }),
  ),
  configOptions: Schema.optionalKey(
    Schema.Union([
      Schema.Array(SessionConfigOption).annotate({
        description: "Initial session configuration options if supported by the Agent.",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Response from loading an existing session.",
  identifier: "LoadSessionResponse",
});

export type ForkSessionResponse = {
  readonly sessionId: SessionId;
  readonly modes?: SessionModeState | null;
  readonly configOptions?: ReadonlyArray<SessionConfigOption> | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ForkSessionResponse = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "Unique identifier for the newly created forked session.",
  }),
  modes: Schema.optionalKey(
    Schema.Union([SessionModeState, Schema.Null]).annotate({
      description:
        "Initial mode state if supported by the Agent\n\nSee protocol docs: [Session Modes](https://agentclientprotocol.com/protocol/session-modes)",
    }),
  ),
  configOptions: Schema.optionalKey(
    Schema.Union([
      Schema.Array(SessionConfigOption).annotate({
        description: "Initial session configuration options if supported by the Agent.",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nResponse from forking an existing session.",
  identifier: "ForkSessionResponse",
});

export type ResumeSessionResponse = {
  readonly modes?: SessionModeState | null;
  readonly configOptions?: ReadonlyArray<SessionConfigOption> | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ResumeSessionResponse = Schema.Struct({
  modes: Schema.optionalKey(
    Schema.Union([SessionModeState, Schema.Null]).annotate({
      description:
        "Initial mode state if supported by the Agent\n\nSee protocol docs: [Session Modes](https://agentclientprotocol.com/protocol/session-modes)",
    }),
  ),
  configOptions: Schema.optionalKey(
    Schema.Union([
      Schema.Array(SessionConfigOption).annotate({
        description: "Initial session configuration options if supported by the Agent.",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Response from resuming an existing session.",
  identifier: "ResumeSessionResponse",
});

export type SetSessionConfigOptionResponse = {
  readonly configOptions: ReadonlyArray<SessionConfigOption>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SetSessionConfigOptionResponse = Schema.Struct({
  configOptions: Schema.Array(SessionConfigOption).annotate({
    description: "The full set of configuration options and their current values.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Response to `session/set_config_option` method.",
  identifier: "SetSessionConfigOptionResponse",
});

export type InitializeResponse = {
  readonly protocolVersion: ProtocolVersion;
  readonly agentCapabilities?: AgentCapabilities;
  readonly authMethods?: ReadonlyArray<AuthMethod>;
  readonly agentInfo?: Implementation | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const InitializeResponse = Schema.Struct({
  protocolVersion: Schema.suspend((): Schema.Codec<ProtocolVersion> => ProtocolVersion).annotate({
    description:
      "The protocol version the client specified if supported by the agent,\nor the latest protocol version supported by the agent.\n\nThe client should disconnect, if it doesn't support this version.",
  }),
  agentCapabilities: Schema.optionalKey(
    Schema.suspend((): Schema.Codec<AgentCapabilities> => AgentCapabilities).annotate({
      description: "Capabilities supported by the agent.",
      default: {
        loadSession: false,
        promptCapabilities: { image: false, audio: false, embeddedContext: false },
        mcpCapabilities: { http: false, sse: false, acp: false },
        sessionCapabilities: {},
        auth: {},
      },
    }),
  ),
  authMethods: Schema.optionalKey(
    Schema.Array(AuthMethod).annotate({
      description: "Authentication methods supported by the agent.",
      default: [],
    }),
  ),
  agentInfo: Schema.optionalKey(
    Schema.Union([Implementation, Schema.Null]).annotate({
      description:
        "Information about the Agent name and version sent to the Client.\n\nNote: in future versions of the protocol, this will be required.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Response to the `initialize` method.\n\nContains the negotiated protocol version and agent capabilities.\n\nSee protocol docs: [Initialization](https://agentclientprotocol.com/protocol/initialization)",
  identifier: "InitializeResponse",
});

export type SessionNotification = {
  readonly sessionId: SessionId;
  readonly update: SessionUpdate;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SessionNotification = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The ID of the session this update pertains to.",
  }),
  update: Schema.suspend((): Schema.Codec<SessionUpdate> => SessionUpdate).annotate({
    description: "The actual update content.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Notification containing a session update from the agent.\n\nUsed to stream real-time progress and results during prompt processing.\n\nSee protocol docs: [Agent Reports Output](https://agentclientprotocol.com/protocol/prompt-turn#3-agent-reports-output)",
  identifier: "SessionNotification",
});

export type AgentNotification = {
  readonly method: string;
  readonly params?:
    | SessionNotification
    | CompleteElicitationNotification
    | MessageMcpNotification
    | ExtNotification
    | null;
};
export const AgentNotification = Schema.Struct({
  method: Schema.String.annotate({ description: "The notification method name." }),
  params: Schema.optionalKey(
    Schema.Union([
      Schema.Union([
        Schema.suspend((): Schema.Codec<SessionNotification> => SessionNotification).annotate({
          title: "SessionNotification",
          description:
            "Handles session update notifications from the agent.\n\nThis is a notification endpoint (no response expected) that receives\nreal-time updates about session progress, including message chunks,\ntool calls, and execution plans.\n\nNote: Clients SHOULD continue accepting tool call updates even after\nsending a `session/cancel` notification, as the agent may send final\nupdates before responding with the cancelled stop reason.\n\nSee protocol docs: [Agent Reports Output](https://agentclientprotocol.com/protocol/prompt-turn#3-agent-reports-output)",
        }),
        Schema.suspend(
          (): Schema.Codec<CompleteElicitationNotification> => CompleteElicitationNotification,
        ).annotate({
          title: "CompleteElicitationNotification",
          description:
            "Notification that a URL-based elicitation has completed.\n\nSee protocol docs: [Elicitation](https://agentclientprotocol.com/protocol/elicitation#url-completion)",
        }),
        Schema.suspend((): Schema.Codec<MessageMcpNotification> => MessageMcpNotification).annotate(
          {
            title: "MessageMcpNotification",
            description:
              "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nReceives an MCP-over-ACP notification.",
          },
        ),
        Schema.suspend((): Schema.Codec<ExtNotification> => ExtNotification).annotate({
          title: "ExtNotification",
          description:
            "Handles extension notifications from the agent.\n\nAllows the Agent to send an arbitrary notification that is not part of the ACP spec.\nExtension notifications provide a way to send one-way messages for custom functionality\nwhile maintaining protocol compatibility.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
      ]).annotate({
        description:
          "All possible notifications that an agent can send to a client.\n\nThis enum is used internally for routing RPC notifications. You typically won't need\nto use this directly.\n\nNotifications do not expect a response.",
      }),
      Schema.Null,
    ]).annotate({ description: "Method-specific notification parameters." }),
  ),
}).annotate({ description: "A JSON-RPC notification object." });

export type AgentRequest = {
  readonly id: RequestId;
  readonly method: string;
  readonly params?:
    | WriteTextFileRequest
    | ReadTextFileRequest
    | RequestPermissionRequest
    | CreateTerminalRequest
    | TerminalOutputRequest
    | ReleaseTerminalRequest
    | WaitForTerminalExitRequest
    | KillTerminalRequest
    | CreateElicitationRequest
    | ConnectMcpRequest
    | MessageMcpRequest
    | DisconnectMcpRequest
    | ExtRequest
    | null;
};
export const AgentRequest = Schema.Struct({
  id: Schema.suspend((): Schema.Codec<RequestId> => RequestId).annotate({
    description: "The request id used to correlate the matching response.",
  }),
  method: Schema.String.annotate({ description: "The method name to invoke." }),
  params: Schema.optionalKey(
    Schema.Union([
      Schema.Union([
        Schema.suspend((): Schema.Codec<WriteTextFileRequest> => WriteTextFileRequest).annotate({
          title: "WriteTextFileRequest",
          description:
            "Writes content to a text file in the client's file system.\n\nOnly available if the client advertises the `fs.writeTextFile` capability.\nAllows the agent to create or modify files within the client's environment.\n\nSee protocol docs: [Client](https://agentclientprotocol.com/protocol/overview#client)",
        }),
        Schema.suspend((): Schema.Codec<ReadTextFileRequest> => ReadTextFileRequest).annotate({
          title: "ReadTextFileRequest",
          description:
            "Reads content from a text file in the client's file system.\n\nOnly available if the client advertises the `fs.readTextFile` capability.\nAllows the agent to access file contents within the client's environment.\n\nSee protocol docs: [Client](https://agentclientprotocol.com/protocol/overview#client)",
        }),
        Schema.suspend(
          (): Schema.Codec<RequestPermissionRequest> => RequestPermissionRequest,
        ).annotate({
          title: "RequestPermissionRequest",
          description:
            "Requests permission from the user for a tool call operation.\n\nCalled by the agent when it needs user authorization before executing\na potentially sensitive operation. The client should present the options\nto the user and return their decision.\n\nIf the client cancels the prompt turn via `session/cancel`, it MUST\nrespond to this request with `RequestPermissionOutcome::Cancelled`.\n\nSee protocol docs: [Requesting Permission](https://agentclientprotocol.com/protocol/tool-calls#requesting-permission)",
        }),
        Schema.suspend((): Schema.Codec<CreateTerminalRequest> => CreateTerminalRequest).annotate({
          title: "CreateTerminalRequest",
          description:
            "Executes a command in a new terminal\n\nOnly available if the `terminal` Client capability is set to `true`.\n\nReturns a `TerminalId` that can be used with other terminal methods\nto get the current output, wait for exit, and kill the command.\n\nThe `TerminalId` can also be used to embed the terminal in a tool call\nby using the `ToolCallContent::Terminal` variant.\n\nThe Agent is responsible for releasing the terminal by using the `terminal/release`\nmethod.\n\nSee protocol docs: [Terminals](https://agentclientprotocol.com/protocol/terminals)",
        }),
        Schema.suspend((): Schema.Codec<TerminalOutputRequest> => TerminalOutputRequest).annotate({
          title: "TerminalOutputRequest",
          description:
            "Gets the terminal output and exit status\n\nReturns the current content in the terminal without waiting for the command to exit.\nIf the command has already exited, the exit status is included.\n\nSee protocol docs: [Terminals](https://agentclientprotocol.com/protocol/terminals)",
        }),
        Schema.suspend((): Schema.Codec<ReleaseTerminalRequest> => ReleaseTerminalRequest).annotate(
          {
            title: "ReleaseTerminalRequest",
            description:
              "Releases a terminal\n\nThe command is killed if it hasn't exited yet. Use `terminal/wait_for_exit`\nto wait for the command to exit before releasing the terminal.\n\nAfter release, the `TerminalId` can no longer be used with other `terminal/*` methods,\nbut tool calls that already contain it, continue to display its output.\n\nThe `terminal/kill` method can be used to terminate the command without releasing\nthe terminal, allowing the Agent to call `terminal/output` and other methods.\n\nSee protocol docs: [Terminals](https://agentclientprotocol.com/protocol/terminals)",
          },
        ),
        Schema.suspend(
          (): Schema.Codec<WaitForTerminalExitRequest> => WaitForTerminalExitRequest,
        ).annotate({
          title: "WaitForTerminalExitRequest",
          description:
            "Waits for the terminal command to exit and return its exit status\n\nSee protocol docs: [Terminals](https://agentclientprotocol.com/protocol/terminals)",
        }),
        Schema.suspend((): Schema.Codec<KillTerminalRequest> => KillTerminalRequest).annotate({
          title: "KillTerminalRequest",
          description:
            "Kills the terminal command without releasing the terminal\n\nWhile `terminal/release` will also kill the command, this method will keep\nthe `TerminalId` valid so it can be used with other methods.\n\nThis method can be helpful when implementing command timeouts which terminate\nthe command as soon as elapsed, and then get the final output so it can be sent\nto the model.\n\nNote: Call `terminal/release` when `TerminalId` is no longer needed.\n\nSee protocol docs: [Terminals](https://agentclientprotocol.com/protocol/terminals)",
        }),
        Schema.suspend(
          (): Schema.Codec<CreateElicitationRequest> => CreateElicitationRequest,
        ).annotate({
          title: "CreateElicitationRequest",
          description:
            "Requests structured user input via a form or URL.\n\nSee protocol docs: [Elicitation](https://agentclientprotocol.com/protocol/elicitation)",
        }),
        Schema.suspend((): Schema.Codec<ConnectMcpRequest> => ConnectMcpRequest).annotate({
          title: "ConnectMcpRequest",
          description:
            "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nOpens an MCP-over-ACP connection.",
        }),
        Schema.suspend((): Schema.Codec<MessageMcpRequest> => MessageMcpRequest).annotate({
          title: "MessageMcpRequest",
          description:
            "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nExchanges an MCP-over-ACP message.",
        }),
        Schema.suspend((): Schema.Codec<DisconnectMcpRequest> => DisconnectMcpRequest).annotate({
          title: "DisconnectMcpRequest",
          description:
            "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nCloses an MCP-over-ACP connection.",
        }),
        Schema.suspend((): Schema.Codec<ExtRequest> => ExtRequest).annotate({
          title: "ExtMethodRequest",
          description:
            "Handles extension method requests from the agent.\n\nAllows the Agent to send an arbitrary request that is not part of the ACP spec.\nExtension methods provide a way to add custom functionality while maintaining\nprotocol compatibility.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
      ]).annotate({
        description:
          "All possible requests that an agent can send to a client.\n\nThis enum is used internally for routing RPC requests. You typically won't need\nto use this directly.\n\nThis enum encompasses all method calls from agent to client.",
      }),
      Schema.Null,
    ]).annotate({ description: "Method-specific request parameters." }),
  ),
}).annotate({ description: "A JSON-RPC request object." });

export type AgentResponse =
  | {
      readonly id: RequestId;
      readonly result:
        | InitializeResponse
        | AuthenticateResponse
        | ListProvidersResponse
        | SetProviderResponse
        | DisableProviderResponse
        | LogoutResponse
        | NewSessionResponse
        | LoadSessionResponse
        | ListSessionsResponse
        | DeleteSessionResponse
        | ForkSessionResponse
        | ResumeSessionResponse
        | CloseSessionResponse
        | SetSessionModeResponse
        | SetSessionConfigOptionResponse
        | PromptResponse
        | StartNesResponse
        | SuggestNesResponse
        | CloseNesResponse
        | ExtResponse
        | MessageMcpResponse;
    }
  | { readonly id: RequestId; readonly error: Error };
export const AgentResponse = Schema.Union([
  Schema.Struct({
    id: Schema.suspend((): Schema.Codec<RequestId> => RequestId).annotate({
      description: "The id of the request this response answers.",
    }),
    result: Schema.Union([
      Schema.suspend((): Schema.Codec<InitializeResponse> => InitializeResponse).annotate({
        title: "InitializeResponse",
        description: "Successful result returned for a `initialize` request.",
      }),
      Schema.suspend((): Schema.Codec<AuthenticateResponse> => AuthenticateResponse).annotate({
        title: "AuthenticateResponse",
        description: "Successful result returned for a `authenticate` request.",
      }),
      Schema.suspend((): Schema.Codec<ListProvidersResponse> => ListProvidersResponse).annotate({
        title: "ListProvidersResponse",
        description: "Successful result returned for a `providers/list` request.",
      }),
      Schema.suspend((): Schema.Codec<SetProviderResponse> => SetProviderResponse).annotate({
        title: "SetProviderResponse",
        description: "Successful result returned for a `providers/set` request.",
      }),
      Schema.suspend((): Schema.Codec<DisableProviderResponse> => DisableProviderResponse).annotate(
        {
          title: "DisableProviderResponse",
          description: "Successful result returned for a `providers/disable` request.",
        },
      ),
      Schema.suspend((): Schema.Codec<LogoutResponse> => LogoutResponse).annotate({
        title: "LogoutResponse",
        description: "Successful result returned for a `logout` request.",
      }),
      Schema.suspend((): Schema.Codec<NewSessionResponse> => NewSessionResponse).annotate({
        title: "NewSessionResponse",
        description: "Successful result returned for a `session/new` request.",
      }),
      Schema.suspend((): Schema.Codec<LoadSessionResponse> => LoadSessionResponse).annotate({
        title: "LoadSessionResponse",
        description: "Successful result returned for a `session/load` request.",
      }),
      Schema.suspend((): Schema.Codec<ListSessionsResponse> => ListSessionsResponse).annotate({
        title: "ListSessionsResponse",
        description: "Successful result returned for a `session/list` request.",
      }),
      Schema.suspend((): Schema.Codec<DeleteSessionResponse> => DeleteSessionResponse).annotate({
        title: "DeleteSessionResponse",
        description: "Successful result returned for a `session/delete` request.",
      }),
      Schema.suspend((): Schema.Codec<ForkSessionResponse> => ForkSessionResponse).annotate({
        title: "ForkSessionResponse",
        description: "Successful result returned for a `session/fork` request.",
      }),
      Schema.suspend((): Schema.Codec<ResumeSessionResponse> => ResumeSessionResponse).annotate({
        title: "ResumeSessionResponse",
        description: "Successful result returned for a `session/resume` request.",
      }),
      Schema.suspend((): Schema.Codec<CloseSessionResponse> => CloseSessionResponse).annotate({
        title: "CloseSessionResponse",
        description: "Successful result returned for a `session/close` request.",
      }),
      Schema.suspend((): Schema.Codec<SetSessionModeResponse> => SetSessionModeResponse).annotate({
        title: "SetSessionModeResponse",
        description: "Successful result returned for a `session/set_mode` request.",
      }),
      Schema.suspend(
        (): Schema.Codec<SetSessionConfigOptionResponse> => SetSessionConfigOptionResponse,
      ).annotate({
        title: "SetSessionConfigOptionResponse",
        description: "Successful result returned for a `session/set_config_option` request.",
      }),
      Schema.suspend((): Schema.Codec<PromptResponse> => PromptResponse).annotate({
        title: "PromptResponse",
        description: "Successful result returned for a `session/prompt` request.",
      }),
      Schema.suspend((): Schema.Codec<StartNesResponse> => StartNesResponse).annotate({
        title: "StartNesResponse",
        description: "Successful result returned for a `nes/start` request.",
      }),
      Schema.suspend((): Schema.Codec<SuggestNesResponse> => SuggestNesResponse).annotate({
        title: "SuggestNesResponse",
        description: "Successful result returned for a `nes/suggest` request.",
      }),
      Schema.suspend((): Schema.Codec<CloseNesResponse> => CloseNesResponse).annotate({
        title: "CloseNesResponse",
        description: "Successful result returned for a `nes/close` request.",
      }),
      Schema.suspend((): Schema.Codec<ExtResponse> => ExtResponse).annotate({
        title: "ExtMethodResponse",
        description:
          "Successful result returned by an extension method outside the core ACP method set.",
      }),
      Schema.suspend((): Schema.Codec<MessageMcpResponse> => MessageMcpResponse).annotate({
        title: "MessageMcpResponse",
        description: "Successful result returned by an MCP-over-ACP `mcp/message` request.",
      }),
    ]).annotate({ description: "Method-specific response data." }),
  }).annotate({ title: "Result", description: "A successful JSON-RPC response." }),
  Schema.Struct({
    id: Schema.suspend((): Schema.Codec<RequestId> => RequestId).annotate({
      description: "The id of the request this response answers.",
    }),
    error: Schema.suspend((): Schema.Codec<Error> => Error).annotate({
      description: "Method-specific error data.",
    }),
  }).annotate({ title: "Error", description: "A failed JSON-RPC response." }),
]).annotate({ description: "A JSON-RPC response object." });

export type AudioContent = {
  readonly annotations?: Annotations | null;
  readonly data: string;
  readonly mimeType: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const AudioContent = Schema.Struct({
  annotations: Schema.optionalKey(
    Schema.Union([Annotations, Schema.Null]).annotate({
      description:
        "Optional annotations that help clients decide how to display or route this content.",
    }),
  ),
  data: Schema.String.annotate({ description: "Base64-encoded media payload." }),
  mimeType: Schema.String.annotate({
    description: "MIME type describing the encoded media payload.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "Audio provided to or from an LLM." });

export type AuthMethodTerminal = {
  readonly id: AuthMethodId;
  readonly name: string;
  readonly description?: string | null;
  readonly args?: ReadonlyArray<string>;
  readonly env?: { readonly [x: string]: string };
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const AuthMethodTerminal = Schema.Struct({
  id: Schema.suspend((): Schema.Codec<AuthMethodId> => AuthMethodId).annotate({
    description: "Unique identifier for this authentication method.",
  }),
  name: Schema.String.annotate({
    description: "Human-readable name of the authentication method.",
  }),
  description: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "Optional description providing more details about this authentication method.",
      }),
      Schema.Null,
    ]),
  ),
  args: Schema.optionalKey(
    Schema.Array(Schema.String).annotate({
      description:
        "Additional arguments to append to the configured agent invocation for terminal auth.",
    }),
  ),
  env: Schema.optionalKey(
    Schema.Record(Schema.String, Schema.String).annotate({
      description:
        "Additional environment variables to set on the configured agent invocation for terminal auth.\nThese values override same-named variables in the base launch configuration.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Terminal-based authentication method.\n\nThe client runs the configured agent program as a separate interactive\nprocess for the user to authenticate via a TUI. Agents MUST advertise this\nmethod only when the client enabled its terminal authentication capability.\nA zero exit status signals success; any other termination signals failure.\nThe client MUST NOT pass this method to `authenticate`.",
});

export type AvailableCommandsUpdate = {
  readonly availableCommands: ReadonlyArray<AvailableCommand>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const AvailableCommandsUpdate = Schema.Struct({
  availableCommands: Schema.Array(AvailableCommand).annotate({
    description: "Commands the agent can execute",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "Available commands are ready or have changed" });

export type BooleanPropertySchema = {
  readonly title?: string | null;
  readonly description?: string | null;
  readonly default?: boolean | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const BooleanPropertySchema = Schema.Struct({
  title: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "Optional title for the property.\n\nOptional. Omitted and `null` are equivalent and mean no title is provided.",
      }),
      Schema.Null,
    ]),
  ),
  description: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "Human-readable description.\n\nOptional. Omitted and `null` are equivalent and mean no description is provided.",
      }),
      Schema.Null,
    ]),
  ),
  default: Schema.optionalKey(
    Schema.Union([
      Schema.Boolean.annotate({
        description:
          "Default value.\n\nOptional. Omitted and `null` are equivalent and mean no default value is provided.",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "Schema for boolean properties in an elicitation form." });

export type CancelRequestNotification = {
  readonly requestId: RequestId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const CancelRequestNotification = Schema.Struct({
  requestId: Schema.suspend((): Schema.Codec<RequestId> => RequestId).annotate({
    description: "The ID of the request to cancel.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Notification to cancel an ongoing request.\n\nSee protocol docs: [Cancellation](https://agentclientprotocol.com/protocol/cancellation)",
});

export type ClientNotification = {
  readonly method: string;
  readonly params?:
    | CancelNotification
    | DidOpenDocumentNotification
    | DidChangeDocumentNotification
    | DidCloseDocumentNotification
    | DidSaveDocumentNotification
    | DidFocusDocumentNotification
    | AcceptNesNotification
    | RejectNesNotification
    | MessageMcpNotification
    | ExtNotification
    | null;
};
export const ClientNotification = Schema.Struct({
  method: Schema.String.annotate({ description: "The notification method name." }),
  params: Schema.optionalKey(
    Schema.Union([
      Schema.Union([
        Schema.suspend((): Schema.Codec<CancelNotification> => CancelNotification).annotate({
          title: "CancelNotification",
          description:
            "Cancels ongoing operations for a session.\n\nThis is a notification sent by the client to cancel an ongoing prompt turn.\n\nUpon receiving this notification, the Agent SHOULD:\n- Stop all language model requests as soon as possible\n- Abort all tool call invocations in progress\n- Send any pending `session/update` notifications\n- Respond to the original `session/prompt` request with `StopReason::Cancelled`\n\nSee protocol docs: [Cancellation](https://agentclientprotocol.com/protocol/prompt-turn#cancellation)",
        }),
        Schema.suspend(
          (): Schema.Codec<DidOpenDocumentNotification> => DidOpenDocumentNotification,
        ).annotate({
          title: "DidOpenDocumentNotification",
          description: "**UNSTABLE**\n\nNotification sent when a file is opened in the editor.",
        }),
        Schema.suspend(
          (): Schema.Codec<DidChangeDocumentNotification> => DidChangeDocumentNotification,
        ).annotate({
          title: "DidChangeDocumentNotification",
          description: "**UNSTABLE**\n\nNotification sent when a file is edited.",
        }),
        Schema.suspend(
          (): Schema.Codec<DidCloseDocumentNotification> => DidCloseDocumentNotification,
        ).annotate({
          title: "DidCloseDocumentNotification",
          description: "**UNSTABLE**\n\nNotification sent when a file is closed.",
        }),
        Schema.suspend(
          (): Schema.Codec<DidSaveDocumentNotification> => DidSaveDocumentNotification,
        ).annotate({
          title: "DidSaveDocumentNotification",
          description: "**UNSTABLE**\n\nNotification sent when a file is saved.",
        }),
        Schema.suspend(
          (): Schema.Codec<DidFocusDocumentNotification> => DidFocusDocumentNotification,
        ).annotate({
          title: "DidFocusDocumentNotification",
          description:
            "**UNSTABLE**\n\nNotification sent when a file becomes the active editor tab.",
        }),
        Schema.suspend((): Schema.Codec<AcceptNesNotification> => AcceptNesNotification).annotate({
          title: "AcceptNesNotification",
          description: "**UNSTABLE**\n\nNotification sent when a suggestion is accepted.",
        }),
        Schema.suspend((): Schema.Codec<RejectNesNotification> => RejectNesNotification).annotate({
          title: "RejectNesNotification",
          description: "**UNSTABLE**\n\nNotification sent when a suggestion is rejected.",
        }),
        Schema.suspend((): Schema.Codec<MessageMcpNotification> => MessageMcpNotification).annotate(
          {
            title: "MessageMcpNotification",
            description:
              "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nSends an MCP-over-ACP notification.",
          },
        ),
        Schema.suspend((): Schema.Codec<ExtNotification> => ExtNotification).annotate({
          title: "ExtNotification",
          description:
            "Handles extension notifications from the client.\n\nExtension notifications provide a way to send one-way messages for custom functionality\nwhile maintaining protocol compatibility.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
      ]).annotate({
        description:
          "All possible notifications that a client can send to an agent.\n\nThis enum is used internally for routing RPC notifications. You typically won't need\nto use this directly.\n\nNotifications do not expect a response.",
      }),
      Schema.Null,
    ]).annotate({ description: "Method-specific notification parameters." }),
  ),
}).annotate({ description: "A JSON-RPC notification object." });

export type ClientRequest = {
  readonly id: RequestId;
  readonly method: string;
  readonly params?:
    | InitializeRequest
    | AuthenticateRequest
    | ListProvidersRequest
    | SetProviderRequest
    | DisableProviderRequest
    | LogoutRequest
    | NewSessionRequest
    | LoadSessionRequest
    | ListSessionsRequest
    | DeleteSessionRequest
    | ForkSessionRequest
    | ResumeSessionRequest
    | CloseSessionRequest
    | SetSessionModeRequest
    | SetSessionConfigOptionRequest
    | PromptRequest
    | StartNesRequest
    | SuggestNesRequest
    | CloseNesRequest
    | MessageMcpRequest
    | ExtRequest
    | null;
};
export const ClientRequest = Schema.Struct({
  id: Schema.suspend((): Schema.Codec<RequestId> => RequestId).annotate({
    description: "The request id used to correlate the matching response.",
  }),
  method: Schema.String.annotate({ description: "The method name to invoke." }),
  params: Schema.optionalKey(
    Schema.Union([
      Schema.Union([
        Schema.suspend((): Schema.Codec<InitializeRequest> => InitializeRequest).annotate({
          title: "InitializeRequest",
          description:
            "Establishes the connection with a client and negotiates protocol capabilities.\n\nThis method is called once at the beginning of the connection to:\n- Negotiate the protocol version to use\n- Exchange capability information between client and agent\n- Determine available authentication methods\n\nThe agent should respond with its supported protocol version and capabilities.\n\nSee protocol docs: [Initialization](https://agentclientprotocol.com/protocol/initialization)",
        }),
        Schema.suspend((): Schema.Codec<AuthenticateRequest> => AuthenticateRequest).annotate({
          title: "AuthenticateRequest",
          description:
            "Authenticates the client using the specified authentication method.\n\nCalled when the agent requires authentication before allowing session creation.\nThe client provides an authentication method ID that was advertised during\ninitialization and whose type defines the `authenticate` flow.\n\nAfter successful authentication, the client can proceed to create sessions with\n`new_session` without receiving an `auth_required` error.\n\nSee protocol docs: [Initialization](https://agentclientprotocol.com/protocol/initialization)",
        }),
        Schema.suspend((): Schema.Codec<ListProvidersRequest> => ListProvidersRequest).annotate({
          title: "ListProvidersRequest",
          description:
            "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nLists providers that can be configured by the client.",
        }),
        Schema.suspend((): Schema.Codec<SetProviderRequest> => SetProviderRequest).annotate({
          title: "SetProviderRequest",
          description:
            "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nReplaces the configuration for a provider.",
        }),
        Schema.suspend((): Schema.Codec<DisableProviderRequest> => DisableProviderRequest).annotate(
          {
            title: "DisableProviderRequest",
            description:
              "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nDisables a provider.",
          },
        ),
        Schema.suspend((): Schema.Codec<LogoutRequest> => LogoutRequest).annotate({
          title: "LogoutRequest",
          description:
            "Logs out of the current authenticated state.\n\nAfter a successful logout, all new sessions will require authentication.\nThere is no guarantee about the behavior of already running sessions.",
        }),
        Schema.suspend((): Schema.Codec<NewSessionRequest> => NewSessionRequest).annotate({
          title: "NewSessionRequest",
          description:
            "Creates a new conversation session with the agent.\n\nSessions represent independent conversation contexts with their own history and state.\n\nThe agent should:\n- Create a new session context\n- Connect to any specified MCP servers\n- Return a unique session ID for future requests\n\nMay return an `auth_required` error if the agent requires authentication.\n\nSee protocol docs: [Session Setup](https://agentclientprotocol.com/protocol/session-setup)",
        }),
        Schema.suspend((): Schema.Codec<LoadSessionRequest> => LoadSessionRequest).annotate({
          title: "LoadSessionRequest",
          description:
            "Loads an existing session to resume a previous conversation.\n\nThis method is only available if the agent advertises the `loadSession` capability.\n\nThe agent should:\n- Restore the session context and conversation history\n- Connect to the specified MCP servers\n- Stream the entire conversation history back to the client via notifications\n\nSee protocol docs: [Loading Sessions](https://agentclientprotocol.com/protocol/session-setup#loading-sessions)",
        }),
        Schema.suspend((): Schema.Codec<ListSessionsRequest> => ListSessionsRequest).annotate({
          title: "ListSessionsRequest",
          description:
            "Lists existing sessions known to the agent.\n\nThis method is only available if the agent advertises the `sessionCapabilities.list` capability.\n\nThe agent should return metadata about sessions with optional filtering and pagination support.",
        }),
        Schema.suspend((): Schema.Codec<DeleteSessionRequest> => DeleteSessionRequest).annotate({
          title: "DeleteSessionRequest",
          description:
            "Deletes an existing session from `session/list`.\n\nThis method is only available if the agent advertises the `sessionCapabilities.delete` capability.",
        }),
        Schema.suspend((): Schema.Codec<ForkSessionRequest> => ForkSessionRequest).annotate({
          title: "ForkSessionRequest",
          description:
            "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nForks an existing session to create a new independent session.\n\nThis method is only available if the agent advertises the `session.fork` capability.\n\nThe agent should create a new session with the same conversation context as the\noriginal, allowing operations like generating summaries without affecting the\noriginal session's history.",
        }),
        Schema.suspend((): Schema.Codec<ResumeSessionRequest> => ResumeSessionRequest).annotate({
          title: "ResumeSessionRequest",
          description:
            "Resumes an existing session without returning previous messages.\n\nThis method is only available if the agent advertises the `sessionCapabilities.resume` capability.\n\nThe agent should resume the session context, allowing the conversation to continue\nwithout replaying the message history (unlike `session/load`).",
        }),
        Schema.suspend((): Schema.Codec<CloseSessionRequest> => CloseSessionRequest).annotate({
          title: "CloseSessionRequest",
          description:
            "Closes an active session and frees up any resources associated with it.\n\nThis method is only available if the agent advertises the `sessionCapabilities.close` capability.\n\nThe agent must cancel any ongoing work (as if `session/cancel` was called)\nand then free up any resources associated with the session.",
        }),
        Schema.suspend((): Schema.Codec<SetSessionModeRequest> => SetSessionModeRequest).annotate({
          title: "SetSessionModeRequest",
          description:
            'Sets the current mode for a session.\n\nAllows switching between different agent modes (e.g., "ask", "architect", "code")\nthat affect system prompts, tool availability, and permission behaviors.\n\nThe mode must be one of the modes advertised in `availableModes` during session\ncreation or loading. Agents may also change modes autonomously and notify the\nclient via `current_mode_update` notifications.\n\nThis method can be called at any time during a session, whether the Agent is\nidle or actively generating a response.\n\nSee protocol docs: [Session Modes](https://agentclientprotocol.com/protocol/session-modes)',
        }),
        Schema.suspend(
          (): Schema.Codec<SetSessionConfigOptionRequest> => SetSessionConfigOptionRequest,
        ).annotate({
          title: "SetSessionConfigOptionRequest",
          description: "Sets the current value for a session configuration option.",
        }),
        Schema.suspend((): Schema.Codec<PromptRequest> => PromptRequest).annotate({
          title: "PromptRequest",
          description:
            "Processes a user prompt within a session.\n\nThis method handles the whole lifecycle of a prompt:\n- Receives user messages with optional context (files, images, etc.)\n- Processes the prompt using language models\n- Reports language model content and tool calls to the Clients\n- Requests permission to run tools\n- Executes any requested tool calls\n- Returns when the turn is complete with a stop reason\n\nSee protocol docs: [Prompt Turn](https://agentclientprotocol.com/protocol/prompt-turn)",
        }),
        Schema.suspend((): Schema.Codec<StartNesRequest> => StartNesRequest).annotate({
          title: "StartNesRequest",
          description:
            "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nStarts an NES session.",
        }),
        Schema.suspend((): Schema.Codec<SuggestNesRequest> => SuggestNesRequest).annotate({
          title: "SuggestNesRequest",
          description:
            "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nRequests a code suggestion.",
        }),
        Schema.suspend((): Schema.Codec<CloseNesRequest> => CloseNesRequest).annotate({
          title: "CloseNesRequest",
          description:
            "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nCloses an active NES session and frees up any resources associated with it.\n\nThe agent must cancel any ongoing work and then free up any resources\nassociated with the NES session.",
        }),
        Schema.suspend((): Schema.Codec<MessageMcpRequest> => MessageMcpRequest).annotate({
          title: "MessageMcpRequest",
          description:
            "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nExchanges an MCP-over-ACP message.",
        }),
        Schema.suspend((): Schema.Codec<ExtRequest> => ExtRequest).annotate({
          title: "ExtMethodRequest",
          description:
            "Handles extension method requests from the client.\n\nExtension methods provide a way to add custom functionality while maintaining\nprotocol compatibility.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
        }),
      ]).annotate({
        description:
          "All possible requests that a client can send to an agent.\n\nThis enum is used internally for routing RPC requests. You typically won't need\nto use this directly.\n\nThis enum encompasses all method calls from client to agent.",
      }),
      Schema.Null,
    ]).annotate({ description: "Method-specific request parameters." }),
  ),
}).annotate({ description: "A JSON-RPC request object." });

export type ClientResponse =
  | {
      readonly id: RequestId;
      readonly result:
        | WriteTextFileResponse
        | ReadTextFileResponse
        | RequestPermissionResponse
        | CreateTerminalResponse
        | TerminalOutputResponse
        | ReleaseTerminalResponse
        | WaitForTerminalExitResponse
        | KillTerminalResponse
        | CreateElicitationResponse
        | ConnectMcpResponse
        | DisconnectMcpResponse
        | MessageMcpResponse
        | ExtResponse;
    }
  | { readonly id: RequestId; readonly error: Error };
export const ClientResponse = Schema.Union([
  Schema.Struct({
    id: Schema.suspend((): Schema.Codec<RequestId> => RequestId).annotate({
      description: "The id of the request this response answers.",
    }),
    result: Schema.Union([
      Schema.suspend((): Schema.Codec<WriteTextFileResponse> => WriteTextFileResponse).annotate({
        title: "WriteTextFileResponse",
        description: "Successful result returned for a `fs/write_text_file` request.",
      }),
      Schema.suspend((): Schema.Codec<ReadTextFileResponse> => ReadTextFileResponse).annotate({
        title: "ReadTextFileResponse",
        description: "Successful result returned for a `fs/read_text_file` request.",
      }),
      Schema.suspend(
        (): Schema.Codec<RequestPermissionResponse> => RequestPermissionResponse,
      ).annotate({
        title: "RequestPermissionResponse",
        description: "Successful result returned for a `session/request_permission` request.",
      }),
      Schema.suspend((): Schema.Codec<CreateTerminalResponse> => CreateTerminalResponse).annotate({
        title: "CreateTerminalResponse",
        description: "Successful result returned for a `terminal/create` request.",
      }),
      Schema.suspend((): Schema.Codec<TerminalOutputResponse> => TerminalOutputResponse).annotate({
        title: "TerminalOutputResponse",
        description: "Successful result returned for a `terminal/output` request.",
      }),
      Schema.suspend((): Schema.Codec<ReleaseTerminalResponse> => ReleaseTerminalResponse).annotate(
        {
          title: "ReleaseTerminalResponse",
          description: "Successful result returned for a `terminal/release` request.",
        },
      ),
      Schema.suspend(
        (): Schema.Codec<WaitForTerminalExitResponse> => WaitForTerminalExitResponse,
      ).annotate({
        title: "WaitForTerminalExitResponse",
        description: "Successful result returned for a `terminal/wait_for_exit` request.",
      }),
      Schema.suspend((): Schema.Codec<KillTerminalResponse> => KillTerminalResponse).annotate({
        title: "KillTerminalResponse",
        description: "Successful result returned for a `terminal/kill` request.",
      }),
      Schema.suspend(
        (): Schema.Codec<CreateElicitationResponse> => CreateElicitationResponse,
      ).annotate({
        title: "CreateElicitationResponse",
        description: "Successful result returned for a `elicitation/create` request.",
      }),
      Schema.suspend((): Schema.Codec<ConnectMcpResponse> => ConnectMcpResponse).annotate({
        title: "ConnectMcpResponse",
        description: "Successful result returned for a `mcp/connect` request.",
      }),
      Schema.suspend((): Schema.Codec<DisconnectMcpResponse> => DisconnectMcpResponse).annotate({
        title: "DisconnectMcpResponse",
        description: "Successful result returned for a `mcp/disconnect` request.",
      }),
      Schema.suspend((): Schema.Codec<MessageMcpResponse> => MessageMcpResponse).annotate({
        title: "MessageMcpResponse",
        description: "Successful result returned by an MCP-over-ACP `mcp/message` request.",
      }),
      Schema.suspend((): Schema.Codec<ExtResponse> => ExtResponse).annotate({
        title: "ExtMethodResponse",
        description:
          "Successful result returned by an extension method outside the core ACP method set.",
      }),
    ]).annotate({ description: "Method-specific response data." }),
  }).annotate({ title: "Result", description: "A successful JSON-RPC response." }),
  Schema.Struct({
    id: Schema.suspend((): Schema.Codec<RequestId> => RequestId).annotate({
      description: "The id of the request this response answers.",
    }),
    error: Schema.suspend((): Schema.Codec<Error> => Error).annotate({
      description: "Method-specific error data.",
    }),
  }).annotate({ title: "Error", description: "A failed JSON-RPC response." }),
]).annotate({ description: "A JSON-RPC response object." });

export type CompactionSummaryChunk = {
  readonly compactionId: CompactionId;
  readonly content: ContentBlock;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const CompactionSummaryChunk = Schema.Struct({
  compactionId: Schema.suspend((): Schema.Codec<CompactionId> => CompactionId).annotate({
    description: "ID of the compaction whose summary receives this content.",
  }),
  content: Schema.suspend((): Schema.Codec<ContentBlock> => ContentBlock).annotate({
    description: "One content block to append.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description: "Metadata scoped to this chunk. Omission and `null` both mean absent.",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nA content block appended to the retained summary of an in-progress\ncompaction. Agents send chunks only after an `in_progress` update and before\nthe terminal update for the same ID. Agents MUST only send this update when\nthe Client advertised [`ClientSessionCapabilities::compaction`].",
});

export type CompactionUpdate = {
  readonly compactionId: CompactionId;
  readonly status: CompactionStatus;
  readonly summary?: ReadonlyArray<ContentBlock> | null;
  readonly error?: string | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const CompactionUpdate = Schema.Struct({
  compactionId: Schema.suspend((): Schema.Codec<CompactionId> => CompactionId).annotate({
    description: "The Agent-owned ID of this compaction, unique within the session.",
  }),
  status: Schema.suspend((): Schema.Codec<CompactionStatus> => CompactionStatus).annotate({
    description: "Current lifecycle status.",
  }),
  summary: Schema.optionalKey(
    Schema.Union([
      Schema.Array(ContentBlock).annotate({
        description: "Complete replacement user-displayable summary retained by the compaction.",
      }),
      Schema.Null,
    ]),
  ),
  error: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description: "Human-readable description of why the compaction failed.",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description: "Extensible metadata patch for this compaction.",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nA context compaction upsert. The first update fixes the compaction's\ntimeline position. Later updates with the same ID patch that entity in place.\nAgents MUST only send this update when the Client advertised\n[`ClientSessionCapabilities::compaction`].\n\n`summary`, `error`, and `_meta` have patch semantics: omission leaves the\nstored value unchanged, `null` clears it, and a concrete value replaces it.\n`summary: []` also clears the retained summary. A non-empty summary is only\nvalid with `completed`; `error` is only valid with `failed`.",
});

export type ConfigOptionUpdate = {
  readonly configOptions: ReadonlyArray<SessionConfigOption>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ConfigOptionUpdate = Schema.Struct({
  configOptions: Schema.Array(SessionConfigOption).annotate({
    description: "The full set of configuration options and their current values.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "Session configuration options have been updated." });

export type Content = {
  readonly content: ContentBlock;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const Content = Schema.Struct({
  content: Schema.suspend((): Schema.Codec<ContentBlock> => ContentBlock).annotate({
    description: "The actual content block.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "Standard content block (text, images, resources)." });

export type ContentChunk = {
  readonly content: ContentBlock;
  readonly messageId?: MessageId | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ContentChunk = Schema.Struct({
  content: Schema.suspend((): Schema.Codec<ContentBlock> => ContentBlock).annotate({
    description: "A single item of content",
  }),
  messageId: Schema.optionalKey(
    Schema.Union([MessageId, Schema.Null]).annotate({
      description:
        "A unique identifier for the message this chunk belongs to.\n\nAll chunks belonging to the same message share the same `messageId`.\nA change in `messageId` indicates a new message has started.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "A streamed item of content" });

export type CurrentModeUpdate = {
  readonly currentModeId: SessionModeId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const CurrentModeUpdate = Schema.Struct({
  currentModeId: Schema.suspend((): Schema.Codec<SessionModeId> => SessionModeId).annotate({
    description: "The ID of the current mode",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "The current mode of the session has changed\n\nSee protocol docs: [Session Modes](https://agentclientprotocol.com/protocol/session-modes)",
});

export type Diff = {
  readonly path: string;
  readonly oldText?: string | null;
  readonly newText: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const Diff = Schema.Struct({
  path: Schema.String.annotate({ description: "The absolute file path being modified." }),
  oldText: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({ description: "The original content (None for new files)." }),
      Schema.Null,
    ]),
  ),
  newText: Schema.String.annotate({ description: "The new content after modification." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "A diff representing file modifications.\n\nShows changes to files in a format suitable for display in the client UI.\n\nSee protocol docs: [Content](https://agentclientprotocol.com/protocol/tool-calls#content)",
});

export type ElicitationAcceptAction = {
  readonly content?: { readonly [x: string]: ElicitationContentValue } | null;
};
export const ElicitationAcceptAction = Schema.Struct({
  content: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, ElicitationContentValue).annotate({
        description:
          "The user-provided content, if any, as an object matching the requested schema.",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "The user accepted the elicitation and provided content." });

export type ElicitationFormMode =
  | {
      readonly requestedSchema: ElicitationSchema;
      readonly sessionId: SessionId;
      readonly toolCallId?: ToolCallId | null;
    }
  | { readonly requestedSchema: ElicitationSchema; readonly requestId: RequestId };
export const ElicitationFormMode = Schema.Union([
  Schema.Struct({
    requestedSchema: Schema.suspend(
      (): Schema.Codec<ElicitationSchema> => ElicitationSchema,
    ).annotate({ description: "A JSON Schema describing the form fields to present to the user." }),
    sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
      description: "The session this elicitation is tied to.",
    }),
    toolCallId: Schema.optionalKey(
      Schema.Union([ToolCallId, Schema.Null]).annotate({
        description:
          "Optional tool call within the session.\n\nOptional. Omitted and `null` are equivalent and mean the elicitation is scoped to the\nsession without a specific tool call.",
      }),
    ),
  }).annotate({
    description:
      "Session-scoped elicitation, optionally tied to a specific tool call.\n\nWhen `tool_call_id` is set, the elicitation is tied to a specific tool call.\nThis is useful when an agent receives an elicitation from an MCP server\nduring a tool call and needs to redirect it to the user.",
  }),
  Schema.Struct({
    requestedSchema: Schema.suspend(
      (): Schema.Codec<ElicitationSchema> => ElicitationSchema,
    ).annotate({ description: "A JSON Schema describing the form fields to present to the user." }),
    requestId: Schema.suspend((): Schema.Codec<RequestId> => RequestId).annotate({
      description: "The request this elicitation is tied to.",
    }),
  }).annotate({
    description:
      "Request-scoped elicitation, tied to a specific JSON-RPC request outside of a session\n(e.g., during auth/configuration phases before any session is started).",
  }),
]);

export type ElicitationRequestScope = { readonly requestId: RequestId };
export const ElicitationRequestScope = Schema.Struct({
  requestId: Schema.suspend((): Schema.Codec<RequestId> => RequestId).annotate({
    description: "The request this elicitation is tied to.",
  }),
}).annotate({
  description:
    "Request-scoped elicitation, tied to a specific JSON-RPC request outside of a session\n(e.g., during auth/configuration phases before any session is started).",
});

export type ElicitationSessionScope = {
  readonly sessionId: SessionId;
  readonly toolCallId?: ToolCallId | null;
};
export const ElicitationSessionScope = Schema.Struct({
  sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
    description: "The session this elicitation is tied to.",
  }),
  toolCallId: Schema.optionalKey(
    Schema.Union([ToolCallId, Schema.Null]).annotate({
      description:
        "Optional tool call within the session.\n\nOptional. Omitted and `null` are equivalent and mean the elicitation is scoped to the\nsession without a specific tool call.",
    }),
  ),
}).annotate({
  description:
    "Session-scoped elicitation, optionally tied to a specific tool call.\n\nWhen `tool_call_id` is set, the elicitation is tied to a specific tool call.\nThis is useful when an agent receives an elicitation from an MCP server\nduring a tool call and needs to redirect it to the user.",
});

export type ElicitationUrlMode =
  | {
      readonly elicitationId: ElicitationId;
      readonly url: string;
      readonly sessionId: SessionId;
      readonly toolCallId?: ToolCallId | null;
    }
  | { readonly elicitationId: ElicitationId; readonly url: string; readonly requestId: RequestId };
export const ElicitationUrlMode = Schema.Union([
  Schema.Struct({
    elicitationId: Schema.suspend((): Schema.Codec<ElicitationId> => ElicitationId).annotate({
      description: "The unique identifier for this elicitation.",
    }),
    url: Schema.String.annotate({ description: "The URL to direct the user to.", format: "uri" }),
    sessionId: Schema.suspend((): Schema.Codec<SessionId> => SessionId).annotate({
      description: "The session this elicitation is tied to.",
    }),
    toolCallId: Schema.optionalKey(
      Schema.Union([ToolCallId, Schema.Null]).annotate({
        description:
          "Optional tool call within the session.\n\nOptional. Omitted and `null` are equivalent and mean the elicitation is scoped to the\nsession without a specific tool call.",
      }),
    ),
  }).annotate({
    description:
      "Session-scoped elicitation, optionally tied to a specific tool call.\n\nWhen `tool_call_id` is set, the elicitation is tied to a specific tool call.\nThis is useful when an agent receives an elicitation from an MCP server\nduring a tool call and needs to redirect it to the user.",
  }),
  Schema.Struct({
    elicitationId: Schema.suspend((): Schema.Codec<ElicitationId> => ElicitationId).annotate({
      description: "The unique identifier for this elicitation.",
    }),
    url: Schema.String.annotate({ description: "The URL to direct the user to.", format: "uri" }),
    requestId: Schema.suspend((): Schema.Codec<RequestId> => RequestId).annotate({
      description: "The request this elicitation is tied to.",
    }),
  }).annotate({
    description:
      "Request-scoped elicitation, tied to a specific JSON-RPC request outside of a session\n(e.g., during auth/configuration phases before any session is started).",
  }),
]);

export type EmbeddedResource = {
  readonly annotations?: Annotations | null;
  readonly resource: EmbeddedResourceResource;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const EmbeddedResource = Schema.Struct({
  annotations: Schema.optionalKey(
    Schema.Union([Annotations, Schema.Null]).annotate({
      description:
        "Optional annotations that help clients decide how to display or route this content.",
    }),
  ),
  resource: Schema.suspend(
    (): Schema.Codec<EmbeddedResourceResource> => EmbeddedResourceResource,
  ).annotate({ description: "Embedded resource payload, either text or binary data." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "The contents of a resource, embedded into a prompt or tool call result.",
});

export type ImageContent = {
  readonly annotations?: Annotations | null;
  readonly data: string;
  readonly mimeType: string;
  readonly uri?: string | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ImageContent = Schema.Struct({
  annotations: Schema.optionalKey(
    Schema.Union([Annotations, Schema.Null]).annotate({
      description:
        "Optional annotations that help clients decide how to display or route this content.",
    }),
  ),
  data: Schema.String.annotate({ description: "Base64-encoded media payload." }),
  mimeType: Schema.String.annotate({
    description: "MIME type describing the encoded media payload.",
  }),
  uri: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description: "URI associated with this resource or media payload.",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "An image provided to or from an LLM." });

export type IntegerPropertySchema = {
  readonly title?: string | null;
  readonly description?: string | null;
  readonly minimum?: number | null;
  readonly maximum?: number | null;
  readonly default?: number | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const IntegerPropertySchema = Schema.Struct({
  title: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "Optional title for the property.\n\nOptional. Omitted and `null` are equivalent and mean no title is provided.",
      }),
      Schema.Null,
    ]),
  ),
  description: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "Human-readable description.\n\nOptional. Omitted and `null` are equivalent and mean no description is provided.",
      }),
      Schema.Null,
    ]),
  ),
  minimum: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description:
          "Minimum value (inclusive).\n\nOptional. Omitted and `null` are equivalent and mean there is no inclusive lower bound.",
        format: "int64",
      }).check(Schema.isInt().annotate({ expected: "an integer" })),
      Schema.Null,
    ]),
  ),
  maximum: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description:
          "Maximum value (inclusive).\n\nOptional. Omitted and `null` are equivalent and mean there is no inclusive upper bound.",
        format: "int64",
      }).check(Schema.isInt().annotate({ expected: "an integer" })),
      Schema.Null,
    ]),
  ),
  default: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description:
          "Default value.\n\nOptional. Omitted and `null` are equivalent and mean no default value is provided.",
        format: "int64",
      }).check(Schema.isInt().annotate({ expected: "an integer" })),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "Schema for integer properties in an elicitation form." });

export type McpServerAcp = {
  readonly name: string;
  readonly serverId: McpServerAcpId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const McpServerAcp = Schema.Struct({
  name: Schema.String.annotate({ description: "Human-readable name identifying this MCP server." }),
  serverId: Schema.suspend((): Schema.Codec<McpServerAcpId> => McpServerAcpId).annotate({
    description:
      "Unique identifier for this MCP server, generated by the component providing it.\n\nProviders MUST NOT reuse an ID for multiple ACP-transport MCP servers that are visible\non the same ACP connection.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nACP transport configuration for MCP.\n\nThe MCP server is provided by an ACP component and communicates over the ACP channel\nusing `mcp/connect`, `mcp/message`, and `mcp/disconnect`.",
});

export type McpServerHttp = {
  readonly name: string;
  readonly url: string;
  readonly headers: ReadonlyArray<HttpHeader>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const McpServerHttp = Schema.Struct({
  name: Schema.String.annotate({ description: "Human-readable name identifying this MCP server." }),
  url: Schema.String.annotate({ description: "URL to the MCP server." }),
  headers: Schema.Array(HttpHeader).annotate({
    description: "HTTP headers to set when making requests to the MCP server.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "HTTP transport configuration for MCP." });

export type McpServerSse = {
  readonly name: string;
  readonly url: string;
  readonly headers: ReadonlyArray<HttpHeader>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const McpServerSse = Schema.Struct({
  name: Schema.String.annotate({ description: "Human-readable name identifying this MCP server." }),
  url: Schema.String.annotate({ description: "URL to the MCP server." }),
  headers: Schema.Array(HttpHeader).annotate({
    description: "HTTP headers to set when making requests to the MCP server.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "SSE transport configuration for MCP." });

export type MultiSelectPropertySchema = {
  readonly title?: string | null;
  readonly description?: string | null;
  readonly minItems?: number | null;
  readonly maxItems?: number | null;
  readonly items: MultiSelectItems;
  readonly default?: ReadonlyArray<string> | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const MultiSelectPropertySchema = Schema.Struct({
  title: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "Optional title for the property.\n\nOptional. Omitted and `null` are equivalent and mean no title is provided.",
      }),
      Schema.Null,
    ]),
  ),
  description: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "Human-readable description.\n\nOptional. Omitted and `null` are equivalent and mean no description is provided.",
      }),
      Schema.Null,
    ]),
  ),
  minItems: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description:
          "Minimum number of items to select.\n\nOptional. Omitted and `null` are equivalent and mean there is no minimum selection count.",
        format: "uint64",
      })
        .check(Schema.isInt().annotate({ expected: "an integer" }))
        .check(
          Schema.isGreaterThanOrEqualTo(0).annotate({
            expected: "a value greater than or equal to 0",
          }),
        ),
      Schema.Null,
    ]),
  ),
  maxItems: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description:
          "Maximum number of items to select.\n\nOptional. Omitted and `null` are equivalent and mean there is no maximum selection count.",
        format: "uint64",
      })
        .check(Schema.isInt().annotate({ expected: "an integer" }))
        .check(
          Schema.isGreaterThanOrEqualTo(0).annotate({
            expected: "a value greater than or equal to 0",
          }),
        ),
      Schema.Null,
    ]),
  ),
  items: Schema.suspend((): Schema.Codec<MultiSelectItems> => MultiSelectItems).annotate({
    description: "The items definition describing allowed values.",
  }),
  default: Schema.optionalKey(
    Schema.Union([
      Schema.Array(Schema.String).annotate({
        description:
          "Default selected values.\n\nOptional. Omitted and `null` are equivalent and mean no default selections are provided.",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "Schema for multi-select (array) properties in an elicitation form." });

export type NesEditSuggestion = {
  readonly id: NesSuggestionId;
  readonly uri: string;
  readonly edits: ReadonlyArray<NesTextEdit>;
  readonly cursorPosition?: Position | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesEditSuggestion = Schema.Struct({
  id: Schema.suspend((): Schema.Codec<NesSuggestionId> => NesSuggestionId).annotate({
    description: "Unique identifier for accept/reject tracking.",
  }),
  uri: Schema.String.annotate({ description: "The URI of the file to edit." }),
  edits: Schema.Array(NesTextEdit).annotate({ description: "The text edits to apply." }),
  cursorPosition: Schema.optionalKey(
    Schema.Union([Position, Schema.Null]).annotate({
      description: "Optional suggested cursor position after applying edits.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "A text edit suggestion." });

export type NesJumpSuggestion = {
  readonly id: NesSuggestionId;
  readonly uri: string;
  readonly position: Position;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesJumpSuggestion = Schema.Struct({
  id: Schema.suspend((): Schema.Codec<NesSuggestionId> => NesSuggestionId).annotate({
    description: "Unique identifier for accept/reject tracking.",
  }),
  uri: Schema.String.annotate({ description: "The file to navigate to." }),
  position: Schema.suspend((): Schema.Codec<Position> => Position).annotate({
    description: "The target position within the file.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "A jump-to-location suggestion." });

export type NesRenameSuggestion = {
  readonly id: NesSuggestionId;
  readonly uri: string;
  readonly position: Position;
  readonly newName: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesRenameSuggestion = Schema.Struct({
  id: Schema.suspend((): Schema.Codec<NesSuggestionId> => NesSuggestionId).annotate({
    description: "Unique identifier for accept/reject tracking.",
  }),
  uri: Schema.String.annotate({ description: "The file URI containing the symbol." }),
  position: Schema.suspend((): Schema.Codec<Position> => Position).annotate({
    description: "The position of the symbol to rename.",
  }),
  newName: Schema.String.annotate({ description: "The new name for the symbol." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "A rename symbol suggestion." });

export type NesSearchAndReplaceSuggestion = {
  readonly id: NesSuggestionId;
  readonly uri: string;
  readonly search: string;
  readonly replace: string;
  readonly isRegex?: boolean | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NesSearchAndReplaceSuggestion = Schema.Struct({
  id: Schema.suspend((): Schema.Codec<NesSuggestionId> => NesSuggestionId).annotate({
    description: "Unique identifier for accept/reject tracking.",
  }),
  uri: Schema.String.annotate({ description: "The file URI to search within." }),
  search: Schema.String.annotate({ description: "The text or pattern to find." }),
  replace: Schema.String.annotate({ description: "The replacement text." }),
  isRegex: Schema.optionalKey(
    Schema.Union([
      Schema.Boolean.annotate({
        description: "Whether `search` is a regular expression. Defaults to `false`.",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "A search-and-replace suggestion." });

export type NumberPropertySchema = {
  readonly title?: string | null;
  readonly description?: string | null;
  readonly minimum?: number | null;
  readonly maximum?: number | null;
  readonly default?: number | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const NumberPropertySchema = Schema.Struct({
  title: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "Optional title for the property.\n\nOptional. Omitted and `null` are equivalent and mean no title is provided.",
      }),
      Schema.Null,
    ]),
  ),
  description: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "Human-readable description.\n\nOptional. Omitted and `null` are equivalent and mean no description is provided.",
      }),
      Schema.Null,
    ]),
  ),
  minimum: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description:
          "Minimum value (inclusive).\n\nOptional. Omitted and `null` are equivalent and mean there is no inclusive lower bound.",
        format: "double",
      }).check(Schema.isFinite().annotate({ expected: "a finite number" })),
      Schema.Null,
    ]),
  ),
  maximum: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description:
          "Maximum value (inclusive).\n\nOptional. Omitted and `null` are equivalent and mean there is no inclusive upper bound.",
        format: "double",
      }).check(Schema.isFinite().annotate({ expected: "a finite number" })),
      Schema.Null,
    ]),
  ),
  default: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description:
          "Default value.\n\nOptional. Omitted and `null` are equivalent and mean no default value is provided.",
        format: "double",
      }).check(Schema.isFinite().annotate({ expected: "a finite number" })),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description: "Schema for number (floating-point) properties in an elicitation form.",
});

export type Plan = {
  readonly entries: ReadonlyArray<PlanEntry>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const Plan = Schema.Struct({
  entries: Schema.Array(PlanEntry).annotate({
    description:
      "The list of tasks to be accomplished.\n\nWhen updating a plan, the agent must send a complete list of all entries\nwith their current status. The client replaces the entire plan with each update.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "An execution plan for accomplishing complex tasks.\n\nPlans consist of multiple entries representing individual tasks or goals.\nAgents report plans to clients to provide visibility into their execution strategy.\nPlans can evolve during execution as the agent discovers new requirements or completes tasks.\n\nSee protocol docs: [Agent Plan](https://agentclientprotocol.com/protocol/agent-plan)",
});

export type PlanFile = {
  readonly planId: PlanId;
  readonly uri: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const PlanFile = Schema.Struct({
  planId: Schema.suspend((): Schema.Codec<PlanId> => PlanId).annotate({
    description: "The plan ID to update.",
  }),
  uri: Schema.String.annotate({ description: "The URI of the file containing the plan." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nA plan represented by a file URI.",
});

export type PlanItems = {
  readonly planId: PlanId;
  readonly entries: ReadonlyArray<PlanEntry>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const PlanItems = Schema.Struct({
  planId: Schema.suspend((): Schema.Codec<PlanId> => PlanId).annotate({
    description: "The plan ID to update.",
  }),
  entries: Schema.Array(PlanEntry).annotate({
    description:
      "The list of tasks to be accomplished.\n\nWhen updating an item-based plan, the agent must send a complete list of all entries\nwith their current status. The client replaces that plan with each update.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nA plan represented as structured entries.",
});

export type PlanMarkdown = {
  readonly planId: PlanId;
  readonly content: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const PlanMarkdown = Schema.Struct({
  planId: Schema.suspend((): Schema.Codec<PlanId> => PlanId).annotate({
    description: "The plan ID to update.",
  }),
  content: Schema.String.annotate({ description: "Markdown content for the plan." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nA plan represented as raw markdown content.",
});

export type PlanRemoved = {
  readonly planId: PlanId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const PlanRemoved = Schema.Struct({
  planId: Schema.suspend((): Schema.Codec<PlanId> => PlanId).annotate({
    description: "The plan ID to remove.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nRemoval notice for a plan identified by ID.",
});

export type PlanUpdate = {
  readonly plan: PlanUpdateContent;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const PlanUpdate = Schema.Struct({
  plan: Schema.suspend((): Schema.Codec<PlanUpdateContent> => PlanUpdateContent).annotate({
    description: "The updated plan content.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nA content update for a plan identified by ID.",
});

export type ResourceLink = {
  readonly annotations?: Annotations | null;
  readonly description?: string | null;
  readonly mimeType?: string | null;
  readonly name: string;
  readonly size?: number | null;
  readonly title?: string | null;
  readonly uri: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ResourceLink = Schema.Struct({
  annotations: Schema.optionalKey(
    Schema.Union([Annotations, Schema.Null]).annotate({
      description:
        "Optional annotations that help clients decide how to display or route this content.",
    }),
  ),
  description: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description: "Optional human-readable details shown with this protocol object.",
      }),
      Schema.Null,
    ]),
  ),
  mimeType: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({ description: "MIME type describing the encoded media payload." }),
      Schema.Null,
    ]),
  ),
  name: Schema.String.annotate({
    description: "Human-readable name shown for this protocol object.",
  }),
  size: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description: "Optional size of the linked resource in bytes, if known.",
        format: "int64",
      }).check(Schema.isInt().annotate({ expected: "an integer" })),
      Schema.Null,
    ]),
  ),
  title: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({ description: "Optional display title for end-user UI." }),
      Schema.Null,
    ]),
  ),
  uri: Schema.String.annotate({
    description: "URI associated with this resource or media payload.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "A resource that the server is capable of reading, included in a prompt or tool call result.",
});

export type SelectedPermissionOutcome = {
  readonly optionId: PermissionOptionId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SelectedPermissionOutcome = Schema.Struct({
  optionId: Schema.suspend((): Schema.Codec<PermissionOptionId> => PermissionOptionId).annotate({
    description: "The ID of the option the user selected.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "The user selected one of the provided options." });

export type SessionConfigBoolean = { readonly currentValue: boolean };
export const SessionConfigBoolean = Schema.Struct({
  currentValue: Schema.Boolean.annotate({
    description: "The current value of the boolean option.",
  }),
}).annotate({ description: "A boolean on/off toggle session configuration option payload." });

export type SessionConfigSelect = {
  readonly currentValue: SessionConfigValueId;
  readonly options: SessionConfigSelectOptions;
};
export const SessionConfigSelect = Schema.Struct({
  currentValue: Schema.suspend(
    (): Schema.Codec<SessionConfigValueId> => SessionConfigValueId,
  ).annotate({ description: "The currently selected value." }),
  options: Schema.suspend(
    (): Schema.Codec<SessionConfigSelectOptions> => SessionConfigSelectOptions,
  ).annotate({ description: "The set of selectable options." }),
}).annotate({
  description: "A single-value selector (dropdown) session configuration option payload.",
});

export type SessionInfoUpdate = {
  readonly title?: string | null;
  readonly updatedAt?: string | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const SessionInfoUpdate = Schema.Struct({
  title: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description: "Human-readable title for the session. Set to null to clear.",
      }),
      Schema.Null,
    ]),
  ),
  updatedAt: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description: "ISO 8601 timestamp of last activity. Set to null to clear.",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Update to session metadata. All fields are optional to support partial updates.\n\nAgents send this notification to update session information like title or custom metadata.\nThis allows clients to display dynamic session names and track session state changes.",
});

export type StringMultiSelectItems = {
  readonly enum: ReadonlyArray<string>;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const StringMultiSelectItems = Schema.Struct({
  enum: Schema.Array(Schema.String).annotate({ description: "Allowed enum values." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "String item schema for multi-select enum properties." });

export type StringPropertySchema = {
  readonly title?: string | null;
  readonly description?: string | null;
  readonly minLength?: number | null;
  readonly maxLength?: number | null;
  readonly pattern?: string | null;
  readonly format?: StringFormat | null;
  readonly default?: string | null;
  readonly enum?: ReadonlyArray<string> | null;
  readonly oneOf?: ReadonlyArray<EnumOption> | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const StringPropertySchema = Schema.Struct({
  title: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "Optional title for the property.\n\nOptional. Omitted and `null` are equivalent and mean no title is provided.",
      }),
      Schema.Null,
    ]),
  ),
  description: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "Human-readable description.\n\nOptional. Omitted and `null` are equivalent and mean no description is provided.",
      }),
      Schema.Null,
    ]),
  ),
  minLength: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description:
          "Minimum string length.\n\nOptional. Omitted and `null` are equivalent and mean there is no minimum length constraint.",
        format: "uint32",
      })
        .check(Schema.isInt().annotate({ expected: "an integer" }))
        .check(
          Schema.isGreaterThanOrEqualTo(0).annotate({
            expected: "a value greater than or equal to 0",
          }),
        ),
      Schema.Null,
    ]),
  ),
  maxLength: Schema.optionalKey(
    Schema.Union([
      Schema.Number.annotate({
        description:
          "Maximum string length.\n\nOptional. Omitted and `null` are equivalent and mean there is no maximum length constraint.",
        format: "uint32",
      })
        .check(Schema.isInt().annotate({ expected: "an integer" }))
        .check(
          Schema.isGreaterThanOrEqualTo(0).annotate({
            expected: "a value greater than or equal to 0",
          }),
        ),
      Schema.Null,
    ]),
  ),
  pattern: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "Pattern the string must match.\n\nOptional. Omitted and `null` are equivalent and mean there is no pattern constraint.",
      }),
      Schema.Null,
    ]),
  ),
  format: Schema.optionalKey(
    Schema.Union([StringFormat, Schema.Null]).annotate({
      description:
        "String format.\n\nOptional. Omitted and `null` are equivalent and mean there is no format constraint.",
    }),
  ),
  default: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "Default value.\n\nOptional. Omitted and `null` are equivalent and mean no default value is provided.",
      }),
      Schema.Null,
    ]),
  ),
  enum: Schema.optionalKey(
    Schema.Union([
      Schema.Array(Schema.String).annotate({
        description:
          "Enum values for untitled single-select enums.\nOptional. Omitted and `null` are equivalent and mean no untitled single-select choices are\ndeclared by `enum`.",
      }),
      Schema.Null,
    ]),
  ),
  oneOf: Schema.optionalKey(
    Schema.Union([
      Schema.Array(EnumOption).annotate({
        description:
          "Titled enum options for titled single-select enums.\nOptional. Omitted and `null` are equivalent and mean no titled single-select choices are\ndeclared by `oneOf`.",
      }),
      Schema.Null,
    ]),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nOptional. Omitted and `null` are equivalent and mean no metadata.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    'Schema for string properties in an elicitation form.\n\nWhen `enum` or `oneOf` is set, this represents a single-select enum\nwith `"type": "string"`.',
});

export type Terminal = {
  readonly terminalId: TerminalId;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const Terminal = Schema.Struct({
  terminalId: Schema.suspend((): Schema.Codec<TerminalId> => TerminalId).annotate({
    description: "Identifier of the terminal instance to embed in the content stream.",
  }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Embed a terminal created with `terminal/create` by its id.\n\nThe terminal must be added before calling `terminal/release`.\n\nSee protocol docs: [Terminal](https://agentclientprotocol.com/protocol/terminals)",
});

export type TextContent = {
  readonly annotations?: Annotations | null;
  readonly text: string;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const TextContent = Schema.Struct({
  annotations: Schema.optionalKey(
    Schema.Union([Annotations, Schema.Null]).annotate({
      description:
        "Optional annotations that help clients decide how to display or route this content.",
    }),
  ),
  text: Schema.String.annotate({ description: "Text payload carried by this content block." }),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "Text provided to or from an LLM." });

export type ToolCall = {
  readonly toolCallId: ToolCallId;
  readonly title: string;
  readonly name?: string | null;
  readonly kind?: ToolKind;
  readonly status?: ToolCallStatus;
  readonly content?: ReadonlyArray<ToolCallContent>;
  readonly locations?: ReadonlyArray<ToolCallLocation>;
  readonly rawInput?: Schema.Json;
  readonly rawOutput?: Schema.Json;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const ToolCall = Schema.Struct({
  toolCallId: Schema.suspend((): Schema.Codec<ToolCallId> => ToolCallId).annotate({
    description: "Unique identifier for this tool call within the session.",
  }),
  title: Schema.String.annotate({
    description: "Human-readable title describing what the tool is doing.",
  }),
  name: Schema.optionalKey(
    Schema.Union([
      Schema.String.annotate({
        description:
          "**UNSTABLE**\n\nThis capability is not part of the spec yet, and may be removed or changed at any point.\n\nProgrammatic name of the tool being invoked.\n\nThis field is optional. Omitting it or sending `null` both mean that no\ntool name is available.",
      }),
      Schema.Null,
    ]),
  ),
  kind: Schema.optionalKey(
    Schema.suspend((): Schema.Codec<ToolKind> => ToolKind).annotate({
      description:
        "The category of tool being invoked.\nHelps clients choose appropriate icons and UI treatment.",
    }),
  ),
  status: Schema.optionalKey(
    Schema.suspend((): Schema.Codec<ToolCallStatus> => ToolCallStatus).annotate({
      description: "Current execution status of the tool call.",
    }),
  ),
  content: Schema.optionalKey(
    Schema.Array(ToolCallContent).annotate({ description: "Content produced by the tool call." }),
  ),
  locations: Schema.optionalKey(
    Schema.Array(ToolCallLocation).annotate({
      description:
        'File locations affected by this tool call.\nEnables "follow-along" features in clients.',
    }),
  ),
  rawInput: Schema.optionalKey(
    Schema.Json.annotate({
      expected: "JSON value",
      description: "Raw input parameters sent to the tool.",
    }),
  ),
  rawOutput: Schema.optionalKey(
    Schema.Json.annotate({
      expected: "JSON value",
      description: "Raw output returned by the tool.",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({
  description:
    "Represents a tool call that the language model has requested.\n\nTool calls are actions that the agent executes on behalf of the language model,\nsuch as reading files, executing code, or fetching data from external sources.\n\nSee protocol docs: [Tool Calls](https://agentclientprotocol.com/protocol/tool-calls)",
});

export type UsageUpdate = {
  readonly used: number;
  readonly size: number;
  readonly cost?: Cost | null;
  readonly _meta?: { readonly [x: string]: Schema.Json } | null;
};
export const UsageUpdate = Schema.Struct({
  used: Schema.Number.annotate({ description: "Tokens currently in context.", format: "uint64" })
    .check(Schema.isInt().annotate({ expected: "an integer" }))
    .check(
      Schema.isGreaterThanOrEqualTo(0).annotate({ expected: "a value greater than or equal to 0" }),
    ),
  size: Schema.Number.annotate({
    description: "Total context window size in tokens.",
    format: "uint64",
  })
    .check(Schema.isInt().annotate({ expected: "an integer" }))
    .check(
      Schema.isGreaterThanOrEqualTo(0).annotate({ expected: "a value greater than or equal to 0" }),
    ),
  cost: Schema.optionalKey(
    Schema.Union([Cost, Schema.Null]).annotate({
      description: "Cumulative session cost (optional).",
    }),
  ),
  _meta: Schema.optionalKey(
    Schema.Union([
      Schema.Record(Schema.String, Schema.Json.annotate({ expected: "JSON value" })).annotate({
        description:
          "The _meta property is reserved by ACP to allow clients and agents to attach additional\nmetadata to their interactions. Implementations MUST NOT make assumptions about values at\nthese keys.\n\nSee protocol docs: [Extensibility](https://agentclientprotocol.com/protocol/extensibility)",
      }),
      Schema.Null,
    ]),
  ),
}).annotate({ description: "Context window and cost update for a session." });
