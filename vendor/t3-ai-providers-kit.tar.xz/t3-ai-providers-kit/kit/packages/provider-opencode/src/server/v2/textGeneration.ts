// Generate endpoints return 403 on the free tier; use and remove a temporary prompt session.
import { AbsolutePath, Location, Model, Provider, Session } from "@opencode/client/effect";
import { TextGenerationError } from "@t3tools/contracts";
import { getModelSelectionStringOptionValue } from "@t3tools/shared/model";
import * as Deferred from "effect/Deferred";
import * as Effect from "effect/Effect";
import * as Schema from "effect/Schema";
import * as Stream from "effect/Stream";

import * as ProviderHost from "@t3tools/provider-core/server/ProviderHost";
import * as OpenCode2Server from "./OpenCode2Server.ts";
import * as OpenCodeRuntime from "../OpenCodeRuntime.ts";
import * as TextGenerationOperations from "@t3tools/provider-core/server/textGenerationOperations";

const isTextGenerationError = Schema.is(TextGenerationError);

const GENERATION_TIMEOUT = "3 minutes";

// Free models refuse denied read/shell permissions; ask and reject requests as they arrive.
const GENERATION_PERMISSIONS = [{ action: "*", resource: "*", effect: "ask" }] as const;

// Provider error text stays in cause, outside detail.
type Outcome =
  | { readonly _tag: "text"; readonly text: string }
  | { readonly _tag: "failed"; readonly detail: string; readonly cause?: unknown };

const runOnServer = Effect.fn("Opencode2TextGeneration.runOnServer")(function* (
  connection: OpenCode2Server.OpenCode2Connection,
  input: TextGenerationOperations.Request<Schema.Top>,
) {
  const { resolveAttachmentPath } = yield* ProviderHost.ProviderHost;
  const { client } = connection;
  const parsed = OpenCodeRuntime.parseOpenCodeModelSlug(input.modelSelection.model);
  if (parsed === null) {
    return yield* new TextGenerationError({
      operation: input.operation,
      detail: "OpenCode model selection must use the 'provider/model' format.",
    });
  }
  const variant = getModelSelectionStringOptionValue(input.modelSelection, "variant");
  const outcome = yield* Deferred.make<Outcome>();
  let sessionId: string | undefined;
  const texts = new Map<string, string>();
  // Subscribed first: the stream is volatile, and the reply arrives on it.
  const events = yield* connection.events;
  yield* events.pipe(
    Stream.runForEach((event) => {
      // An execution end a newer server sent in a shape this build cannot
      // read still ends the generation, as it ends a turn in the adapter.
      if (event.type === "unreadable.execution.ended") {
        if (event.sessionID !== sessionId) return Effect.void;
        return Deferred.succeed(
          outcome,
          event.executionType === "session.execution.succeeded"
            ? { _tag: "text", text: [...texts.values()].join("\n").trim() }
            : {
                _tag: "failed",
                detail: "OpenCode ended the generation in a way this version cannot read.",
                cause: event,
              },
        );
      }
      if (
        sessionId === undefined ||
        !("data" in event) ||
        !("sessionID" in event.data) ||
        event.data.sessionID !== sessionId
      ) {
        return Effect.void;
      }
      switch (event.type) {
        case "session.text.ended":
          texts.set(`${event.data.assistantMessageID}:${event.data.ordinal}`, event.data.text);
          return Effect.void;
        case "permission.asked":
          return client.permission
            .reply({
              sessionID: event.data.sessionID,
              requestID: event.data.id,
              decision: "reject",
              message: "Tools are not available while generating text.",
            })
            .pipe(Effect.ignore({ log: true }));
        case "session.execution.succeeded":
          return Deferred.succeed(outcome, {
            _tag: "text",
            text: [...texts.values()].join("\n").trim(),
          });
        case "session.execution.failed":
          return Deferred.succeed(outcome, {
            _tag: "failed",
            detail: "OpenCode could not generate the text.",
            cause: event.data.error,
          });
        case "session.execution.interrupted":
          return Deferred.succeed(outcome, {
            _tag: "failed",
            detail: "OpenCode stopped the generation.",
          });
        default:
          return Effect.void;
      }
    }),
    // The reply only arrives on this stream, so a lost stream ends the wait.
    Effect.exit,
    Effect.flatMap((exit) =>
      Deferred.succeed(outcome, {
        _tag: "failed",
        detail: "The OpenCode event stream was lost.",
        cause: exit,
      }),
    ),
    Effect.forkScoped,
  );
  // The limit covers creating the session and sending the prompt as well, since
  // either request can stall while the event stream stays connected.
  const generate = Effect.gen(function* () {
    const session = yield* client.session.create({
      title: `T3 Code ${input.operation}`,
      location: Location.PublicRef.make({ directory: AbsolutePath.make(input.cwd) }),
      model: Model.Ref.make({
        providerID: Provider.ID.make(parsed.providerID),
        id: Model.ID.make(parsed.modelID),
        ...(variant === undefined ? {} : { variant: Model.VariantID.make(variant) }),
      }),
      permissions: GENERATION_PERMISSIONS,
    });
    sessionId = session.id;
    yield* Effect.addFinalizer(() =>
      client.session
        .remove({ sessionID: session.id })
        .pipe(Effect.timeout("5 seconds"), Effect.ignore({ log: true })),
    );
    const images = (input.attachments ?? []).flatMap((attachment) => {
      if (attachment.type !== "image") return [];
      const path = resolveAttachmentPath(attachment);
      return path === null ? [] : [{ uri: `file://${path}`, name: attachment.name }];
    });
    yield* client.session.prompt({
      sessionID: session.id,
      text: input.prompt,
      ...(images.length === 0 ? {} : { files: images }),
    });
    return yield* Deferred.await(outcome);
  });
  const result = yield* generate.pipe(
    Effect.timeoutOrElse({
      duration: GENERATION_TIMEOUT,
      orElse: () =>
        (sessionId === undefined
          ? Effect.void
          : client.session
              .interrupt({ sessionID: Session.ID.make(sessionId) })
              .pipe(Effect.timeout("5 seconds"), Effect.ignore)
        ).pipe(
          Effect.as<Outcome>({
            _tag: "failed",
            detail: "OpenCode did not finish generating in time.",
          }),
        ),
    }),
  );
  if (result._tag === "failed") {
    return yield* new TextGenerationError({
      operation: input.operation,
      detail: result.detail,
      ...(result.cause === undefined ? {} : { cause: result.cause }),
    });
  }
  if (result.text.length === 0) {
    return yield* new TextGenerationError({
      operation: input.operation,
      detail: "OpenCode returned empty output.",
    });
  }
  return result.text;
}, Effect.scoped);

export const make = Effect.fn("OpenCode2TextGeneration.make")(function* () {
  const server = yield* OpenCode2Server.OpenCode2Server;
  const host = yield* ProviderHost.ProviderHost;
  const run: TextGenerationOperations.Runner = (input) =>
    server
      .withConnection((connection) => runOnServer(connection, input))
      .pipe(
        Effect.provideService(ProviderHost.ProviderHost, host),
        Effect.mapError((cause) =>
          isTextGenerationError(cause)
            ? cause
            : new TextGenerationError({
                operation: input.operation,
                detail: "OpenCode text generation failed.",
                cause,
              }),
        ),
        Effect.flatMap((raw) => TextGenerationOperations.decodeJsonReply(input, "OpenCode", raw)),
      );
  return TextGenerationOperations.fromRunner(
    "OpenCode2TextGeneration",
    TextGenerationOperations.withoutInvestigation("OpenCode", run),
  );
});
