import { ProviderDriverKind } from "@t3tools/contracts";
import { defineProviderClient } from "@t3tools/provider-core/client";

import { KiroSettings } from "./settings.ts";

const TILE =
  "M260 0H940A260 260 0 0 1 1200 260V940A260 260 0 0 1 940 1200H260A260 260 0 0 1 0 940V260A260 260 0 0 1 260 0Z";
const GHOST =
  "M398.554 818.914C316.315 1001.03 491.477 1046.74 620.672 940.156C658.687 1059.66 801.052 970.473 852.234 877.795C964.787 673.567 919.318 465.357 907.64 422.374C827.637 129.443 427.623 128.946 358.8 423.865C342.651 475.544 342.402 534.18 333.458 595.051C328.986 625.86 325.507 645.488 313.83 677.785C306.873 696.424 297.68 712.819 282.773 740.645C259.915 783.881 269.604 867.113 387.87 823.883L399.051 818.914H398.554Z";
const LEFT_EYE =
  "M636.123 549.353C603.328 549.353 598.359 510.097 598.359 486.742C598.359 465.623 602.086 448.977 609.293 438.293C615.504 428.852 624.697 424.131 636.123 424.131C647.555 424.131 657.492 428.852 664.447 438.541C672.398 449.474 676.623 466.12 676.623 486.742C676.623 525.998 661.471 549.353 636.375 549.353H636.123Z";
const RIGHT_EYE =
  "M771.24 549.353C738.445 549.353 733.477 510.097 733.477 486.742C733.477 465.623 737.203 448.977 744.41 438.293C750.621 428.852 759.814 424.131 771.24 424.131C782.672 424.131 792.609 428.852 799.564 438.541C807.516 449.474 811.74 466.12 811.74 486.742C811.74 525.998 796.588 549.353 771.492 549.353H771.24Z";
const white = { light: "#FFFFFF", dark: "#FFFFFF" };
const black = { light: "#000000", dark: "#000000" };

export const kiroClient = defineProviderClient({
  driverKind: ProviderDriverKind.make("kiro"),
  label: "Kiro",
  featured: false,
  badgeLabel: "Early Access",
  settingsSchema: KiroSettings,
  environmentFields: [
    {
      name: "KIRO_API_KEY",
      label: "Kiro API key",
      description: "Optional. Signs in without `kiro-cli login` (Kiro Pro and above).",
      placeholder: "Paste API key",
      sensitive: true,
    },
  ],
  icon: {
    viewBox: "0 0 1200 1200",
    fill: { light: "#9046FF", dark: "#9046FF" },
    paths: [
      // The ghost is a hole in the tile, so a monochrome icon still shows it.
      { d: `${TILE}${GHOST}${LEFT_EYE}${RIGHT_EYE}`, fillRule: "evenodd" },
      { d: GHOST, fill: white },
      { d: LEFT_EYE, fill: black },
      { d: RIGHT_EYE, fill: black },
    ],
  },
});
