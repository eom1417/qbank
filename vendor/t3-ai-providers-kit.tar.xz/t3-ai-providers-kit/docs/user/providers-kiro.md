# Kiro

T3 Code runs the [Kiro CLI](https://kiro.dev/docs/cli/) as an agent, using your own Kiro account,
custom agents, steering, hooks, and MCP configuration.

## Set Up Kiro

1. Install the Kiro CLI on the machine running the T3 Code server. On macOS or Linux, run
   `curl -fsSL https://cli.kiro.dev/install | bash`. On Windows 11, run
   `irm 'https://cli.kiro.dev/install.ps1' | iex` in PowerShell. Kiro's
   [installation guide](https://kiro.dev/docs/getting-started/installation/) lists other options.
2. Run `kiro-cli login` once in a terminal. Kiro Pro and higher plans can instead set an API key as
   `KIRO_API_KEY` in the Kiro provider's environment variables.
3. Open **Settings → Providers**, enable Kiro, and refresh it.

If `kiro-cli` is not on the server's `PATH`, set its **Binary path**. On macOS and Linux, the
installer usually puts it in `~/.local/bin`. T3 Code starts Kiro's CLI V3 engine, so a Kiro CLI
that cannot run V3 will not start.

## Models

The model picker lists the models your Kiro account can use once Kiro is signed in. New threads
start on your Kiro default model: `auto`, which lets Kiro choose, unless your account or
organization sets another. A model your account cannot use stops the turn with an error instead of
running on another model.

Models with adjustable reasoning effort, such as recent Claude Opus and Sonnet models and GPT-5.6,
show a **Reasoning** setting with only the levels Kiro offers for that model. Your default model and
models without effort control run at Kiro's own setting.

## Agents

The **Agent** setting next to the model picks the
[Kiro agent](https://kiro.dev/docs/custom-agents/) a thread runs as: Kiro's built-in agents such as
Spec and Plan, and your own agents in `~/.kiro/agents`. Agents in a project's `.kiro/agents` are
not listed yet. Refresh the Kiro provider after adding or removing an agent.

The thread's model still applies when an agent sets its own `model`. An agent that was removed
leaves the thread on Kiro's current agent.

## Permission Modes

Kiro asks before tool calls such as writes and commands, and T3 Code answers by the permission mode:

- **Supervised** sends those requests to you. Kiro's Autopilot is off, so Kiro also asks you to
  review the turn's file changes before it finishes.
- **Full access** approves them without asking you. Autopilot stays on, so there is no review step.

Kiro offers no **Auto** or **Auto-accept edits**. Approvals offer only the choices Kiro sends. Kiro's
**Always allow** saves a rule for the whole workspace, so T3 Code shows it only when Kiro offers no
one-time choice.

## Steering, Forks and Compaction

- A message you send while Kiro is working joins the running turn. Kiro reads it once its current
  step or tool call finishes. A message with images stops the turn and starts a new one with it.
- Forking a thread from a message gives the fork Kiro's own copy of the conversation up to that
  message.
- `/compact` uses Kiro's own compaction. Kiro also compacts on its own as the conversation fills its
  context.
